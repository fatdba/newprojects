SELECT TO_CHAR(ROWNUM) row_num, v0.* FROM /* 2b.160 */ (
-- requested by David Kurtz
SELECT  /* LEADING(T) USE_NL(S) */ -- removed hint as per Luis Calvo
        t.owner, t.table_name, t.tablespace_name, t.num_rows, t.blocks hwm_blocks, t.last_analyzed, s.blocks seg_blocks
FROM    dba_tables t
,       dba_segments s
WHERE   'Y' = 'Y'
and     t.owner not in ('ANONYMOUS','APEX_030200','APEX_040000','APEX_SSO','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS')
and     t.owner not in ('SI_INFORMTN_SCHEMA','SQLTXADMIN','SQLTXPLAIN','SYS','SYSMAN','SYSTEM','TRCANLZR','WMSYS','XDB','XS$NULL','PERFSTAT','STDBYPERF','MGDSYS','OJVMSYS')
and     s.segment_type = 'TABLE'
and     t.owner = s.owner
and     t.table_name = s.segment_name
and     t.tablespace_name = s.tablespace_name
and     s.partition_name IS NULL
and     t.segment_created = 'YES'
AND     (       t.num_rows = 0
        OR       t.num_rows IS NULL
        )
and     s.extents =  1
ORDER BY 1,2
) v0 WHERE ROWNUM <= 10000
