-- time zero for pdtool1 (begin)
VAR pdtool1_main_time0 NUMBER;
EXEC :pdtool1_main_time0 := DBMS_UTILITY.GET_TIME;

COL my_sid NEW_V my_sid;
SELECT TO_CHAR(sid) my_sid FROM v$mystat WHERE ROWNUM = 1;

SET TERM ON;
SPO 00000_readme_first_&&my_sid..txt
-- initial validation
PRO If pdtool1 disconnects right after this message it means the user executing it
PRO owns a table called PLAN_TABLE that is not the Oracle seeded GTT plan table
PRO owned by SYS (PLAN_TABLE$ table with a PUBLIC synonym PLAN_TABLE).
PRO pdtool1 requires the Oracle seeded PLAN_TABLE, consider dropping the one in this schema.
WHENEVER SQLERROR EXIT;
DECLARE
 is_plan_table_in_usr_schema NUMBER; 
 l_version v$instance.version%TYPE;
BEGIN
 SELECT COUNT(*)
   INTO is_plan_table_in_usr_schema
   FROM user_tables
  WHERE table_name = 'PLAN_TABLE';
  -- user has a physical table called PLAN_TABLE, abort
  IF is_plan_table_in_usr_schema > 0 THEN
    RAISE_APPLICATION_ERROR(-20100, 'PLAN_TABLE physical table present in user schema '||USER||'.');
  END IF;
  SELECT version INTO l_version FROM v$instance;
  IF SUBSTR(l_version, 1, 2) != SUBSTR('&&_o_release.', 1, 2) THEN
    RAISE_APPLICATION_ERROR(-20101, 'Set configuration parameter "pdtool1_sections" on sql/pdtool1_00_config.sql instead.');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

-- parameters (reset readme)
SPO 00000_readme_first_&&my_sid..txt
PRO
PRO Parameter 1: 
PRO If your Database is licensed to use the Oracle Tuning pack please enter T.
PRO If you have a license for Diagnostics pack but not for Tuning pack, enter D.
PRO If you have both Tuning and Diagnostics packs, enter T.
PRO Be aware value N reduces the output content substantially. Avoid N if possible.
PRO
PRO Oracle Pack License? (Tuning, Diagnostics or None) [ T | D | N ] (required)
COL license_pack NEW_V license_pack FOR A1;
SELECT NVL(UPPER(SUBSTR(TRIM('&1.'), 1, 1)), '?') license_pack FROM DUAL;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF NOT '&&license_pack.' IN ('T', 'D', 'N') THEN
    RAISE_APPLICATION_ERROR(-20000, 'Invalid Oracle Pack License "&&license_pack.". Valid values are T, D and N.');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET TERM OFF;
COL diagnostics_pack NEW_V diagnostics_pack FOR A1;
SELECT CASE WHEN '&&license_pack.' IN ('T', 'D') THEN 'Y' ELSE 'N' END diagnostics_pack FROM DUAL;
COL skip_diagnostics NEW_V skip_diagnostics FOR A1;
SELECT CASE WHEN '&&license_pack.' IN ('T', 'D') THEN NULL ELSE 'Y' END skip_diagnostics FROM DUAL;
COL tuning_pack NEW_V tuning_pack FOR A1;
SELECT CASE WHEN '&&license_pack.' = 'T' THEN 'Y' ELSE 'N' END tuning_pack FROM DUAL;
COL skip_tuning NEW_V skip_tuning FOR A1;
SELECT CASE WHEN '&&license_pack.' = 'T' THEN NULL ELSE 'Y' END skip_tuning FROM DUAL;
SET TERM ON;
SELECT 'Be aware value "N" reduces output content substantially. Avoid "N" if possible.' warning FROM dual WHERE '&&license_pack.' = 'N';
BEGIN
  IF '&&license_pack.' = 'N' THEN
    DBMS_LOCK.SLEEP(10); -- sleep few seconds
  END IF;
END;
/

PRO
PRO Parameter 2:
PRO Name of an optional custom configuration file executed right after 
PRO sql/pdtool1_00_config.sql. If such file name is provided, then corresponding file
PRO should exist under pdtool1-master/sql. Filename is case sensitivive and its existence
PRO is not validated. Example: custom_config_01.sql
PRO If no custom configuration file is needed, simply hit the "return" key.
PRO
PRO Custom configuration filename? (optional)
COL custom_config_filename NEW_V custom_config_filename NOPRI;
SELECT NVL(TRIM('&2.'), 'null') custom_config_filename FROM DUAL;

SPO OFF;

-- ash verification
DEF pdtool1_estimated_hrs = '0';
@@&&ash_validation.&&skip_diagnostics.verify_stats_wr_sys.sql
@@&&ash_validation.&&skip_diagnostics.pre_check.sql

SET HEA OFF TERM OFF;
SPO pdtool1_pause.sql
SELECT 'PAUSE *** pdtool1 may take over 8 hours to execute, hit "return" to continue, or control-c to quit. ' FROM DUAL WHERE &&pdtool1_estimated_hrs. > 8;
SPO OFF;
SET HEA ON TERM ON;
@pdtool1_pause.sql
HOS rm pdtool1_pause.sql

-- reset readme
SET TERM OFF;
SPO 00000_readme_first_&&my_sid..txt
PRO
PRO Open and read 00001_pdtool1_<dbname>_index.html
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
PRO initial log:
PRO
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
DEF
@@pdtool1_00_config.sql
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
PRO custom configuration filename: "&&custom_config_filename."
PRO
SET SUF '';
@@&&custom_config_filename.
SET SUF sql;
-- dba_hist or awr repository. do not change awr_hist_prefix.
DEF awr_hist_prefix = 'DBA_HIST_';
DEF awr_object_prefix = 'dba_hist_';
COL awr_object_prefix NEW_V awr_object_prefix;
SELECT CASE WHEN '&&pdtool1_repo_user.' IS NULL THEN '&&awr_object_prefix.' ELSE '&&pdtool1_repo_user..&&pdtool1_repo_prefix.' END awr_object_prefix FROM DUAL
/
-- links
DEF pdtool1_conf_tool_page = '<a href="https://www.fatdba.com/" target="_blank">';
DEF pdtool1_conf_all_pages_icon = '<a href="https://www.fatdba.com/" target="_blank"><img src="pdtool1_img.jpg" alt="pdtool1" height="47" width="50" /></a>';
DEF pdtool1_conf_all_pages_logo = '';
DEF pdtool1_conf_google_charts = '<script type="text/javascript" src="https://www.google.com/jsapi"></script>';
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
PRO config log:
PRO
DEF
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
PRO setup log:
PRO
@@pdtool1_0b_pre.sql
DEF section_id = '0a';
EXEC DBMS_APPLICATION_INFO.SET_MODULE('&&pdtool1_prefix.','&&section_id.');
DEF max_col_number = '7';
DEF column_number = '0';
SPO &&pdtool1_main_report..html APP;
PRO <table><tr class="main">
PRO <td class="c">1/&&max_col_number.</td>
PRO <td class="c">2/&&max_col_number.</td>
PRO <td class="c">3/&&max_col_number.</td>
PRO <td class="c">4/&&max_col_number.</td>
PRO <td class="c">5/&&max_col_number.</td>
PRO <td class="c">6/&&max_col_number.</td>
PRO <td class="c">7/&&max_col_number.</td>
PRO </tr><tr class="main"><td>
PRO &&pdtool1_conf_tool_page.<img src="pdtool1_img.jpg" alt="pdtool1" height="234" width="248" /></a>
PRO <br />
SPO OFF;

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '1';

@@&&pdtool1_1a.configuration.sql
@@&&pdtool1_1b.security.sql
@@&&pdtool1_1c.audit.sql
@@&&pdtool1_1d.memory.sql
@@&&pdtool1_1e.resources.sql
@@&&pdtool1_1f.resources_statspack.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '2';

SPO &&pdtool1_main_report..html APP;
PRO
PRO </td><td>
PRO
SPO OFF;

@@&&pdtool1_2a.admin.sql
@@&&pdtool1_2b.storage.sql
@@&&pdtool1_2c.asm.sql
@@&&pdtool1_2d.rman.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '3';

SPO &&pdtool1_main_report..html APP;
PRO
PRO </td><td>
PRO
SPO OFF;

@@&&pdtool1_3a.resource_mgm.sql
@@&&pdtool1_3b.plan_stability.sql
@@&&pdtool1_3c.cbo_stats.sql
@@&&pdtool1_3d.performance.sql
@@&&skip_diagnostics.&&pdtool1_3e.os_stats.sql
@@&&is_single_instance.&&skip_diagnostics.&&pdtool1_3f.ic_latency.sql
@@&&is_single_instance.&&skip_diagnostics.&&pdtool1_3g.ic_performance.sql
@@&&pdtool1_3h.sessions.sql
@@&&pdtool1_3i.jdbc_sessions.sql
@@&&pdtool1_3j.non_jdbc_sessions.sql
@@&&pdtool1_3k.dataguard.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '4';

SPO &&pdtool1_main_report..html APP;
PRO
PRO </td><td>
PRO
SPO OFF;

@@&&skip_diagnostics.&&pdtool1_4a.sga_stats.sql
@@&&skip_diagnostics.&&pdtool1_4b.pga_stats.sql
@@&&skip_diagnostics.&&pdtool1_4c.mem_stats.sql
@@&&skip_diagnostics.&&pdtool1_4d.time_model.sql
@@&&skip_diagnostics.&&pdtool1_4e.time_model_comp.sql
@@&&skip_diagnostics.&&skip_10g_script.&&pdtool1_4f.io_waits.sql
@@&&skip_diagnostics.&&skip_10g_script.&&pdtool1_4g.io_waits_top_histog.sql
@@&&skip_diagnostics.&&skip_10g_script.&&pdtool1_4h.io_waits_top_trend.sql
@@&&skip_diagnostics.&&skip_10g_script.&&pdtool1_4i.io_waits_top_relation.sql
@@&&pdtool1_4j.parallel_execution.sql
@@&&skip_diagnostics.&&pdtool1_4k.sysmetric_history.sql
@@&&skip_diagnostics.&&pdtool1_4l.sysmetric_summary.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '5';

SPO &&pdtool1_main_report..html APP;
PRO
PRO </td><td>
PRO
SPO OFF;

@@&&skip_diagnostics.&&pdtool1_5a.ash.sql
@@&&skip_diagnostics.&&pdtool1_5b.ash_wait.sql
@@&&skip_diagnostics.&&pdtool1_5c.ash_top.sql
@@&&skip_diagnostics.&&pdtool1_5d.sysstat.sql
@@&&skip_diagnostics.&&pdtool1_5e.sysstat_exa.sql
@@&&skip_diagnostics.&&pdtool1_5f.sysstat_current.sql
@@&&skip_diagnostics.&&pdtool1_5g.exadata.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '6';

SPO &&pdtool1_main_report..html APP;
PRO
PRO </td><td>
PRO
SPO OFF;

@@&&skip_diagnostics.&&pdtool1_6a.ash_class.sql
@@&&skip_diagnostics.&&pdtool1_6b.ash_event.sql
@@&&skip_diagnostics.&&pdtool1_6c.ash_sql.sql
@@&&skip_diagnostics.&&pdtool1_6d.ash_sql_ts.sql
@@&&skip_diagnostics.&&pdtool1_6e.ash_programs.sql
@@&&skip_diagnostics.&&pdtool1_6f.ash_modules.sql
@@&&skip_diagnostics.&&pdtool1_6g.ash_users.sql
@@&&skip_diagnostics.&&pdtool1_6h.ash_plsql.sql
@@&&skip_diagnostics.&&pdtool1_6i.ash_objects.sql
@@&&skip_diagnostics.&&pdtool1_6j.ash_services.sql
@@&&skip_diagnostics.&&pdtool1_6k.ash_phv.sql
@@&&skip_diagnostics.&&skip_10g_script.&&pdtool1_6l.ash_signature.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DEF column_number = '7';

SPO &&pdtool1_main_report..html APP;
PRO
PRO </td><td>
PRO
SPO OFF;

@@&&skip_diagnostics.&&pdtool1_7a.rpt.sql
@@&&skip_diagnostics.&&pdtool1_7b.sql_sample.sql

PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- log footer
SPO &&pdtool1_log..txt APP;
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
DEF;
PRO Parameters
COL sid FOR A40;
COL name FOR A40;
COL value FOR A50;
COL display_value FOR A50;
COL update_comment NOPRI;
SELECT *
  FROM v$spparameter
 WHERE isspecified = 'TRUE'
 ORDER BY
       name,
       sid,
       ordinal;
COL sid CLE;
COL name CLE;
COL value CLE;
COL display_value CLE;
COL update_comment CLE;
SHOW PARAMETERS;
PRO
SELECT ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_time0) / 100 / 3600, 3) elapsed_hours FROM DUAL;
PRO
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
PRO end log
SPO OFF;

-- main footer
SPO &&pdtool1_main_report..html APP;
PRO
PRO </td></tr></table>
SPO OFF;
-- time one for pdtool1 (end)
VAR pdtool1_main_time1 NUMBER;
EXEC :pdtool1_main_time1 := DBMS_UTILITY.GET_TIME;
@@pdtool1_0c_post.sql
EXEC DBMS_APPLICATION_INFO.SET_MODULE(NULL,NULL);
UNDEF 1 2

