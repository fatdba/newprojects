
@@get_schema INSTALL
@@get_schema HISDATA
@@get_schema P0664882
