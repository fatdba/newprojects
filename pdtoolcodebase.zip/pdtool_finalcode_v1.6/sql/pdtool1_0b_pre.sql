DEF pdtool1_vYYNN = 'v1708';
DEF pdtool1_vrsn = '&&pdtool1_vYYNN. (2017-03-25)';
DEF pdtool1_copyright = ' (c) 2017';

SET TERM OFF;
-- watchdog
VAR pdtool1_time0 NUMBER;
VAR pdtool1_max_seconds NUMBER;
EXEC :pdtool1_time0 := DBMS_UTILITY.GET_TIME;
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
EXEC :pdtool1_max_seconds := &&pdtool1_conf_max_hours. * 3600;
COL pdtool1_bypass NEW_V pdtool1_bypass;
SELECT NULL pdtool1_bypass FROM DUAL;

-- snaps
SELECT startup_time, dbid, instance_number, COUNT(*) snaps,
       MIN(begin_interval_time) min_time, MAX(end_interval_time) max_time,
       MIN(snap_id) min_snap_id, MAX(snap_id) max_snap_id
  FROM &&awr_object_prefix.snapshot
 GROUP BY
       startup_time, dbid, instance_number
 ORDER BY
       startup_time, dbid, instance_number
/

COL history_days NEW_V history_days;
-- range: takes at least 31 days and at most as many as actual history, with a default of 31. parameter restricts within that range. 
SELECT TO_CHAR(LEAST(CEIL(SYSDATE - CAST(MIN(begin_interval_time) AS DATE)), GREATEST(31, TO_NUMBER(NVL(TRIM('&&pdtool1_conf_days.'), '31'))))) history_days FROM &&awr_object_prefix.snapshot WHERE '&&diagnostics_pack.' = 'Y' AND dbid = (SELECT dbid FROM v$database);
SELECT TO_CHAR(TO_DATE('&&pdtool1_conf_date_to.', 'YYYY-MM-DD') - TO_DATE('&&pdtool1_conf_date_from.', 'YYYY-MM-DD') + 1) history_days FROM DUAL WHERE '&&pdtool1_conf_date_from.' != 'YYYY-MM-DD' AND '&&pdtool1_conf_date_to.' != 'YYYY-MM-DD';
SELECT '0' history_days FROM DUAL WHERE NVL(TRIM('&&diagnostics_pack.'), 'N') = 'N';
SET TERM OFF;

-- Dates format
DEF pdtool1_date_format = 'YYYY-MM-DD"T"HH24:MI:SS';
DEF pdtool1_timestamp_format = 'YYYY-MM-DD"T"HH24:MI:SS.FF';
DEF pdtool1_timestamp_tz_format = 'YYYY-MM-DD"T"HH24:MI:SS.FFTZH:TZM';

COL pdtool1_date_from NEW_V pdtool1_date_from;
COL pdtool1_date_to NEW_V pdtool1_date_to;
SELECT CASE '&&pdtool1_conf_date_from.' WHEN 'YYYY-MM-DD' THEN TO_CHAR(SYSDATE - &&history_days., '&&pdtool1_date_format.') ELSE '&&pdtool1_conf_date_from.T00:00:00' END pdtool1_date_from FROM DUAL;
SELECT CASE '&&pdtool1_conf_date_to.' WHEN 'YYYY-MM-DD' THEN TO_CHAR(SYSDATE, '&&pdtool1_date_format.') ELSE '&&pdtool1_conf_date_to.T23:59:59' END pdtool1_date_to FROM DUAL;

VAR hist_work_days NUMBER;
VAR hist_days NUMBER;
BEGIN
  :hist_days := ROUND(TO_DATE('&&pdtool1_date_to.', '&&pdtool1_date_format.') - TO_DATE('&&pdtool1_date_from.', '&&pdtool1_date_format.'));
  :hist_work_days := 0;
  FOR i IN 0 .. :hist_days - 1
  LOOP
    IF TO_CHAR(TO_DATE('&&pdtool1_date_from.', '&&pdtool1_date_format.') + i, 'D') BETWEEN TO_NUMBER('&&pdtool1_conf_work_day_from.') AND TO_NUMBER('&&pdtool1_conf_work_day_to.') THEN
      :hist_work_days := :hist_work_days + 1;
      dbms_output.put_line((TO_DATE('&&pdtool1_date_from.', '&&pdtool1_date_format.') + i)||' '||:hist_work_days);
    END IF;
  END LOOP;
END;
/
PRINT hist_work_days;
PRINT hist_days;
COL hist_work_days NEW_V hist_work_days;
SELECT TO_CHAR(:hist_work_days) hist_work_days FROM DUAL;

-- parameter pdtool1_sections: report column, or section, or range of columns or range of sections i.e. 3, 3-4, 3a, 3a-4c, 3-4c, 3c-4 (max length of 5)
VAR pdtool1_sec_from VARCHAR2(2);
VAR pdtool1_sec_to   VARCHAR2(2);
VAR pdtool1_sections VARCHAR2(32);
PRO
BEGIN
  IF '&&pdtool1_sections.' IS NULL THEN -- no sections were selected as per config parameter on pdtool1_00_config.sql or custom file passed
    IF LOWER(NVL(TRIM('&&custom_config_filename.'), 'null')) = 'null' THEN -- 2nd execution parameter is null
      :pdtool1_sections := NULL; -- all sections
    ELSIF LENGTH(TRIM('&&custom_config_filename.')) <= 5 AND TRIM('&&custom_config_filename.') BETWEEN '1' AND '9' THEN -- assume 2nd execution parameter is a section selection
      :pdtool1_sections := LOWER(TRIM('&&custom_config_filename.')); -- second parameter becomes potential sections selection
    ELSE
      :pdtool1_sections := NULL; -- 2nd parameter was indeed a custom config file
    END IF;      
  ELSE -- an actual selection of sections was passed on config parameter
    :pdtool1_sections := LOWER(TRIM('&&pdtool1_sections.'));
  END IF;
  IF LENGTH(:pdtool1_sections) > 5 THEN -- wrong value of parameter passed (too long), then select all sections
    :pdtool1_sec_from := '1a';
    :pdtool1_sec_to := '9z';
  ELSIF LENGTH(:pdtool1_sections) = 5 AND SUBSTR(:pdtool1_sections, 3, 1) = '-' AND SUBSTR(:pdtool1_sections, 1, 2) BETWEEN '1a' AND '9z' AND SUBSTR(:pdtool1_sections, 4, 2) BETWEEN '1a' AND '9z' THEN -- i.e. 1a-7b
    :pdtool1_sec_from := SUBSTR(:pdtool1_sections, 1, 2);
    :pdtool1_sec_to := SUBSTR(:pdtool1_sections, 4, 2);
  ELSIF LENGTH(:pdtool1_sections) = 4 AND SUBSTR(:pdtool1_sections, 3, 1) = '-' AND SUBSTR(:pdtool1_sections, 1, 2) BETWEEN '1a' AND '9z' AND SUBSTR(:pdtool1_sections, 4, 1) BETWEEN '1' AND '9' THEN -- i.e. 3b-7
    :pdtool1_sec_from := SUBSTR(:pdtool1_sections, 1, 2);
    :pdtool1_sec_to := SUBSTR(:pdtool1_sections, 4, 1)||'z';
  ELSIF LENGTH(:pdtool1_sections) = 4 AND SUBSTR(:pdtool1_sections, 2, 1) = '-' AND SUBSTR(:pdtool1_sections, 1, 1) BETWEEN '1' AND '9' AND SUBSTR(:pdtool1_sections, 3, 2) BETWEEN '1a' AND '9z' THEN -- i.e. 3-5b
    :pdtool1_sec_from := SUBSTR(:pdtool1_sections, 1, 1)||'a';
    :pdtool1_sec_to := SUBSTR(:pdtool1_sections, 3, 2);
  ELSIF LENGTH(:pdtool1_sections) = 3 AND SUBSTR(:pdtool1_sections, 2, 1) = '-' AND SUBSTR(:pdtool1_sections, 1, 1) BETWEEN '1' AND '9' AND SUBSTR(:pdtool1_sections, 3, 1) BETWEEN '1' AND '9' THEN -- i.e. 3-5
    :pdtool1_sec_from := SUBSTR(:pdtool1_sections, 1, 1)||'a';
    :pdtool1_sec_to := SUBSTR(:pdtool1_sections, 3, 1)||'z';
  ELSIF LENGTH(:pdtool1_sections) = 2 AND SUBSTR(:pdtool1_sections, 1, 2) BETWEEN '1a' AND '9z' THEN -- i.e. 7b
    :pdtool1_sec_from := SUBSTR(:pdtool1_sections, 1, 2);
    :pdtool1_sec_to := :pdtool1_sec_from;
  ELSIF LENGTH(:pdtool1_sections) = 1 AND SUBSTR(:pdtool1_sections, 1, 1) BETWEEN '1' AND '9' THEN -- i.e. 7
    :pdtool1_sec_from := SUBSTR(:pdtool1_sections, 1, 1)||'a';
    :pdtool1_sec_to := SUBSTR(:pdtool1_sections, 1, 1)||'z';
  ELSE -- wrong value of parameter passed (incorrect syntax), or nothing was passed
    :pdtool1_sec_from := '1a';
    :pdtool1_sec_to := '9z';
  END IF;
END;
/
PRO pdtool1_sec_from pdtool1_sec_to pdtool1_sections
PRINT pdtool1_sec_from;
PRINT pdtool1_sec_to;
PRINT pdtool1_sections;
PRO
COL skip_extras NEW_V skip_extras;
SELECT CASE WHEN :pdtool1_sections IS NOT NULL THEN ' echo skip ' END skip_extras FROM DUAL;
PRO
COL pdtool1_0g NEW_V pdtool1_0g;
COL pdtool1_1a NEW_V pdtool1_1a;
COL pdtool1_1b NEW_V pdtool1_1b;
COL pdtool1_1c NEW_V pdtool1_1c;
COL pdtool1_1d NEW_V pdtool1_1d;
COL pdtool1_1e NEW_V pdtool1_1e;
COL pdtool1_1f NEW_V pdtool1_1f;
COL pdtool1_1g NEW_V pdtool1_1g;
COL pdtool1_2a NEW_V pdtool1_2a;
COL pdtool1_2b NEW_V pdtool1_2b;
COL pdtool1_2c NEW_V pdtool1_2c;
COL pdtool1_2d NEW_V pdtool1_2d;
COL pdtool1_3a NEW_V pdtool1_3a;
COL pdtool1_3b NEW_V pdtool1_3b;
COL pdtool1_3c NEW_V pdtool1_3c;
COL pdtool1_3d NEW_V pdtool1_3d;
COL pdtool1_3e NEW_V pdtool1_3e;
COL pdtool1_3f NEW_V pdtool1_3f;
COL pdtool1_3g NEW_V pdtool1_3g;
COL pdtool1_3h NEW_V pdtool1_3h;
COL pdtool1_3i NEW_V pdtool1_3i;
COL pdtool1_3j NEW_V pdtool1_3j;
COL pdtool1_3k NEW_V pdtool1_3k;
COL pdtool1_4a NEW_V pdtool1_4a;
COL pdtool1_4b NEW_V pdtool1_4b;
COL pdtool1_4c NEW_V pdtool1_4c;
COL pdtool1_4d NEW_V pdtool1_4d;
COL pdtool1_4e NEW_V pdtool1_4e;
COL pdtool1_4f NEW_V pdtool1_4f;
COL pdtool1_4g NEW_V pdtool1_4g;
COL pdtool1_4h NEW_V pdtool1_4h;
COL pdtool1_4i NEW_V pdtool1_4i;
COL pdtool1_4j NEW_V pdtool1_4j;
COL pdtool1_4k NEW_V pdtool1_4k;
COL pdtool1_4l NEW_V pdtool1_4l;
COL pdtool1_5a NEW_V pdtool1_5a;
COL pdtool1_5b NEW_V pdtool1_5b;
COL pdtool1_5c NEW_V pdtool1_5c;
COL pdtool1_5d NEW_V pdtool1_5d;
COL pdtool1_5e NEW_V pdtool1_5e;
COL pdtool1_5f NEW_V pdtool1_5f;
COL pdtool1_5g NEW_V pdtool1_5g;
COL pdtool1_6a NEW_V pdtool1_6a;
COL pdtool1_6b NEW_V pdtool1_6b;
COL pdtool1_6c NEW_V pdtool1_6c;
COL pdtool1_6d NEW_V pdtool1_6d;
COL pdtool1_6e NEW_V pdtool1_6e;
COL pdtool1_6f NEW_V pdtool1_6f;
COL pdtool1_6g NEW_V pdtool1_6g;
COL pdtool1_6h NEW_V pdtool1_6h;
COL pdtool1_6i NEW_V pdtool1_6i;
COL pdtool1_6j NEW_V pdtool1_6j;
COL pdtool1_6k NEW_V pdtool1_6k;
COL pdtool1_6l NEW_V pdtool1_6l;
COL pdtool1_7a NEW_V pdtool1_7a;
COL pdtool1_7b NEW_V pdtool1_7b;
COL pdtool1_7c NEW_V pdtool1_7c;
SELECT CASE '&&pdtool1_conf_incl_tkprof.' WHEN 'Y'                 THEN 'pdtool1_0g_' ELSE ' echo skip ' END pdtool1_0g FROM DUAL;
SELECT CASE WHEN '1a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1a_' ELSE ' echo skip ' END pdtool1_1a FROM DUAL;
SELECT CASE WHEN '1b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1b_' ELSE ' echo skip ' END pdtool1_1b FROM DUAL;
SELECT CASE WHEN '1c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1c_' ELSE ' echo skip ' END pdtool1_1c FROM DUAL;
SELECT CASE WHEN '1d' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1d_' ELSE ' echo skip ' END pdtool1_1d FROM DUAL;
SELECT CASE WHEN '1e' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1e_' ELSE ' echo skip ' END pdtool1_1e FROM DUAL;
SELECT CASE WHEN '1f' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1f_' ELSE ' echo skip ' END pdtool1_1f FROM DUAL;
SELECT CASE WHEN '1g' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_1g_' ELSE ' echo skip ' END pdtool1_1g FROM DUAL;
SELECT CASE WHEN '2a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_2a_' ELSE ' echo skip ' END pdtool1_2a FROM DUAL;
SELECT CASE WHEN '2b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_2b_' ELSE ' echo skip ' END pdtool1_2b FROM DUAL;
SELECT CASE WHEN '2c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_2c_' ELSE ' echo skip ' END pdtool1_2c FROM DUAL;
SELECT CASE WHEN '2d' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_2d_' ELSE ' echo skip ' END pdtool1_2d FROM DUAL;
SELECT CASE WHEN '3a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3a_' ELSE ' echo skip ' END pdtool1_3a FROM DUAL;
SELECT CASE WHEN '3b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3b_' ELSE ' echo skip ' END pdtool1_3b FROM DUAL;
SELECT CASE WHEN '3c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3c_' ELSE ' echo skip ' END pdtool1_3c FROM DUAL;
SELECT CASE WHEN '3d' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3d_' ELSE ' echo skip ' END pdtool1_3d FROM DUAL;
SELECT CASE WHEN '3e' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3e_' ELSE ' echo skip ' END pdtool1_3e FROM DUAL;
SELECT CASE WHEN '3f' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3f_' ELSE ' echo skip ' END pdtool1_3f FROM DUAL;
SELECT CASE WHEN '3g' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3g_' ELSE ' echo skip ' END pdtool1_3g FROM DUAL;
SELECT CASE WHEN '3h' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3h_' ELSE ' echo skip ' END pdtool1_3h FROM DUAL;
SELECT CASE WHEN '3i' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3i_' ELSE ' echo skip ' END pdtool1_3i FROM DUAL;
SELECT CASE WHEN '3j' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3j_' ELSE ' echo skip ' END pdtool1_3j FROM DUAL;
SELECT CASE WHEN '3k' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_3k_' ELSE ' echo skip ' END pdtool1_3k FROM DUAL;
SELECT CASE WHEN '4a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4a_' ELSE ' echo skip ' END pdtool1_4a FROM DUAL;
SELECT CASE WHEN '4b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4b_' ELSE ' echo skip ' END pdtool1_4b FROM DUAL;
SELECT CASE WHEN '4c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4c_' ELSE ' echo skip ' END pdtool1_4c FROM DUAL;
SELECT CASE WHEN '4d' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4d_' ELSE ' echo skip ' END pdtool1_4d FROM DUAL;
SELECT CASE WHEN '4e' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4e_' ELSE ' echo skip ' END pdtool1_4e FROM DUAL;
SELECT CASE WHEN '4f' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4f_' ELSE ' echo skip ' END pdtool1_4f FROM DUAL;
SELECT CASE WHEN '4g' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4g_' ELSE ' echo skip ' END pdtool1_4g FROM DUAL;
SELECT CASE WHEN '4h' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4h_' ELSE ' echo skip ' END pdtool1_4h FROM DUAL;
SELECT CASE WHEN '4i' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4i_' ELSE ' echo skip ' END pdtool1_4i FROM DUAL;
SELECT CASE WHEN '4j' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4j_' ELSE ' echo skip ' END pdtool1_4j FROM DUAL;
SELECT CASE WHEN '4k' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4k_' ELSE ' echo skip ' END pdtool1_4k FROM DUAL;
SELECT CASE WHEN '4l' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_4l_' ELSE ' echo skip ' END pdtool1_4l FROM DUAL;
SELECT CASE WHEN '5a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5a_' ELSE ' echo skip ' END pdtool1_5a FROM DUAL;
SELECT CASE WHEN '5b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5b_' ELSE ' echo skip ' END pdtool1_5b FROM DUAL;
SELECT CASE WHEN '5c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5c_' ELSE ' echo skip ' END pdtool1_5c FROM DUAL;
SELECT CASE WHEN '5d' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5d_' ELSE ' echo skip ' END pdtool1_5d FROM DUAL;
SELECT CASE WHEN '5e' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5e_' ELSE ' echo skip ' END pdtool1_5e FROM DUAL;
SELECT CASE WHEN '5f' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5f_' ELSE ' echo skip ' END pdtool1_5f FROM DUAL;
SELECT CASE WHEN '5g' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_5g_' ELSE ' echo skip ' END pdtool1_5g FROM DUAL;
SELECT CASE WHEN '6a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6a_' ELSE ' echo skip ' END pdtool1_6a FROM DUAL;
SELECT CASE WHEN '6b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6b_' ELSE ' echo skip ' END pdtool1_6b FROM DUAL;
SELECT CASE WHEN '6c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6c_' ELSE ' echo skip ' END pdtool1_6c FROM DUAL;
SELECT CASE WHEN '6d' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6d_' ELSE ' echo skip ' END pdtool1_6d FROM DUAL;
SELECT CASE WHEN '6e' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6e_' ELSE ' echo skip ' END pdtool1_6e FROM DUAL;
SELECT CASE WHEN '6f' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6f_' ELSE ' echo skip ' END pdtool1_6f FROM DUAL;
SELECT CASE WHEN '6g' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6g_' ELSE ' echo skip ' END pdtool1_6g FROM DUAL;
SELECT CASE WHEN '6h' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6h_' ELSE ' echo skip ' END pdtool1_6h FROM DUAL;
SELECT CASE WHEN '6i' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6i_' ELSE ' echo skip ' END pdtool1_6i FROM DUAL;
SELECT CASE WHEN '6j' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6j_' ELSE ' echo skip ' END pdtool1_6j FROM DUAL;
SELECT CASE WHEN '6k' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6k_' ELSE ' echo skip ' END pdtool1_6k FROM DUAL;
SELECT CASE WHEN '6l' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_6l_' ELSE ' echo skip ' END pdtool1_6l FROM DUAL;
SELECT CASE WHEN '7a' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_7a_' ELSE ' echo skip ' END pdtool1_7a FROM DUAL;
SELECT CASE WHEN '7b' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_7b_' ELSE ' echo skip ' END pdtool1_7b FROM DUAL;
SELECT CASE WHEN '7c' BETWEEN :pdtool1_sec_from AND :pdtool1_sec_to THEN 'pdtool1_7c_' ELSE ' echo skip ' END pdtool1_7c FROM DUAL;

-- filename prefix
COL pdtool1_prefix NEW_V pdtool1_prefix;
SELECT CASE WHEN :pdtool1_sec_from = '1a' AND :pdtool1_sec_to = '9z' THEN 'pdtool1' ELSE 'pdtool1_'||:pdtool1_sec_from||'_'||:pdtool1_sec_to END pdtool1_prefix FROM DUAL;

-- esp init
DEF ecr_collection_key = '';

-- dummy
DEF skip_script = 'sql/pdtool1_0f_skip_script.sql ';

-- get dbid
COL pdtool1_dbid NEW_V pdtool1_dbid;
SELECT TRIM(TO_CHAR(dbid)) pdtool1_dbid FROM v$database;

-- get dbmod
COL pdtool1_dbmod NEW_V pdtool1_dbmod;
SELECT LPAD(MOD(dbid,1e6),6,'6') pdtool1_dbmod FROM v$database;

-- get instance number
COL connect_instance_number NEW_V connect_instance_number;
SELECT TO_CHAR(instance_number) connect_instance_number FROM v$instance;

-- get database name (up to 10, stop before first '.', no special characters)
COL database_name_short NEW_V database_name_short FOR A10;
SELECT LOWER(SUBSTR(SYS_CONTEXT('USERENV', 'DB_NAME'), 1, 10)) database_name_short FROM DUAL;
SELECT SUBSTR('&&database_name_short.', 1, INSTR('&&database_name_short..', '.') - 1) database_name_short FROM DUAL;
SELECT TRANSLATE('&&database_name_short.',
'abcdefghijklmnopqrstuvwxyz0123456789-_ ''`~!@#$%&*()=+[]{}\|;:",.<>/?'||CHR(0)||CHR(9)||CHR(10)||CHR(13)||CHR(38),
'abcdefghijklmnopqrstuvwxyz0123456789-_') database_name_short FROM DUAL;

-- get host name (up to 30, stop before first '.', no special characters)
COL host_name_short NEW_V host_name_short FOR A30;
SELECT LOWER(SUBSTR(SYS_CONTEXT('USERENV', 'SERVER_HOST'), 1, 30)) host_name_short FROM DUAL;
SELECT SUBSTR('&&host_name_short.', 1, INSTR('&&host_name_short..', '.') - 1) host_name_short FROM DUAL;
SELECT TRANSLATE('&&host_name_short.',
'abcdefghijklmnopqrstuvwxyz0123456789-_ ''`~!@#$%&*()=+[]{}\|;:",.<>/?'||CHR(0)||CHR(9)||CHR(10)||CHR(13)||CHR(38),
'abcdefghijklmnopqrstuvwxyz0123456789-_') host_name_short FROM DUAL;

-- get host name (up to 30, stop before first '.', no special characters)
DEF esp_host_name_short = '';
COL esp_host_name_short NEW_V esp_host_name_short FOR A30;
SELECT LOWER(SUBSTR(SYS_CONTEXT('USERENV', 'SERVER_HOST'), 1, 30)) esp_host_name_short FROM DUAL;
SELECT SUBSTR('&&esp_host_name_short.', 1, INSTR('&&esp_host_name_short..', '.') - 1) esp_host_name_short FROM DUAL;
SELECT TRANSLATE('&&esp_host_name_short.',
'abcdefghijklmnopqrstuvwxyz0123456789-_ ''`~!@#$%&*()=+[]{}\|;:",.<>/?'||CHR(0)||CHR(9)||CHR(10)||CHR(13)||CHR(38),
'abcdefghijklmnopqrstuvwxyz0123456789-_') esp_host_name_short FROM DUAL;

-- get host hash
COL host_hash NEW_V host_hash;
SELECT LPAD(ORA_HASH(SYS_CONTEXT('USERENV', 'SERVER_HOST'),999999),6,'6') host_hash FROM DUAL;

-- get collection date
DEF esp_collection_yyyymmdd = '';
COL esp_collection_yyyymmdd NEW_V esp_collection_yyyymmdd FOR A8;
SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') esp_collection_yyyymmdd FROM DUAL;

-- esp init
DEF ecr_collection_key = '';

-- setup
DEF main_table = '';
DEF title = '';
DEF title_no_spaces = '';
DEF title_suffix = '';
-- timestamp on filename
COL pdtool1_file_time NEW_V pdtool1_file_time FOR A20;
SELECT TO_CHAR(SYSDATE, 'YYYYMMDD_HH24MI') pdtool1_file_time FROM DUAL;
DEF common_pdtool1_prefix = '&&pdtool1_prefix._&&pdtool1_dbmod.';
DEF pdtool1_main_report = '00001_&&common_pdtool1_prefix._index';
DEF pdtool1_log = '00002_&&common_pdtool1_prefix._log';
DEF pdtool1_log2 = '00003_&&common_pdtool1_prefix._log2';
DEF pdtool1_log3 = '00004_&&common_pdtool1_prefix._log3';
DEF pdtool1_tkprof = '00005_&&common_pdtool1_prefix._tkprof';
--DEF pdtool1_main_filename = '&&common_pdtool1_prefix._&&host_hash.';
COL pdtool1_main_filename NEW_V pdtool1_main_filename;
SELECT '&&common_pdtool1_prefix.'||(CASE '&&pdtool1_conf_incl_dbname_file.' WHEN 'Y' THEN '_&&database_name_short.' ELSE '_&&host_hash.' END) pdtool1_main_filename FROM DUAL
/
COL pdtool1_zip_filename NEW_V pdtool1_zip_filename;
SELECT '&&pdtool1_main_filename._&&pdtool1_file_time.' pdtool1_zip_filename FROM DUAL
/
DEF pdtool1_tracefile_identifier = '&&common_pdtool1_prefix.';
DEF pdtool1_tar_filename = '00008_&&pdtool1_zip_filename.';
DEF pdtool1_mv_host_command = '';

-- mont info
HOS dcli -g ~/dbs_group -l oracle mount >> &&pdtool1_log3..txt

-- Exadata
ALTER SESSION SET "_serial_direct_read" = ALWAYS;
ALTER SESSION SET "_small_table_threshold" = 1001;
-- nls
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ".,";
ALTER SESSION SET NLS_DATE_FORMAT = '&&pdtool1_date_format.';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT = '&&pdtool1_timestamp_format.';
ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT = '&&pdtool1_timestamp_tz_format.';
-- adding to prevent slow access to ASH with non default NLS settings
ALTER SESSION SET NLS_SORT = 'BINARY';
ALTER SESSION SET NLS_COMP = 'BINARY';
-- workaround fairpoint
COL db_vers_ofe NEW_V db_vers_ofe;
SELECT TRIM('.' FROM TRIM('0' FROM version)) db_vers_ofe FROM v$instance;
ALTER SESSION SET optimizer_features_enable = '&&db_vers_ofe.';
-- to work around bug 12672969
ALTER SESSION SET "_optimizer_order_by_elimination_enabled"=false; 
-- workaround Siebel
ALTER SESSION SET optimizer_index_cost_adj = 100;
--ALTER SESSION SET optimizer_dynamic_sampling = 2;
ALTER SESSION SET "_always_semi_join" = CHOOSE;
ALTER SESSION SET "_and_pruning_enabled" = TRUE;
ALTER SESSION SET "_subquery_pruning_enabled" = TRUE;
-- workaround bug 19567916
ALTER SESSION SET "_optimizer_aggr_groupby_elim" = FALSE;
-- workaround 
ALTER SESSION SET "_gby_hash_aggregation_enabled" = TRUE;
ALTER SESSION SET "_hash_join_enabled" = TRUE;
ALTER SESSION SET "_optim_peek_user_binds" = TRUE;
ALTER SESSION SET "_optimizer_skip_scan_enabled" = TRUE;
ALTER SESSION SET "_optimizer_sortmerge_join_enabled" = TRUE;
ALTER SESSION SET cursor_sharing = EXACT;
ALTER SESSION SET db_file_multiblock_read_count = 128;
ALTER SESSION SET optimizer_index_caching = 0;
ALTER SESSION SET optimizer_index_cost_adj = 100;
-- workaround 21150273 and 20465582
ALTER SESSION SET optimizer_dynamic_sampling = 0;
ALTER SESSION SET "_optimizer_dsdir_usage_control"=0;
ALTER SESSION SET "_sql_plan_directive_mgmt_control" = 0;

-- tracing script in case it takes long to execute so we can diagnose it
ALTER SESSION SET MAX_DUMP_FILE_SIZE = '1G';
ALTER SESSION SET TRACEFILE_IDENTIFIER = "&&pdtool1_tracefile_identifier.";
--ALTER SESSION SET STATISTICS_LEVEL = 'ALL';
BEGIN
  IF TO_NUMBER('&&sql_trace_level.') > 0 THEN
    EXECUTE IMMEDIATE 'ALTER SESSION SET EVENTS ''10046 TRACE NAME CONTEXT FOREVER, LEVEL &&sql_trace_level.''';
  END IF;
END;
/
-- esp collection. note: skip if executing for one section
@&&skip_diagnostics.&&skip_extras.sql/esp_master.sql
SET TERM OFF; 

-- nls (2nd time as esp may change them)
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ".,";
ALTER SESSION SET NLS_DATE_FORMAT = '&&pdtool1_date_format.';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT = '&&pdtool1_timestamp_format.';
ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT = '&&pdtool1_timestamp_tz_format.';

-- initialization
--COL row_num NEW_V row_num FOR 9999999 HEA '#' PRI;
COL row_num NEW_V row_num HEA '#' PRI;
--COL nbsp NEW_V nbsp;
--SELECT CHR(38)||'nbsp;' nbsp FROM DUAL;

-- get rdbms version
COL db_version NEW_V db_version;
SELECT version db_version FROM v$instance;

-- skip
DEF skip_10g_column = '';
COL skip_10g_column NEW_V skip_10g_column;
DEF skip_10g_script = '';
COL skip_10g_script NEW_V skip_10g_script;
SELECT ' -- skip 10g ' skip_10g_column, ' echo skip 10g ' skip_10g_script FROM v$instance WHERE version LIKE '10%';
DEF skip_11g_column = '';
COL skip_11g_column NEW_V skip_11g_column;
DEF skip_11g_script = '';
COL skip_11g_script NEW_V skip_11g_script;
SELECT ' -- skip 11g ' skip_11g_column, ' echo skip 11g ' skip_11g_script FROM v$instance WHERE version LIKE '11%';
DEF skip_11r1_column = '';
COL skip_11r1_column NEW_V skip_11r1_column;
DEF skip_11r1_script = '';
COL skip_11r1_script NEW_V skip_11r1_script;
SELECT ' -- skip 11gR1 ' skip_11r1_column, ' echo skip 11gR1 ' skip_11r1_script FROM v$instance WHERE version LIKE '11.1%';

-- get average number of CPUs
COL avg_cpu_count NEW_V avg_cpu_count FOR A6;
SELECT TO_CHAR(ROUND(AVG(TO_NUMBER(value)),1)) avg_cpu_count FROM gv$system_parameter2 WHERE name = 'cpu_count';

-- get total number of CPUs
COL sum_cpu_count NEW_V sum_cpu_count FOR A3;
SELECT TO_CHAR(SUM(TO_NUMBER(value))) sum_cpu_count FROM gv$system_parameter2 WHERE name = 'cpu_count';

-- get average number of Cores
COL avg_core_count NEW_V avg_core_count FOR A5;
SELECT TO_CHAR(ROUND(AVG(TO_NUMBER(value)),1)) avg_core_count FROM gv$osstat WHERE stat_name = 'NUM_CPU_CORES';

-- get average number of Threads
COL avg_thread_count NEW_V avg_thread_count FOR A6;
SELECT TO_CHAR(ROUND(AVG(TO_NUMBER(value)),1)) avg_thread_count FROM gv$osstat WHERE stat_name = 'NUM_CPUS';

-- get number of Hosts
COL hosts_count NEW_V hosts_count FOR A2;
SELECT TO_CHAR(COUNT(DISTINCT inst_id)) hosts_count FROM gv$osstat WHERE stat_name = 'NUM_CPU_CORES';

-- get cores_threads_hosts
COL cores_threads_hosts NEW_V cores_threads_hosts;
SELECT CASE TO_NUMBER('&&hosts_count.') WHEN 1 THEN 'cores:&&avg_core_count. threads:&&avg_thread_count.' ELSE 'cores:&&avg_core_count.(avg) threads:&&avg_thread_count.(avg) hosts:&&hosts_count.' END cores_threads_hosts FROM DUAL;

-- get block_size
COL database_block_size NEW_V database_block_size;
SELECT TRIM(TO_NUMBER(value)) database_block_size FROM v$system_parameter2 WHERE name = 'db_block_size';

-- determine if rac or single instance (null means rac)
COL is_single_instance NEW_V is_single_instance FOR A1;
SELECT CASE COUNT(*) WHEN 1 THEN 'Y' END is_single_instance FROM gv$instance;

-- snapshot ranges
SELECT '0' history_days FROM DUAL WHERE TRIM('&&history_days.') IS NULL;
COL tool_sysdate NEW_V tool_sysdate;
SELECT TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') tool_sysdate FROM DUAL;
COL between_times NEW_V between_times;
COL between_dates NEW_V between_dates;
SELECT ', between &&pdtool1_date_from. and &&pdtool1_date_to.' between_dates FROM DUAL;
COL minimum_snap_id NEW_V minimum_snap_id;
SELECT NVL(TO_CHAR(MIN(snap_id)), '0') minimum_snap_id FROM &&awr_object_prefix.snapshot WHERE '&&diagnostics_pack.' = 'Y' AND dbid = &&pdtool1_dbid. AND begin_interval_time > TO_DATE('&&pdtool1_date_from.', '&&pdtool1_date_format.');
SELECT '-1' minimum_snap_id FROM DUAL WHERE TRIM('&&minimum_snap_id.') IS NULL;
COL maximum_snap_id NEW_V maximum_snap_id;
SELECT NVL(TO_CHAR(MAX(snap_id)), '&&minimum_snap_id.') maximum_snap_id FROM &&awr_object_prefix.snapshot WHERE '&&diagnostics_pack.' = 'Y' AND dbid = &&pdtool1_dbid. AND end_interval_time < TO_DATE('&&pdtool1_date_to.', '&&pdtool1_date_format.');
SELECT '-1' maximum_snap_id FROM DUAL WHERE TRIM('&&maximum_snap_id.') IS NULL;

-- e
DEF pdtool1_eadam_snaps = '-666';

-- ebs
DEF ebs_release = '';
DEF ebs_system_name = '';
COL ebs_release NEW_V ebs_release;
COL ebs_system_name NEW_V ebs_system_name;
SELECT release_name ebs_release, applications_system_name ebs_system_name FROM applsys.fnd_product_groups WHERE ROWNUM = 1;

-- siebel
DEF siebel_schema = 'siebel_schema';
DEF siebel_app_ver = '';
COL siebel_schema NEW_V siebel_schema;
COL siebel_app_ver NEW_V siebel_app_ver;
SELECT owner siebel_schema FROM sys.dba_tab_columns WHERE table_name = 'S_REPOSITORY' AND column_name = 'ROW_ID' AND data_type = 'VARCHAR2' AND ROWNUM = 1;
SELECT /* ignore if it fails to parse */ app_ver siebel_app_ver FROM &&siebel_schema..s_app_ver WHERE ROWNUM = 1;

-- psft
DEF psft_schema = 'psft_schema';
DEF psft_tools_rel = '';
COL psft_schema NEW_V psft_schema;
COL psft_tools_rel NEW_V psft_tools_rel;
SELECT owner psft_schema FROM sys.dba_tab_columns WHERE table_name = 'PSSTATUS' AND column_name = 'TOOLSREL' AND data_type = 'VARCHAR2' AND ROWNUM = 1;
SELECT /* ignore if it fails to parse */ toolsrel psft_tools_rel FROM &&psft_schema..psstatus WHERE ROWNUM = 1;

-- inclusion config determine skip flags
COL pdtool1_skip_html NEW_V pdtool1_skip_html;
COL pdtool1_skip_xml NEW_V pdtool1_skip_xml;
COL pdtool1_skip_text NEW_V pdtool1_skip_text;
COL pdtool1_skip_csv  NEW_V pdtool1_skip_csv;
COL pdtool1_skip_line NEW_V pdtool1_skip_line;
COL pdtool1_skip_pie  NEW_V pdtool1_skip_pie;
COL pdtool1_skip_bar  NEW_V pdtool1_skip_bar;
COL pdtool1_skip_metadata  NEW_V pdtool1_skip_metadata;
SELECT CASE '&&pdtool1_conf_incl_html.'     WHEN 'N' THEN ' echo skip html ' END pdtool1_skip_html     FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_xml.'      WHEN 'N' THEN ' echo skip xml '  END pdtool1_skip_xml      FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_text.'     WHEN 'N' THEN ' echo skip text ' END pdtool1_skip_text     FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_csv.'      WHEN 'N' THEN ' echo skip csv '  END pdtool1_skip_csv      FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_line.'     WHEN 'N' THEN ' echo skip line ' END pdtool1_skip_line     FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_pie.'      WHEN 'N' THEN ' echo skip pie '  END pdtool1_skip_pie      FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_bar.'      WHEN 'N' THEN ' echo skip bar '  END pdtool1_skip_bar      FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_metadata.' WHEN 'N' THEN ' echo skip meta ' END pdtool1_skip_metadata FROM DUAL;

-- inclusion of some diagnostics from memory (not from history)
COL pdtool1_skip_ash_mem NEW_V pdtool1_skip_ash_mem;
COL pdtool1_skip_sql_mon NEW_V pdtool1_skip_sql_mon;
COL pdtool1_skip_stat_mem NEW_V pdtool1_skip_stat_mem;
COL pdtool1_skip_px_mem NEW_V pdtool1_skip_px_mem;
SELECT CASE '&&pdtool1_conf_incl_ash_mem.'  WHEN 'N' THEN ' echo skip ash mem '  END pdtool1_skip_ash_mem  FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_sql_mon.'  WHEN 'N' THEN ' echo skip sql mon '  END pdtool1_skip_sql_mon  FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_stat_mem.' WHEN 'N' THEN ' echo skip stat mem ' END pdtool1_skip_stat_mem FROM DUAL;
SELECT CASE '&&pdtool1_conf_incl_px_mem.'   WHEN 'N' THEN ' echo skip px mem '   END pdtool1_skip_px_mem   FROM DUAL;

DEF top_level_hints = ' NO_MERGE ';
DEF sq_fact_hints = ' MATERIALIZE NO_MERGE ';
DEF ds_hint = ' DYNAMIC_SAMPLING(4) ';
DEF ash_hints1 = ' FULL(h.ash) FULL(h.evt) FULL(h.sn) USE_HASH(h.sn h.ash h.evt) ';
DEF ash_hints2 = ' FULL(h.INT$&&awr_hist_prefix.ACT_SESS_HISTORY.sn) FULL(h.INT$&&awr_hist_prefix.ACT_SESS_HISTORY.ash) FULL(h.INT$&&awr_hist_prefix.ACT_SESS_HISTORY.evt) ';
DEF ash_hints3 = ' USE_HASH(h.INT$&&awr_hist_prefix.ACT_SESS_HISTORY.sn h.INT$&&awr_hist_prefix.ACT_SESS_HISTORY.ash h.INT$&&awr_hist_prefix.ACT_SESS_HISTORY.evt) ';
DEF def_max_rows = '10000';
DEF max_rows = '1e4';
DEF exclusion_list = "('ANONYMOUS','APEX_030200','APEX_040000','APEX_SSO','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS')";
DEF exclusion_list2 = "('SI_INFORMTN_SCHEMA','SQLTXADMIN','SQLTXPLAIN','SYS','SYSMAN','SYSTEM','TRCANLZR','WMSYS','XDB','XS$NULL','PERFSTAT','STDBYPERF','MGDSYS','OJVMSYS')";
DEF skip_html = '';
DEF skip_text = '';
DEF skip_csv = '';
DEF skip_lch = 'Y';
DEF skip_lch2 = 'Y';
DEF skip_pch = 'Y';
DEF skip_bch = 'Y';
DEF skip_all = '';
DEF abstract = '';
DEF abstract2 = '';
DEF foot = '';
DEF abstract_uom = 'Memory is accounted as power of two (binary) while storage and network traffic as power of ten (decimal). <br />';
--DEF sql_text = '';
COL sql_text FOR A100;
DEF chartype = '';
DEF stacked = '';
--DEF haxis = '&&db_version. dbmod:&&pdtool1_dbmod. host:&&host_hash. (avg cpu_count: &&avg_cpu_count.)';
DEF haxis = '&&db_version. &&cores_threads_hosts.';
DEF vaxis = '';
DEF vbaseline = '';
DEF bar_height = '65%';
COL tit_01 NEW_V tit_01;
COL tit_02 NEW_V tit_02;
COL tit_03 NEW_V tit_03;
COL tit_04 NEW_V tit_04;
COL tit_05 NEW_V tit_05;
COL tit_06 NEW_V tit_06;
COL tit_07 NEW_V tit_07;
COL tit_08 NEW_V tit_08;
COL tit_09 NEW_V tit_09;
COL tit_10 NEW_V tit_10;
COL tit_11 NEW_V tit_11;
COL tit_12 NEW_V tit_12;
COL tit_13 NEW_V tit_13;
COL tit_14 NEW_V tit_14;
COL tit_15 NEW_V tit_15;
DEF tit_01 = '';
DEF tit_02 = '';
DEF tit_03 = '';
DEF tit_04 = '';
DEF tit_05 = '';
DEF tit_06 = '';
DEF tit_07 = '';
DEF tit_08 = '';
DEF tit_09 = '';
DEF tit_10 = '';
DEF tit_11 = '';
DEF tit_12 = '';
DEF tit_13 = '';
DEF tit_14 = '';
DEF tit_15 = '';
DEF wait_class_01 = '';
DEF event_name_01 = '';
DEF wait_class_02 = '';
DEF event_name_02 = '';
DEF wait_class_03 = '';
DEF event_name_03 = '';
DEF wait_class_04 = '';
DEF event_name_04 = '';
DEF wait_class_05 = '';
DEF event_name_05 = '';
DEF wait_class_06 = '';
DEF event_name_06 = '';
DEF wait_class_07 = '';
DEF event_name_07 = '';
DEF wait_class_08 = '';
DEF event_name_08 = '';
DEF wait_class_09 = '';
DEF event_name_09 = '';
DEF wait_class_10 = '';
DEF event_name_10 = '';
DEF wait_class_11 = '';
DEF event_name_11 = '';
DEF wait_class_12 = '';
DEF event_name_12 = '';
DEF exadata = '';
DEF max_col_number = '1';
DEF column_number = '1';
COL recovery NEW_V recovery;
SELECT CHR(38)||' recovery' recovery FROM DUAL;
-- this above is to handle event "RMAN backup & recovery I/O"
COL skip_html NEW_V skip_html;
COL skip_text NEW_V skip_text;
COL skip_csv NEW_V skip_csv;
COL skip_lch NEW_V skip_lch;
COL skip_lch2 NEW_V skip_lch2;
COL skip_pch NEW_V skip_pch;
COL skip_bch NEW_V skip_bch;
COL skip_all NEW_V skip_all;
COL dummy_01 NOPRI;
COL dummy_02 NOPRI;
COL dummy_03 NOPRI;
COL dummy_04 NOPRI;
COL dummy_05 NOPRI;
COL dummy_06 NOPRI;
COL dummy_07 NOPRI;
COL dummy_08 NOPRI;
COL dummy_09 NOPRI;
COL dummy_10 NOPRI;
COL dummy_11 NOPRI;
COL dummy_12 NOPRI;
COL dummy_13 NOPRI;
COL dummy_14 NOPRI;
COL dummy_15 NOPRI;
COL pdtool1_time_stamp NEW_V pdtool1_time_stamp FOR A20;
DEF total_hours = '';
SELECT TO_CHAR(SYSDATE, '&&pdtool1_date_format.') pdtool1_time_stamp FROM DUAL;
COL hh_mm_ss NEW_V hh_mm_ss FOR A8;
COL title_no_spaces NEW_V title_no_spaces;
COL spool_filename NEW_V spool_filename;
COL one_spool_filename NEW_V one_spool_filename;
COL report_sequence NEW_V report_sequence;
--VAR row_count NUMBER;
VAR sql_text CLOB;
VAR sql_text_backup CLOB;
VAR sql_text_backup2 CLOB;
VAR sql_text_display CLOB;
VAR file_seq NUMBER;
EXEC :file_seq := 8;
VAR repo_seq NUMBER;
EXEC :repo_seq := 1;
SELECT TO_CHAR(:repo_seq) report_sequence FROM DUAL;
VAR get_time_t0 NUMBER;
VAR get_time_t1 NUMBER;
DEF current_time = '';
COL pdtool1_tuning_pack_for_pdmoni NEW_V pdtool1_tuning_pack_for_pdmoni;
COL skip_pdmoni_exec NEW_V skip_pdmoni_exec;
COL pdtool1_sql_text_100 NEW_V pdtool1_sql_text_100;
DEF exact_matching_signature = '';
DEF force_matching_signature = '';
—- this gives you two level of “indirection”, aka it goes into PL/SQL that dumps a script that is later on executed 
—- I use this for bar charts on pdtool11
--DEF wait_class_colors = 'CASE wait_class WHEN ''''''''CPU'''''''' THEN ''''''''34CF27'''''''' WHEN ''''''''Scheduler'''''''' THEN ''''''''9FFA9D'''''''' WHEN ''''''''User I/O'''''''' THEN ''''''''0252D7'''''''' WHEN ''''''''System I/O'''''''' THEN ''''''''1E96DD'''''''' ';
--DEF wait_class_colors2 = ' WHEN ''''''''Concurrency'''''''' THEN ''''''''871C12'''''''' WHEN ''''''''Application'''''''' THEN ''''''''C42A05'''''''' WHEN ''''''''Commit'''''''' THEN ''''''''EA6A05'''''''' WHEN ''''''''Configuration'''''''' THEN ''''''''594611''''''''  ';
--DEF wait_class_colors3 = ' WHEN ''''''''Administrative'''''''' THEN ''''''''75763E''''''''  WHEN ''''''''Network'''''''' THEN ''''''''989779'''''''' WHEN ''''''''Other'''''''' THEN ''''''''F571A0'''''''' ';
--DEF wait_class_colors4 = ' WHEN ''''''''Cluster'''''''' THEN ''''''''CEC3B5'''''''' WHEN ''''''''Queueing'''''''' THEN ''''''''C6BAA5'''''''' ELSE ''''''''000000'''''''' END';
—- I use this for bar charts on pdtool1
--DEF wait_class_colors = " CASE wait_class WHEN ''ON CPU'' THEN ''34CF27'' WHEN ''Scheduler'' THEN ''9FFA9D'' WHEN ''User I/O'' THEN ''0252D7'' WHEN ''System I/O'' THEN ''1E96DD'' ";
--DEF wait_class_colors2 = " WHEN ''Concurrency'' THEN ''871C12'' WHEN ''Application'' THEN ''C42A05'' WHEN ''Commit'' THEN ''EA6A05'' WHEN ''Configuration'' THEN ''594611''  ";
--DEF wait_class_colors3 = " WHEN ''Administrative'' THEN ''75763E''  WHEN ''Network'' THEN ''989779'' WHEN ''Other'' THEN ''F571A0'' ";
--DEF wait_class_colors4 = " WHEN ''Cluster'' THEN ''CEC3B5'' WHEN ''Queueing'' THEN ''C6BAA5'' ELSE ''000000'' END ";
DEF wait_class_colors = " CASE wait_class WHEN 'ON CPU' THEN '34CF27' WHEN 'Scheduler' THEN '9FFA9D' WHEN 'User I/O' THEN '0252D7' WHEN 'System I/O' THEN '1E96DD' ";
DEF wait_class_colors2 = " WHEN 'Concurrency' THEN '871C12' WHEN 'Application' THEN 'C42A05' WHEN 'Commit' THEN 'EA6A05' WHEN 'Configuration' THEN '594611'  ";
DEF wait_class_colors3 = " WHEN 'Administrative' THEN '75763E'  WHEN 'Network' THEN '989779' WHEN 'Other' THEN 'F571A0' ";
DEF wait_class_colors4 = " WHEN 'Cluster' THEN 'CEC3B5' WHEN 'Queueing' THEN 'C6BAA5' ELSE '000000' END ";
—-this one gives you one level of indirection indirection AND it builds the string in the way the line charts needs it (color: ‘#FFFFFF’) 
--DEF wait_class_colors_s = 'CASE wait_class WHEN ''''CPU'''' THEN ''''color: ''''''''#34CF27'''''''''''' WHEN ''''Scheduler'''' THEN ''''color: ''''''''#9FFA9D'''''''''''' WHEN ''''User I/O'''' THEN ''''color: ''''''''#0252D7'''''''''''' WHEN ''''System I/O'''' THEN ''''color: ''''''''#1E96DD'''''''''''' ';
--DEF wait_class_colors2_s = ' WHEN ''''Concurrency'''' THEN ''''color: ''''''''#871C12'''''''''''' WHEN ''''Application'''' THEN ''''color: ''''''''#C42A05'''''''''''' WHEN ''''Commit'''' THEN ''''color: ''''''''#EA6A05'''''''''''' WHEN ''''Configuration'''' THEN ''''color: ''''''''#594611''''''''''''  ';
--DEF wait_class_colors3_s = ' WHEN ''''Administrative'''' THEN ''''color: ''''''''#75763E''''''''''''  WHEN ''''Network'''' THEN ''''color: ''''''''#989779'''''''''''' WHEN ''''Other'''' THEN ''''color: ''''''''#F571A0'''''''''''' ';
--DEF wait_class_colors4_s = ' WHEN ''''Cluster'''' THEN ''''color: ''''''''#CEC3B5'''''''''''' WHEN ''''Queueing'''' THEN ''''color: ''''''''#C6BAA5'''''''''''' ELSE ''''color: ''''''''#000000'''''''''''' END';
--
COL series_01 NEW_V series_01; 
COL series_02 NEW_V series_02; 
COL series_03 NEW_V series_03; 
COL series_04 NEW_V series_04; 
COL series_05 NEW_V series_05; 
COL series_06 NEW_V series_06; 
COL series_07 NEW_V series_07; 
COL series_08 NEW_V series_08; 
COL series_09 NEW_V series_09; 
COL series_10 NEW_V series_10; 
COL series_11 NEW_V series_11; 
COL series_12 NEW_V series_12; 
COL series_13 NEW_V series_13; 
COL series_14 NEW_V series_14; 
COL series_15 NEW_V series_15; 
DEF series_01 = ''
DEF series_02 = ''
DEF series_03 = ''
DEF series_04 = ''
DEF series_05 = ''
DEF series_06 = ''
DEF series_07 = ''
DEF series_08 = ''
DEF series_09 = ''
DEF series_10 = ''
DEF series_11 = ''
DEF series_12 = ''
DEF series_13 = ''
DEF series_14 = ''
DEF series_15 = ''

-- get udump directory path
COL pdtool1_udump_path NEW_V pdtool1_udump_path FOR A500;
SELECT value||DECODE(INSTR(value, '/'), 0, '\', '/') pdtool1_udump_path FROM v$parameter2 WHERE name = 'user_dump_dest';
SELECT value||DECODE(INSTR(value, '/'), 0, '\', '/') pdtool1_udump_path FROM v$diag_info WHERE name = 'Diag Trace';

-- get pid
COL pdtool1_spid NEW_V pdtool1_spid FOR A5;
SELECT TO_CHAR(spid) pdtool1_spid FROM v$session s, v$process p WHERE s.sid = SYS_CONTEXT('USERENV', 'SID') AND p.addr = s.paddr;

SET TERM OFF; 
SET HEA ON; 
SET LIN 32767; 
SET NEWP NONE; 
SET PAGES &&def_max_rows.; 
SET LONG 32000000; 
SET LONGC 2000; 
SET WRA ON; 
SET TRIMS ON; 
SET TRIM ON; 
SET TI OFF; 
SET TIMI OFF; 
SET ARRAY 1000; 
SET NUM 20; 
SET SQLBL ON; 
SET BLO .; 
SET RECSEP OFF;
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
DEF
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
SPO OFF;

-- log header
SPO &&pdtool1_log..txt;
PRO begin log
PRO
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
HOS ps -ef 
DEF;
PRO Parameters
COL sid FOR A40;
COL name FOR A40;
COL value FOR A50;
COL display_value FOR A50;
COL update_comment NOPRI;
SELECT *
  FROM v$spparameter
 WHERE isspecified = 'TRUE'
 ORDER BY
       name,
       sid,
       ordinal;
COL sid CLE;
COL name CLE;
COL value CLE;
COL display_value CLE;
COL update_comment CLE;
SHOW PARAMETERS;
SELECT 'Tool Execution Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_main_time0) / 100 / 3600, 3) tool_exec_hours FROM DUAL
/
SPO OFF;

-- processes
SET TERM ON;
HOS ps -ef >> &&pdtool1_log3..txt

-- main header
COL report_dbname NEW_V report_dbname;
SELECT CASE '&&pdtool1_conf_incl_dbname_index.' WHEN 'Y' THEN 'Database:&&database_name_short..' END report_dbname FROM DUAL
/
SPO &&pdtool1_main_report..html;
@@pdtool1_0d_html_header.sql
PRO </head>
PRO <body>

PRO <h1><em>&&pdtool1_conf_tool_page.pdtool1</a></em> &&pdtool1_vYYNN.: PDTool: Database Audit/Health-Check tool (By FatDBA) &&db_version. &&pdtool1_conf_all_pages_logo.</h1>
PRO
PRO <pre>
--PRO version:&&db_version. dbmod:&&pdtool1_dbmod. host:&&host_hash. license:&&license_pack. days:&&history_days. This report covers the time interval between &&pdtool1_date_from. and &&pdtool1_date_to. Timestamp: &&pdtool1_time_stamp.
PRO &&report_dbname. License:&&license_pack.. This report covers the time interval between &&pdtool1_date_from. and &&pdtool1_date_to.. Days:&&history_days.. Timestamp:&&pdtool1_time_stamp..
PRO </pre>
PRO
SPO OFF;

-- ash
HOS zip -m &&pdtool1_zip_filename. pre_check_*.txt >> &&pdtool1_log3..txt
HOS zip -m &&pdtool1_zip_filename. verify_stats_wr_sys_*.txt >> &&pdtool1_log3..txt
-- osw
--HOS zip -r osw_&&esp_host_name_short..zip `ps -ef | grep OSW | grep FM | awk -F 'OSW' '{print $2}' | cut -f 3 -d ' '`
--HOS zip -mT &&pdtool1_zip_filename. osw_&&esp_host_name_short..zip
-- zip esp into main
HOS zip -m &&pdtool1_zip_filename. escp_output_&&esp_host_name_short._&&esp_collection_yyyymmdd..zip >> &&pdtool1_log3..txt
-- zip other files
HOS zip -m &&pdtool1_zip_filename. 00000_readme_first_&&my_sid..txt >> &&pdtool1_log3..txt
HOS zip -j &&pdtool1_zip_filename. js/sorttable.js >> &&pdtool1_log3..txt
HOS zip -j &&pdtool1_zip_filename. js/pdtool1_img.jpg >> &&pdtool1_log3..txt
HOS zip -j &&pdtool1_zip_filename. js/pdtool1_favicon.ico >> &&pdtool1_log3..txt
