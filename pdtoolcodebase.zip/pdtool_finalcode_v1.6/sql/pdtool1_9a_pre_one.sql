-- setup
SET VER OFF; 
SET FEED OFF; 
SET ECHO OFF;
SELECT TO_CHAR(SYSDATE, '&&pdtool1_date_format.') pdtool1_time_stamp FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'HH24:MI:SS') hh_mm_ss FROM DUAL;
SELECT REPLACE(TRANSLATE('&&title.',
'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ''`~!@#$%^*()-_=+[]{}\|;:",.<>/?'||CHR(0)||CHR(9)||CHR(10)||CHR(13)||CHR(38),
'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz0123456789_'), '__', '_') title_no_spaces FROM DUAL;
SELECT '&&common_pdtool1_prefix._&&section_id._&&report_sequence._&&title_no_spaces.' spool_filename FROM DUAL;
SET HEA OFF;
SET TERM ON;

-- cleanup
SELECT '0' row_num FROM DUAL;

-- log and watchdog
SPO &&pdtool1_log..txt APP;
COL pdtool1_bypass NEW_V pdtool1_bypass;
SELECT ' echo timeout ' pdtool1_bypass FROM DUAL WHERE (DBMS_UTILITY.GET_TIME - :pdtool1_time0) / 100  >  :pdtool1_max_seconds
/
SELECT 'Elapsed Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_time0) / 100 / 3600, 3) FROM DUAL
/
PRO
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO
PRO &&hh_mm_ss. &&section_id. "&&section_name."
PRO &&hh_mm_ss. &&title.&&title_suffix.

-- count
PRINT sql_text;
--SELECT '0' row_num FROM DUAL;
PRO &&hh_mm_ss. &&section_id..&&report_sequence.
EXEC :sql_text_display := REPLACE(REPLACE(TRIM(CHR(10) FROM :sql_text)||';', '<', CHR(38)||'lt;'), '>', CHR(38)||'gt;');
SET TIMI ON;
SET SERVEROUT ON;
SET SERVEROUT ON SIZE 1000000;
SET SERVEROUT ON SIZE UNL;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Elapsed Hours so far: '||ROUND((DBMS_UTILITY.GET_TIME - :pdtool1_time0) / 100 / 3600, 3)||CHR(10));
END;
/
SET TIMI OFF;
SET SERVEROUT OFF;
PRO
SPO OFF;
HOS zip &&pdtool1_zip_filename. &&pdtool1_log..txt >> &&pdtool1_log3..txt

-- spools query
SPO &&common_pdtool1_prefix._query.sql;
SELECT 'SELECT TO_CHAR(ROWNUM) row_num, v0.* FROM /* &&section_id..&&report_sequence. */ ('||CHR(10)||TRIM(CHR(10) FROM :sql_text)||CHR(10)||') v0 WHERE ROWNUM <= &&max_rows.' FROM DUAL;
SPO OFF;
SET HEA ON;
GET &&common_pdtool1_prefix._query.sql

-- update main report
SET TERM OFF;
SPO &&pdtool1_main_report..html APP;
PRO <li title="&&main_table.">&&pdtool1_bypass.&&title.
SPO OFF;
HOS zip &&pdtool1_zip_filename. &&pdtool1_main_report..html >> &&pdtool1_log3..txt

-- dummy call
COL pdtool1_prev_sql_id NEW_V pdtool1_prev_sql_id NOPRI;
COL pdtool1_prev_child_number NEW_V pdtool1_prev_child_number NOPRI;
SELECT prev_sql_id pdtool1_prev_sql_id, TO_CHAR(prev_child_number) pdtool1_prev_child_number FROM v$session WHERE sid = SYS_CONTEXT('USERENV', 'SID')
/

-- execute one sql
@@&&pdtool1_bypass.&&skip_html.&&pdtool1_skip_html.pdtool1_9b_one_html.sql
@@&&pdtool1_bypass.&&skip_html.&&pdtool1_skip_xml.pdtool1_9g_one_xml.sql
@@&&pdtool1_bypass.&&skip_text.&&pdtool1_skip_text.pdtool1_9c_one_text.sql
@@&&pdtool1_bypass.&&skip_csv.&&pdtool1_skip_csv.pdtool1_9d_one_csv.sql
@@&&pdtool1_bypass.&&skip_lch.&&pdtool1_skip_line.pdtool1_9e_one_line_chart.sql
@@&&pdtool1_bypass.&&skip_lch2.&&pdtool1_skip_line.pdtool1_9e_two_line_chart.sql
@@&&pdtool1_bypass.&&skip_pch.&&pdtool1_skip_pie.pdtool1_9f_one_pie_chart.sql
@@&&pdtool1_bypass.&&skip_bch.&&pdtool1_skip_bar.pdtool1_9h_one_bar_chart.sql
HOS zip &&pdtool1_zip_filename. &&pdtool1_log2..txt >> &&pdtool1_log3..txt
HOS zip &&pdtool1_zip_filename. &&pdtool1_log3..txt

-- sql monitor long executions of sql from pdtool1
SELECT 'N' pdtool1_tuning_pack_for_pdmoni, ' echo skip pdmoni' skip_pdmoni_exec FROM DUAL
/
SELECT '&&tuning_pack.' pdtool1_tuning_pack_for_pdmoni, NULL skip_pdmoni_exec, SUBSTR(sql_text, 1, 100) pdtool1_sql_text_100, elapsed_time FROM v$sql 
WHERE sql_id = '&&pdtool1_prev_sql_id.' AND elapsed_time / 1e6 > 60 /* seconds */
/
@@&&skip_tuning.&&skip_pdmoni_exec.pdmoni.sql &&pdtool1_tuning_pack_for_pdmoni. &&pdtool1_prev_sql_id.
HOS zip -m &&pdtool1_zip_filename. pdmoni_&&pdtool1_prev_sql_id._&&current_time..zip >> &&pdtool1_log3..txt

-- needed reset after eventual pdmoni above
SET TERM OFF; 
SET HEA ON; 
SET LIN 32767; 
SET NEWP NONE; 
SET PAGES &&def_max_rows.; 
SET LONG 32000000; 
SET LONGC 2000; 
SET WRA ON; 
SET TRIMS ON; 
SET TRIM ON; 
SET TI OFF; 
SET TIMI OFF; 
SET ARRAY 1000; 
SET NUM 20; 
SET SQLBL ON; 
SET BLO .; 
SET RECSEP OFF;

-- cleanup
EXEC :sql_text := NULL;
--COL row_num NEW_V row_num HEA '#' PRI;
DEF abstract = '';
DEF abstract2 = '';
DEF foot = '';
DEF max_rows = '&&def_max_rows.';
DEF skip_html = '';
DEF skip_text = '';
DEF skip_csv = '';
DEF skip_lch = '--skip--';
DEF skip_lch2 = '--skip--';
DEF skip_pch = '--skip--';
DEF skip_bch = '--skip--';
DEF title_suffix = '';
--DEF haxis = '&&db_version. dbmod:&&pdtool1_dbmod. host:&&host_hash. (avg cpu_count: &&avg_cpu_count.)';
DEF haxis = '&&db_version. &&cores_threads_hosts.';

-- update main report
SPO &&pdtool1_main_report..html APP;
PRO <small><em> (&&row_num.) </em></small>
PRO </li>
SPO OFF;
HOS zip &&pdtool1_zip_filename. &&pdtool1_main_report..html >> &&pdtool1_log3..txt

-- report sequence
EXEC :repo_seq := :repo_seq + 1;
SELECT TO_CHAR(:repo_seq) report_sequence FROM DUAL;

