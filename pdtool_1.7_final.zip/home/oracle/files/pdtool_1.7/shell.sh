#!/bin/bash

# Set the directory path
DIR="C:\Users\PrashantDixit\Downloads\sqldb360-24.2\sqldb360-24.2\repo\repo_pdtool\source"

# Backup files before modifying (optional)
# mkdir -p "$DIR/backup"
# cp -r $DIR/* "$DIR/backup"

# Replace 'edb360' with 'pdtool' and 'sqldb360' with 'pdtool1' in all files
find $DIR -type f -exec sed -i 's/edb360/pdtool/g' {} +
find $DIR -type f -exec sed -i 's/sqldb360/pdtool1/g' {} +

echo "Text replacement completed!"

