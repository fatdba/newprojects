@@&&pdtool_0g.tkprof.sql
DEF section_id = '6o';
DEF section_name = 'Active Session History (ASH) - Top Latch Waits';
EXEC DBMS_APPLICATION_INFO.SET_MODULE('&&pdtool_prefix.','&&section_id.');
SPO &&pdtool_main_report..html APP;
PRO <h2>&&section_id.. &&section_name.</h2>
PRO <ol start="&&report_sequence.">
SPO OFF;

DEF main_table = '&&cdb_awr_hist_prefix.ACTIVE_SESS_HISTORY';
DEF skip_all = 'Y';

BEGIN
  :sql_text_backup := q'[
WITH hist AS (
   SELECT /*+ &&sq_fact_hints. */ /* &&section_id..&&report_sequence. */  d.*,
         SUM(samples) over () total_samples
    FROM (
          SELECT 
                 event,
          --     LPAD(LTRIM(TO_CHAR(p1,'XXXXXXXXXXXXXXXX')),16,0) addr,
                 p2 latch#,
                 COUNT(distinct p1) num_addr,
                 COUNT(*) samples,
                 row_number() OVER (ORDER BY COUNT(*) DESC) rn
            FROM &&cdb_awr_hist_prefix.active_sess_history
           WHERE @filter_predicate@
             AND event like 'latch%'
             AND p1text = 'address'
             AND p2text = 'number'
          GROUP BY event, p2
         ) d
)
SELECT  
       &&skip_ver_le_12_1. l.type||': '||
       REGEXP_SUBSTR(h.event,'[^:]+')||': '||
&&skip_ver_le_11_2.        l.display_name
&&skip_ver_ge_12_1.        l.name
       ||' (#'||h.latch#
       ||CASE WHEN num_addr>1 THEN ', '||num_addr||' addresses' END
       ||')' event_latch,
       h.samples,
       ROUND(100 * h.samples / h.total_samples, 1) percent,
       NULL dummy_01
  FROM hist h
       LEFT OUTER JOIN v$latchname l ON h.latch# = l.latch#
 WHERE h.samples >= h.total_samples / 2000 AND rn <= 14
UNION
SELECT 'OTHERS',
       NVL(SUM(h.samples),0) samples,
       NVL(ROUND(100 * SUM(h.samples) / AVG(h.total_samples), 1), 0) percent,
       NULL dummy_01
  FROM hist h
 WHERE h.samples < h.total_samples / 2000 OR rn > 14
ORDER BY 2 DESC NULLS LAST
]';
END;
/

/*****************************************************************************************/

SELECT ', between '||TO_CHAR(TO_TIMESTAMP('&&tool_sysdate.', 'YYYYMMDDHH24MISS') - 1, 'YYYY-MM-DD HH24:MM:SS')||' and '||TO_CHAR(TO_TIMESTAMP('&&tool_sysdate.', 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD HH24:MM:SS') between_times FROM DUAL;

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Cluster for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&is_single_instance.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 1 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 1 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst1.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 2 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 2 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst2.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 3 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 3 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst3.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 4 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 4 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst4.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 5 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 5 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst5.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 6 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 6 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst6.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 7 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 7 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst7.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 8 for 1 day';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 8 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 1 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst8.pdtool_9a_pre_one.sql

/*****************************************************************************************/

SELECT ', between '||TO_CHAR(TO_TIMESTAMP('&&tool_sysdate.', 'YYYYMMDDHH24MISS') - 7, 'YYYY-MM-DD HH24:MM:SS')||' and '||TO_CHAR(TO_TIMESTAMP('&&tool_sysdate.', 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD HH24:MM:SS')||', and between &&pdtool_conf_work_time_from. and &&pdtool_conf_work_time_to. hours' between_times FROM DUAL;

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Cluster for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&is_single_instance.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 1 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 1 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst1.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 2 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 2 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst2.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 3 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 3 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst3.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 4 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 4 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst4.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 5 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 5 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst5.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 6 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 6 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst6.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 7 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 7 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst7.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 8 for 5 working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 8 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst8.pdtool_9a_pre_one.sql

/*****************************************************************************************/

SELECT ', between '||TO_CHAR(TO_TIMESTAMP('&&tool_sysdate.', 'YYYYMMDDHH24MISS') - 7, 'YYYY-MM-DD HH24:MM:SS')||' and '||TO_CHAR(TO_TIMESTAMP('&&tool_sysdate.', 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD HH24:MM:SS') between_times FROM DUAL;

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Cluster for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&is_single_instance.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 1 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 1 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst1.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 2 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 2 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst2.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 3 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 3 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst3.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 4 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 4 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst4.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 5 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 5 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst5.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 6 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 6 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst6.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 7 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 7 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst7.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 8 for 7 days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 8 AND sample_time BETWEEN TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'') - 7 AND TO_TIMESTAMP(''&&tool_sysdate.'', ''YYYYMMDDHH24MISS'')');
@@&&skip_inst8.pdtool_9a_pre_one.sql

/*****************************************************************************************/

SELECT '&&between_dates., and between &&pdtool_conf_work_time_from. and &&pdtool_conf_work_time_to. hours' between_times FROM DUAL;

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Cluster for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&is_single_instance.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 1 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 1 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst1.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 2 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 2 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst2.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 3 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 3 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst3.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 4 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 4 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst4.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 5 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 5 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst5.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 6 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 6 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst6.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 7 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 7 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst7.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 8 for &&hist_work_days. working days';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 8 AND TO_CHAR(sample_time, ''D'') BETWEEN ''&&pdtool_conf_work_day_from.'' AND ''&&pdtool_conf_work_day_to.'' AND TO_CHAR(sample_time, ''HH24'') BETWEEN ''&&pdtool_conf_work_time_from.'' AND ''&&pdtool_conf_work_time_to.''');
@@&&skip_inst8.pdtool_9a_pre_one.sql

/*****************************************************************************************/

SELECT '&&between_dates.' between_times FROM DUAL;

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Cluster for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', '1 = 1');
@@&&is_single_instance.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 1 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 1');
@@&&skip_inst1.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 2 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 2');
@@&&skip_inst2.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 3 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 3');
@@&&skip_inst3.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 4 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 4');
@@&&skip_inst4.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 5 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 5');
@@&&skip_inst5.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 6 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 6');
@@&&skip_inst6.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 7 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 7');
@@&&skip_inst7.pdtool_9a_pre_one.sql

DEF skip_pch = '';
DEF title = 'ASH Top Latch Waits for Instance 8 for &&history_days. days of history';
DEF title_suffix = '&&between_times.';
EXEC :sql_text := REPLACE(:sql_text_backup, '@filter_predicate@', 'instance_number = 8');
@@&&skip_inst8.pdtool_9a_pre_one.sql

/*****************************************************************************************/

DEF skip_lch = 'Y';
DEF skip_pch = 'Y';

SPO &&pdtool_main_report..html APP;
PRO </ol>
SPO OFF;
