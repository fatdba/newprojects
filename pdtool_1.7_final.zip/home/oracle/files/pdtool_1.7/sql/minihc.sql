DEF pdtool_sections = ',1a,2b,2d,3d,3e,4a,4b,4c,4e,4f,4i,4j,5d,6a,6c,';
DEF sql_trace_level = 0;
DEF pdtool_conf_incl_stat_mem = 'N';
DEF pdtool_conf_incl_eadam = 'N';
DEF skip_esp_and_escp = '--skip--';
DEF ash_validation = '--skip--';
DEF pdtool_conf_series_selection ='Y';


