-- 12c dbms_stats.report_stats_operations
-- add seq to spool_filename
EXEC :file_seq := :file_seq + 1;
SELECT LPAD(:file_seq, 5, '0')||'_&&common_pdtool_prefix._&&section_id._&&report_sequence._dbms_stats.report_stats_operations' one_spool_filename FROM DUAL;
SET PAGES 0;
SPO &&pdtool_log..txt APP;
PRO Get DBMS_STATS.REPORT_STATS_OPERATIONS(detail_level => 'BASIC', format => 'HTML', latestN => &&def_max_rows., since => TO_TIMESTAMP('&&pdtool_date_from.', '&&pdtool_date_format.'), until => TO_TIMESTAMP('&&pdtool_date_to.', '&&pdtool_date_format.'))
SPO OFF;
SPO &&pdtool_output_directory.&&one_spool_filename..html
SELECT DBMS_STATS.REPORT_STATS_OPERATIONS(detail_level => 'BASIC', format => 'HTML', latestN => &&def_max_rows., since => TO_TIMESTAMP('&&pdtool_date_from.', '&&pdtool_date_format.'), until => TO_TIMESTAMP('&&pdtool_date_to.', '&&pdtool_date_format.')) FROM DUAL
/
SPO OFF;
SET PAGES &&def_max_rows.; 
HOS zip -mj &&pdtool_zip_filename. &&pdtool_output_directory.&&one_spool_filename..html >> &&pdtool_log3..txt
-- update main report
SPO &&pdtool_main_report..html APP;
PRO <li title="DBMS_STATS.REPORT_STATS_OPERATIONS">Statistics Gathering History Report
PRO <a href="&&one_spool_filename..html">html</a>
PRO </li>
SPO OFF;
HOS zip -j &&pdtool_zip_filename. &&pdtool_main_report..html >> &&pdtool_log3..txt
-- report sequence
EXEC :repo_seq := :repo_seq + 1;
SELECT TO_CHAR(:repo_seq) report_sequence FROM DUAL;


file:///tmp/00123_pdtool_2b_3c_619615_3c_115_dbms_stats.report_stats_operations.html