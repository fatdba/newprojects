-- this is a sample custom configuration requesting to produce just one section
-- for all possible DEF values please review pdtool_00_config.sql
DEF pdtool_sections = '1a';
