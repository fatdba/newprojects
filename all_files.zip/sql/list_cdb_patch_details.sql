-- $Name$ list_cdb_patch_details.sql
--
-- $Log$: Modified - 31 Jan 2020 - SC - Creation
--                 - 13 Nov 2020 - SC - Added more queries
--                 - 07 Feb 2023 - SC - Modified ORDER BY clause in DBA_REGISTRY_HISTORY query
--
--$Author$: Shawn Craven 

set lines 330 pages 100
col ACTION for a18
col VERSION for a25
col COMMENTS for a85
col ACTION_TIME for a21
col DESCRIPTION for a80
col BUNDLE_DATA for a35
col STATUS for a12
col PATCH_DESCRIPTOR for a35
col PATCH_DIRECTORY for a35
col POST_LOGFILE for a35
col LOGFILE for a35
col BUNDLE_SERIES for a8

select 'Registry_History' "CHECK_NAME",TO_CHAR(action_time, 'DD-MON-YYYY HH24:MI:SS') AS ACTION_TIME, action, namespace, version,id,comments
from DBA_REGISTRY_HISTORY
--ORDER by ACTION_TIME ;
ORDER by VERSION, ACTION_TIME ;

col VERSION for a25
SELECT 'sqlpatch_history' "CHECK_NAME",TO_CHAR(action_time, 'DD-MON-YYYY HH24:MI:SS') AS action_time,action,status,description,patch_id
FROM sys.dba_registry_sqlpatch
ORDER by action_time ;

SET LINESIZE 500
SET PAGESIZE 1000
SET SERVEROUT ON
SET LONG 2000000
COLUMN action_time FORMAT A12
COLUMN action FORMAT A18
COLUMN patch_type FORMAT A10
--COLUMN description FORMAT A32
COLUMN status FORMAT A10
COLUMN version FORMAT A10
alter session set "_exclude_seed_cdb_view"=FALSE;

--spool check_patches_19c.txt

select CON_ID,
TO_CHAR(action_time, 'YYYY-MM-DD') AS action_time,
PATCH_ID,
PATCH_TYPE,
ACTION,
DESCRIPTION,
SOURCE_VERSION,
TARGET_VERSION
from CDB_REGISTRY_SQLPATCH
order by CON_ID, action_time, patch_id;

--spool off