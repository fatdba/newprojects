-- $Name$ list_cursor_activity.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--                 - 07 Apr 2022 - SC - Cleaned up VALUE column lengths
--
-- $Author$: Shawn Craven
--

set lines 220 pages 100

col USERNAME for a22
col VALUE for 999,999,999
col MAX_OPEN_CUR for 999,999,999

PROMPT 
PROMPT *** process, session, open_cursor, session_cursor_cache count settings ***
PROMPT
col NAME for a32
col DESCRIPTION for a40
col VALUE for a32
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('processes','sessions','open_cursors','session_cached_cursors')
--  and  val.KSPPSTVL is not null
order by 1;

PROMPT
PROMPT *** Total cursors open - by session ***
PROMPT
col VALUE for 99999
select a.value, s.username, s.sid, s.serial#
  from v$sesstat a, v$statname b, v$session s
 where a.statistic# = b.statistic#
   and s.sid = a.sid
   and s.USERNAME not in ('SYS','SYSRAC') 
   and b.name = 'opened cursors current'
 order by USERNAME ;

PROMPT 
PROMPT *** Total cursors open - by username and machine ***
PROMPT
select sum(a.value) total_cur,
       avg(a.value) avg_cur,
       max(a.value) max_cur,
       s.username,
       s.machine
  from v$sesstat a, v$statname b, v$session s
 where a.statistic# = b.statistic#
   and s.sid = a.sid
   and b.name = 'opened cursors current'
   and USERNAME not in ('SYS')
 group by s.username, s.machine
 order by 1 desc;

PROMPT
PROMPT *** hard and soft parse percentage *** 
PROMPT
select to_char (100 * sess / calls, '999999999990.00') || '%' cursor_cache_hits,
       to_char(100 * (calls - sess - hard) / calls, '999990.00') || '%' soft_parses,
       to_char(100 * hard / calls, '999990.00') || '%' hard_parses
  from (select value calls
          from sys.v_$sysstat
         where name = 'parse count (total)'),
       (select value hard
          from sys.v_$sysstat
         where name = 'parse count (hard)'),
       (select value sess
          from sys.v_$sysstat
         where name = 'session cursor cache hits');

PROMPT
PROMPT *** hard and soft parse percentage ***
PROMPT
select 'session_cached_cursors' parameter,
       lpad(value, 5) value,
       decode(value, 0, '  n/a', to_char(100 * used / value, '990') || '%') usage
  from (select max(s.value) used
          from sys.v_$statname n, sys.v_$sesstat s
         where n.name = 'session cursor cache count'
           and s.statistic# = n.statistic#),
       (select value
          from sys.v_$parameter
         where name = 'session_cached_cursors')
union all
select 'open_cursors',
       lpad(value, 5),
       to_char(100 * used / value, '990') || '%'
  from (select max(sum(s.value)) used
          from sys.v_$statname n, sys.v_$sesstat s
         where n.name in
               ('opened cursors current', 'session cursor cache count')
           and s.statistic# = n.statistic#
         group by s.sid),
       (select value from sys.v_$parameter where name = 'open_cursors') ;
