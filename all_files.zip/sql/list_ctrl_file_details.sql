col NAME for a55
select * from v$controlfile ;
