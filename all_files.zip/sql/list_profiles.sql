-- $Name$ list_profiles.sql
--
-- $Log$  Modified - 04 Sept 2017 - SC - Creation
--                 - 23 Mar  2022 - SC - Reordered order by - CON_ID now the 1st column
-- $Author$: Shawn Craven

set lines 220 pages 100
col PROFILE for a30
col LIMIT for a55
col CON_ID for 99999
select CON_ID, PROFILE, RESOURCE_NAME, RESOURCE_TYPE, LIMIT, COMMON from cdb_profiles order by 1,2,3 ;
