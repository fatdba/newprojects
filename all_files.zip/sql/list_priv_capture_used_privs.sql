-- $Name$ list_priv_capture_used_privs.sql
--
-- $Log$  Modified - 04 Aug 2022 - GF - Creation

-- $Author$: Gonzalo Fernandez

set lines 220 pages 100
COLUMN capture FORMAT A25
COLUMN object_owner FORMAT A10
COLUMN object_name FORMAT A30
COLUMN object_type FORMAT A20
COLUMN user_priv FORMAT A10
SET LINESIZE 200

SELECT capture,
       user_priv,
       object_owner,
       object_name,
       object_type
FROM   dba_used_privs
WHERE  run_name =  UPPER('&run_name')
ORDER BY 3,5,4;
