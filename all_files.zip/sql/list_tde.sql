-- $Name$ list_tde.sql
-- $Log$: Modified - 04 Nov 2018
-- $Author$: Shawn Craven

prompt *** ENCRYPTION DETAILS ***
SET LINESIZE 220
col STATUS for a20
col USER for a8
col CON_ID for 99999
col CREATOR for a10
col KEY_USE for a11
col KEY_ID for a55
col CREATION_TIME for a36
col ACTIVATION_TIME for a36
col WALLET_ORDER for a12
col FULLY_BACKED_UP for a15
col wrl_parameter for a48
SELECT * FROM gv$encryption_wallet order by 1;

SELECT CON_ID, CREATOR, USER, CREATION_TIME, ACTIVATION_TIME, KEY_USE, key_id FROM v$encryption_keys order by CON_ID;

set lines 220
col TAG for a18
col CREATOR_PDBNAME for a25
col ACTIVATING_PDBNAME for a25
col ORIGIN for a8

select con_id,tag,substr(key_id,1,6)||'...' "KEY_ID...",creator,key_use,keystore_type,origin,creator_pdbname,activating_pdbname from v$encryption_keys order by con_id ;
