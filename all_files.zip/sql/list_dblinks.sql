-- $Name$ List_dblinks.sql
--
-- $Log$: Modified - 04 Sep 2018 - SC - Creation
--                 - 25 Mar 2022 - SC - FOrmated SERVICE colum from a32 to a58
--
-- $Author$: Shawn Craven

set lines 220
COL OWNER FORMAT a25
COL DB_LINK FORMAT A35
COL CREATED FORMAT A24
COL USERNAME FORMAT A28 HEADING "USER"
COL HOST FORMAT A58 HEADING "SERVICE"
col PASSWORD for a25
SELECT * FROM DBA_DB_LINKS 
order by 1;
