-- $Name$ list_auto_db_task_maint.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** AUTO DB TASK DETAILS ***
prompt

set lines 130
COL client_name FOR A31
COL status for a8
COL mean_job_duration FOR A30 TRU
COL total_cpu_last_7_days FOR A30 TRU
COL max_duration_last_30_days FOR A25 TRU
SELECT client_name, status, mean_job_duration, total_cpu_last_7_days, max_duration_last_30_days FROM dba_autotask_client ;
