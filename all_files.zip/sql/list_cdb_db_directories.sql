-- $Name$ list_db_directories.sql
--
-- $Log$  Modified - 04 Jun 2016 - SC - Creation
--
-- $Author$: Shawn Craven

set lines 220
set pages 9000
col OWNER format a8
col CON_ID format 999999
col DIRECTORY_NAME format a25
col DIRECTORY_PATH format a100
col ORIGIN_CON_ID  format 9999
select CON_ID,ORIGIN_CON_ID, OWNER, DIRECTORY_NAME, DIRECTORY_PATH from cdb_directories
order by CON_ID,ORIGIN_CON_ID, DIRECTORY_NAME ;
