-- $Name$
-- $Log$: Modified - 04 Sept 2017

-- $Author$: Shawn Craven
PROMPT RUN in CDB to review all local PDB accounts

set lines 220 pages 100
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a26
col COMMON for a6
col LAST_LOGIN for a38
col CON_ID for 999999
select CON_ID, username, account_status, created, profile, password_versions, COMMON, last_login from cdb_users
where COMMON != 'YES'
and account_status = 'OPEN'
and last_login is not null
and profile != 'PL_GENERIC_ID'
and username not in ('ARCSIGHT','DB','OPS$ORACLE','PDBSYS')
order by 1,2 ;
