-- $Name$
-- $Log$: Modified - 16 July 2019
-- $Author$: Shawn Craven

set pages 999 lines 250
set echo off
col file_name format a105
col size_mb format 999,999,999.99
col free_mb format 999,999,999.99
col maxsize_mb format 999,999,999.99

PROMPT
PROMPT DATA datafiles
PROMPT

select file_id, file_name, bytes/1024/1024 size_mb, maxbytes/1024/1024 maxsize_mb, autoextensible, (increment_by*block_size)/1024/1024 ext_mb
  from dba_data_files f, dba_tablespaces t
 where f.tablespace_name = t.tablespace_name
order by 1;

PROMPT TEMP tempfiles
PROMPT

select file_id, file_name, bytes/1024/1024 size_mb, maxbytes/1024/1024 maxsize_mb, autoextensible, (increment_by*block_size)/1024/1024 ext_mb
  from dba_temp_files f, dba_tablespaces t
 where f.tablespace_name = t.tablespace_name
order by 1;

col size_mb format 999,999,999.99
col free_mb format 999,999,999.99
col maxsize_mb format 999,999,999.99

PROMPT DATA tablespaces
PROMPT

select t.tablespace_name, t.contents, t.status, t.logging, t.bigfile, t.block_size, 
       round(f.sum_bytes/1024/1024,2) size_mb, 
       round(s.sum_bytes/1024/1024,2) free_mb, 
       round(f.sum_max_bytes/1024/1024,2) maxsize_mb,
       round((f.sum_bytes-s.sum_bytes)/f.sum_bytes,2)*100 used_pct,
       round((f.sum_bytes-s.sum_bytes)/f.sum_max_bytes,2)*100 used_pct_of_max
  from dba_tablespaces t, 
       (select sum(bytes) sum_bytes, sum(decode(f.autoextensible,'YES',greatest(f.maxbytes,f.bytes),f.bytes)) sum_max_bytes, tablespace_name
          from dba_data_files f
        group by tablespace_name
       ) f,
       (select sum(bytes) sum_bytes, tablespace_name
          from dba_free_space s
        group by tablespace_name
       ) s
   where t.tablespace_name = f.tablespace_name
   and t.tablespace_name = s.tablespace_name(+)
order by 1;

PROMPT TEMP tablespaces
PROMPT

select t.tablespace_name, t.contents, t.status, t.logging, t.bigfile, t.block_size,
       round(f.sum_bytes/1024/1024,2) size_mb,
       round(s.sum_bytes/1024/1024,2) free_mb,
       round(f.sum_max_bytes/1024/1024,2) maxsize_mb,
       round((f.sum_bytes-s.sum_bytes)/f.sum_bytes,2)*100 used_pct,
       round((f.sum_bytes-s.sum_bytes)/f.sum_max_bytes,2)*100 used_pct_of_max
  from dba_tablespaces t,
       (select sum(bytes) sum_bytes, sum(decode(f.autoextensible,'YES',greatest(f.maxbytes,f.bytes),f.bytes)) sum_max_bytes, tablespace_name
          from dba_temp_files f
        group by tablespace_name
       ) f,
       (select sum(bytes) sum_bytes, tablespace_name
          from dba_free_space s
        group by tablespace_name
       ) s
 where t.tablespace_name = f.tablespace_name
   and t.tablespace_name = s.tablespace_name(+)
order by 1;
