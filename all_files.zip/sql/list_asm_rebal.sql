set lines 220
prompt
prompt Current ASM disk operations - Starting with Oracle Database 12c, new queries should use this column instead of the OPERATION column
prompt ===========================
col ERROR_CODE for a12
select * from   gv$asm_operation order by 1;
