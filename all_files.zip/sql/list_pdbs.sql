-- $Name$ list_pdbs.sql
--
-- $Log$: Modified - 04 Sep 2018 - SC - Creation
--                 - 29 Apr 2022 - SC - Added usable query
--                 - 20 Jul 2022 - SC - Cleaned up OPENED query with to_char and added CREATED column
--                 - 31 Aug 2022 - SC - Added MULTITENANT FEATURE USAGE DETAILS query
--                 - 17 Jun 2022 - SC - Added PDB characterset value to the first query group
--
-- $Author$: Shawn Craven
--

prompt
prompt *** PDB Details ***
prompt

set lines 220
col NAME for a22
col CON_ID for 99999
col CREATED for a18
col OPENED for a18
col RESTRICTED for a10
col TOTAL_SIZE for 999,999,999,999,999
col CHARACTER_SET_NAME for a18

select p.INST_ID,
       p.NAME,
       p.CON_ID,
       p.CON_UID,
       p.GUID,
       p.OPEN_MODE,
       p.RESTRICTED,
       p.RECOVERY_STATUS,
       to_char(p.CREATION_TIME, 'YYYY/MM/DD HH24:MI') "CREATED",
       to_char(p.OPEN_TIME, 'YYYY/MM/DD HH24:MI') "OPENED",
       p.TOTAL_SIZE/1024/1024/1024 as TOTAL_SIZE_GB,
       nls.VALUE as CHARACTER_SET_NAME
from gv$pdbs p
join v$nls_parameters nls on nls.PARAMETER = 'NLS_CHARACTERSET'
order by p.CON_ID, p.INST_ID;

prompt
prompt *** PDB USEABLE? sb NORMAL ***
prompt

COLUMN pdb_name FORMAT A22

select PDB_NAME,STATUS from cdb_pdbs;

prompt *** PDB SNAPSHOT MODE DETAILS ****

COLUMN snapshot_mode FORMAT A15

SELECT p.con_id,
       p.pdb_name,
       p.snapshot_mode,
       p.snapshot_interval
FROM   cdb_pdbs p
ORDER BY 1;

prompt
prompt *** MULTITENANT FEATURE USAGE DETAILS ***
prompt

col FEATURE_NAME for a32
select name feature_name,version,detected_usages,aux_count
  from dba_feature_usage_statistics
 where name like '%Pluggable%' or name like '%Multitenant%';