-- $Name$ cr_RENAPS_dbas.sql
--
-- $Log$: Modified - 26 Apr 2023 - SC - Creation
--
-- $Author$: Shawn Craven (scraven@renaps.com)
--

-- Create the users using CASE statement syntax

BEGIN
    FOR i IN 1..10 LOOP
        BEGIN
            EXECUTE IMMEDIATE 'CREATE USER ' ||
                              CASE i
                                  WHEN 1  THEN 'pdixit'
                                  WHEN 2  THEN 'csaikaly'
                                  WHEN 3  THEN 'mpalacios'
                                  WHEN 4  THEN 'gfernandez'
                                  WHEN 5  THEN 'hzgheib'
                                  WHEN 6  THEN 'mcote'
                                  WHEN 7  THEN 'mgizaris'
                                  WHEN 8  THEN 'sfung'
                                  WHEN 9  THEN 'scraven'
                                  WHEN 10 THEN 'sgandhi'
                              END ||
                              ' IDENTIFIED BY "new_password123" ' ||
                              ' DEFAULT TABLESPACE users ' ||
                              ' QUOTA 100M ON users ' ||
                              ' PROFILE R$OLT_DBA ' ||
                              ' ACCOUNT LOCK ' ||
                              ' PASSWORD EXPIRE ';
            EXECUTE IMMEDIATE 'GRANT DBA TO ' ||
                              CASE i
                                  WHEN 1  THEN 'pdixit'
                                  WHEN 2  THEN 'csaikaly'
                                  WHEN 3  THEN 'mpalacios'
                                  WHEN 4  THEN 'gfernandez'
                                  WHEN 5  THEN 'hzgheib'
                                  WHEN 6  THEN 'mcote'
                                  WHEN 7  THEN 'mgizaris'
                                  WHEN 8  THEN 'sfung'
                                  WHEN 9  THEN 'scraven'
                                  WHEN 10 THEN 'sgandhi'
                              END;
            EXECUTE IMMEDIATE 'AUDIT ALL BY ' ||
                              CASE i
                                  WHEN 1  THEN 'pdixit'
                                  WHEN 2  THEN 'csaikaly'
                                  WHEN 3  THEN 'mpalacios'
                                  WHEN 4  THEN 'gfernandez'
                                  WHEN 5  THEN 'hzgheib'
                                  WHEN 6  THEN 'mcote'
                                  WHEN 7  THEN 'mgizaris'
                                  WHEN 8  THEN 'sfung'
                                  WHEN 9  THEN 'scraven'
                                  WHEN 10 THEN 'sgandhi'
                              END;
            DBMS_OUTPUT.PUT_LINE('User ' ||
                                 CASE i
                                  WHEN 1  THEN 'pdixit'
                                  WHEN 2  THEN 'csaikaly'
                                  WHEN 3  THEN 'mpalacios'
                                  WHEN 4  THEN 'gfernandez'
                                  WHEN 5  THEN 'hzgheib'
                                  WHEN 6  THEN 'mcote'
                                  WHEN 7  THEN 'mgizaris'
                                  WHEN 8  THEN 'sfung'
                                  WHEN 9  THEN 'scraven'
                                  WHEN 10 THEN 'sgandhi'
                                 END ||
                                 ' created successfully');
        EXCEPTION
            WHEN OTHERS THEN
                IF SQLCODE = -01920 THEN
                    DBMS_OUTPUT.PUT_LINE('User ' ||
                             CASE i
                                  WHEN 1  THEN 'pdixit'
                                  WHEN 2  THEN 'csaikaly'
                                  WHEN 3  THEN 'mpalacios'
                                  WHEN 4  THEN 'gfernandez'
                                  WHEN 5  THEN 'hzgheib'
                                  WHEN 6  THEN 'mcote'
                                  WHEN 7  THEN 'mgizaris'
                                  WHEN 8  THEN 'sfung'
                                  WHEN 9  THEN 'scraven'
                                  WHEN 10 THEN 'sgandhi'
                              END ||
                                  ' already exists, skipped ***');
                ELSE
                    RAISE;
                END IF;
        END;
    END LOOP;
END;
/

@list_dba_users.sql
@list_audit_policies.sql
