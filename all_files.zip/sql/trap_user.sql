-- $Name$ trap_user.sql
--
-- $Log$: Modified - 04 Sep 2017 - SC - Creation
--                 - 01 Apr 2022 - SC - Added CON_ID to all database session section

-- $Author$: Shawn Craven

set lines 220
set pages 100

column inst_id format 99
column con_id format 9999
column GLOBAL_NAME format a32
column MACHINE format a32
column SID format 999999
column SPID format a12
column USERNAME format a25
column OSUSER format a25
column SERVICE_NAME format a20

prompt
prompt *** All Database Sessions ***

SELECT global_name,
s.inst_id,
s.con_id,
s.username username,
osuser,
s.sid,
s.serial#,
p.spid,
s.sql_id,
cast(substr(s.service_name,1,20) as VARCHAR2(22))||'...' "SERVICE_NAME...",
cast(substr(s.machine,1,19) as VARCHAR2(22))||'...' "MACHINE..."
  FROM global_name,
       gv$session s,
       gv$process p
 WHERE s.paddr = p.addr
   AND s.username IS NOT NULL
--   AND SERVICE_NAME not like 'jdeprod_dg%'
 ORDER BY s.inst_id, s.con_id, s.username ;

prompt CDB Details
SELECT DISTINCT instance_number,instance_name,status,database_status,logins,cast(substr(host_name,1,19) as VARCHAR2(22))||'...' "HOST_NAME...",version,startup_time,sysdate FROM gv$instance order by 1;

prompt PDB Details
set lines 220
col NAME for a22
col OPEN_TIME for a35
col RESTRICTED for a10
col TOTAL_SIZE for 999,999,999,999,999
select INST_ID, CON_ID, CON_UID, GUID, NAME, OPEN_MODE, RESTRICTED, RECOVERY_STATUS, OPEN_TIME, TOTAL_SIZE/1024/1024/1024 as TOTAL_SIZE_GB from gv$pdbs order by CON_ID, INST_ID ;

col USERNAME for a20
col MACHINE  for a32
select username,  cast(substr(machine,1,19) as VARCHAR2(22))||'...' "MACHINE_NAME...", count(*)
from gv$session
where status='ACTIVE'
group by username, machine ;

select cast(substr(machine,1,19) as VARCHAR2(22))||'...' "MACHINE_NAME...",count(*) from v$session where type<>'BACKGROUND' group by machine;
PROMPT
PROMPT *** Current Session Details ***
PROMPT
@init.sql
PROMPT

/*
set lines 220
col resource_name format a15
select resource_name, current_utilization, max_utilization, limit_value
  from v$resource_limit
 where resource_name in ('sessions', 'processes');
 
--#How do I connect to the database to increase my processes parameter? Well I remember Tanel Poder blogged about "How to log on even when SYSDBA can't do so?"
sqlplus -prelim "/ as sysdba"
*/
