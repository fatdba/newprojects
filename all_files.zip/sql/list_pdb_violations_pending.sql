set lines 220
col TIME for a29
col NAME for a18
col CAUSE for a25
col MESSAGE for a50
select time, type, name, cause, status, message from PDB_PLUG_IN_VIOLATIONS where STATUS not in ('RESOLVED') order by name;
