-- $Name$ list_holding_locks.sql
-- $Log$: Modified - 04 Sep 2015 - SC - Creation
--
-- $Author$: Shawn Craven

set pagesize 1000
set linesize 250
col object for a35
col machine for a40
col userid for a25
col program for a20
col usercode for a15
col hold for a20
col type for a5
col module for a32
SELECT
  a.inst_id, a.osuser || ':' || a.username   UserID,
--  a.machine
cast(substr(machine,1,19) as VARCHAR2(22))||'...' "MACHINE..."
, a.sid || ',' || a.serial#       usercode
, b.lock_type Type, a.sql_id SQL_ID, b.mode_held   Hold
, c.owner || '.' || c.object_name Object
, a.module                       Module
, ROUND(d.seconds_in_wait/60,2)   WaitMin
  FROM
  gv$session       a
, dba_locks       b
, dba_objects     c
, gv$session_wait  d
 WHERE a.sid        =  b.session_id
  AND b.lock_type  IN ('DML','DDL')
  AND b.lock_id1   =  c.object_id
  AND b.session_id  =  d.sid
  AND a.username not like 'oracle%';
