-- $Name$ list_tables_avec_blobs.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** USER PROXY DETAILS ***
prompt

col CLIENT for a15
col PROXY for a15
SELECT * FROM proxy_users 
order by CLIENT, PROXY ;
