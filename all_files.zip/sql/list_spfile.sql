set lines 220
col NAME for a32 
col DESCRIPTION for a35 
col VALUE for a75 
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE 
  from x$ksppi nam, x$ksppsv val 
where nam.indx = val.indx and nam.ksppinm like 'spfile%' 
  and  val.KSPPSTVL is not null 
order by 1; 

