-- $Name$ list_nls.sql
--
-- $Log$: Modified - 04 Sep 2018 - SC - Creation
--
-- $Author$: Shawn Craven

prompt *** CHARACTERSET DETAILS ***
COLUMN parameter FORMAT A30
COLUMN value FORMAT A30
SELECT *
FROM   nls_database_parameters
WHERE  parameter in ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET','NLS_DATE_FORMAT') order by 1;
