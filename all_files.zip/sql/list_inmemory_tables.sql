-- $Name$
-- $Log$: Modified - 03 Mar 2020 - SC - Created
--
-- $Author$: Shawn Craven

PROMPT
PROMPT *** INMEMORY Settings ***
PROMPT

SHOW PARAMETER INMEMORY

PROMPT
PROMPT *** INMEMORY Tables ***
PROMPT

set lines 200 pages 100
COLUMN owner      FORMAT A35
COLUMN table_name FORMAT A35

SELECT owner,
       table_name,
       inmemory,
       inmemory_priority,
       inmemory_distribute,
       inmemory_compression,
       inmemory_duplicate
FROM   cdb_users c, dba_tables d
WHERE  c.username = d.owner
AND    c.oracle_maintained = 'N'
AND    d.inmemory != 'DISABLED'
ORDER BY owner, table_name ;
