-- $Name$ list_all_pdb_users.sql
--
-- $Log$  Modified - 04 Sep 2017  - SC - Creation.
--                 - 16 Feb 2022  - SC - Added password_change_date column.
--                 - 02 May 2023  - SC - Cleanup query and ensured PASSWORD_EXPIRE is reported.
--                 - 24 Jul 2023  - SC - Formatted CREATED, PASSWORD_CHANGE_DATE and PASSWORD_EXPIRE better.
--
-- $Author$: Shawn Craven

prompt
prompt *** To be run in PDB ***
prompt

set lines 220 pages 50
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a27
col COMMON for a6
col LAST_LOGIN for a22
col PASSWORD_CHANGE_DATE for a22
col PASSWORD_EXPIRE for a22
col expiry_date format a22
col CREATED for a22
col CON_ID for 999999
select con_id, username, common, account_status, profile, to_char(created, 'DD-MON-RRRR hh24:mi:ss') as created, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, to_char(password_change_date, 'DD-MON-RRRR hh24:mi:ss') as password_change_date,to_char(expiry_date, 'DD-MON-RRRR hh24:mi:ss') as password_expire, password_versions
from cdb_users
where ORACLE_MAINTAINED != 'Y'
and COMMON = 'NO'
order by 1,2 ;