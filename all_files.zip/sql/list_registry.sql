prompt *** REGISTRY DETAILS ***
set lines 220
col COMP_ID for a18
col COMP_NAME for a55
select comp_id,comp_name,version,status from dba_registry
order by 1;
