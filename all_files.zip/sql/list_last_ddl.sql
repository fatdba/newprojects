-- $Name$ list_last_ddl.sql
--
-- $Log$  Modified - 16 Jun 2016 - SC - Creation
--
-- $Author$: Shawn Craven

set linesize 160
set pagesize 1000
col owner format a10
col object_name format a30
select OWNER, OBJECT_NAME, OBJECT_TYPE, CREATED, LAST_DDL_TIME from dba_objects where OWNER = '&OWNER' and LAST_DDL_TIME > sysdate-30 order by OBJECT_TYPE,LAST_DDL_TIME, OBJECT_NAME  ;
