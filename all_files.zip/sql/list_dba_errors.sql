-- $Name$: list_dba_errors.sql
--
-- $Log$: Modified - 18 Mar 2022 - creation
--
-- $Author$: Shawn Craven

set lines 220
col OWNER for a8
col TEXT for a95
col LINE for 9999
col SEQUENCE for 99999999
col POSITION for 99999999
select * from dba_errors 
--where OWNER in ('&&SCHEMA')
order by 1,3,2;
