-- $Name$ info.sql
--
-- $Log$: Modified - 04 Sep 2018 - SC - Creation.
--                 - 18 Jan 2019 - SC - Addded many init parameter queries.
--                 - 03 Feb 2019 - SC - Updated long columns to use cast.
--                 - 14 Mar 2019 - SC - Cleaned up DG broker details.
--                 - 28 May 2019 - SC - Cleaned up MEMORY details.
--                 - 23 Jul 2019 - SC - Added Direct and async I/O check.
--                 - 27 Sep 2021 - SC - Added additional nls_database_parameters values and DB size.
--                 - 25 Jan 2022 - SC - Added PLATFORM and CREATED DETAILS section.
--                 - 16 Feb 2022 - SC - Added CPU and CORE section.
--                 - 19 Sep 2022 - SC - Added OPTIMIZER PARAMETER DETAILS section.
--                 - 22 Nov 2022 - SC - Modified CHARACTERSET DETAILS section and added _exclude_seed_cdb_view section.
--                 - 27 Feb 2023 - SC - Added DB_DOMAIN and GLOBAL_NAME CDB details.
--                 - 28 Mar 2023 - SC - Added REPORT_TITLE header information.
--                 - 31 Aug 2023 - SC - Removed REPORT_TITLE header information, added Report Header Details - cleaner.
--                 - 07 Sep 2023 - SC - Added archive log list; section.
--
-- $Author$: Shawn Craven
--
-- Note: To be run with SYSDBA privileges
--

-- Report Header Details

SET FEEDBACK OFF ;

col 'ORACLE_HOME: '   for a60
col 'Database Name: ' for a32
col 'Server Name: '   for a32
col 'Report Date: '   for a32
col 'Report Date: '   for a32

col DATABASE_REPORT for a80
SELECT
  LPAD('ORACLE_HOME: ', 20) ||
  RPAD(sys_context('USERENV', 'ORACLE_HOME'), 60) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Database Name: ', 20) ||
  RPAD(sys_context('USERENV', 'DB_NAME'), 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Instance Name: ', 20) ||
  RPAD(sys_context('USERENV', 'INSTANCE_NAME'), 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('DB Unique Name: ', 20) ||
  RPAD(sys_context('USERENV', 'DB_UNIQUE_NAME'), 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Container Type: ', 20) ||
  RPAD(CASE
         WHEN SYS_CONTEXT('USERENV', 'CON_NAME')='CDB$ROOT' THEN 'CDB'
         ELSE 'PDB'
       END, 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Server Name: ', 20) ||
  RPAD(sys_context('USERENV', 'HOST'), 32) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Report Date: ', 20) ||
  RPAD(TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS'), 22) AS database_report
FROM dual;
SET FEEDBACK ON ;

ALTER session SET NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

set serveroutput ON lines 2000 pages 2000 echo OFF

prompt
prompt *** SPFILE DETAILS ***

col NAME for a32
col DESCRIPTION for a35
col VALUE for a75
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'spfile%'
  and  val.KSPPSTVL is not null
order by 1;

prompt
prompt *** BACKGROUND DETAILS ***

select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'background%'
  and  val.KSPPSTVL is not null
order by 1;

prompt
prompt *** AUDIT and DIAG DETAILS ***

col NAME for a32
col DESCRIPTION for a48
col VALUE for a45
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('diagnostic_dest','audit_trail','audit_file_dest','audit_sys_operations','audit_syslog_level')
--  and  val.KSPPSTVL is not null
order by 1;

prompt
prompt *** Direct and Asynchronous I/O Details      ***
prompt *** disk_asynch_io S/B true                  ***
prompt *** ignore filesystemio_options if using ASM ***

col NAME for a32
col DESCRIPTION for a48
col VALUE for a45
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('disk_asynch_io','filesystemio_options')
--  and  val.KSPPSTVL is not null
order by 1;

prompt
prompt *** DEFAULT CREATE DETAILS ***

col NAME for a32
col DESCRIPTION for a40
col VALUE for a35
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('db_create_file_dest','db_create_online_log_dest_1','db_create_online_log_dest_2')
--  and  val.KSPPSTVL is not null
order by 1;


prompt
prompt *** MEMORY PARAMETER DETAILS ***

col NAME for a32
col DESCRIPTION for a66
col VALUE for a25
col CON_ID for 99999
col INST_ID for 99999
select distinct nam.CON_ID CONTAINER, nam.INST_ID INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('streams_pool_size','memory_target','memory_max_target','sga_target','sga_max_size','db_cache_size','shared_pool_size','large_pool_size','java_pool_size','pga_aggregate_limit','pga_aggregate_target')
--  and  val.KSPPSTVL is not null
order by 1,2 ;

prompt
prompt *** SGA DYNAMIC COMPONENTS ***

SELECT component, current_size/1024/1024 as size_mb, min_size/1024/1024 as min_size_mb
FROM v$sga_dynamic_components
WHERE current_size > 0
ORDER BY component;

prompt
prompt *** select * from v$sgainfo ***

col BYTES for 999,999,999,999,999
select * from v$sgainfo ;

prompt
prompt *** OPTIMIZER PARAMETER DETAILS ***

col NAME for a38
col DESCRIPTION for a66
col VALUE for a25
col CON_ID for 99999
col INST_ID for 99999
select distinct nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('optimizer_capture_sql_plan_baselines','optimizer_use_sql_plan_baselines','optimizer_mode','optimizer_index_cost_adj','optimizer_index_caching','optimizer_dynamic_sampling','db_file_multiblock_read_count','hash_area_size','sort_area_size')
--  and  val.KSPPSTVL is not null
order by 1 ;

prompt
prompt *** PARALLEL_MAX_SERVERS ***

select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'parallel_max_servers' and  val.KSPPSTVL is not null ;

prompt
prompt *** HUGEPAGES/LARGE PAGES DETAILS ***

select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
 where nam.indx = val.indx and nam.ksppinm like 'use_large_pages'
   and val.KSPPSTVL is not null ;

!cat /etc/sysctl.conf|grep vm.nr_hugepages

prompt
prompt *** CHARACTERSET DETAILS ***

set lines 220
COLUMN parameter FORMAT A30
COLUMN value FORMAT A30
SELECT *
FROM   nls_database_parameters
WHERE  parameter in ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET','NLS_DATE_FORMAT')
order by 1 ;

prompt
prompt *** ADDITIONAL CDB CHARACTERSET DETAILS ***

set lines 220
COLUMN name FORMAT A24
COLUMN description FORMAT A64
COLUMN value FORMAT A30
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
 where nam.indx = val.indx and nam.ksppinm like 'nls%'
   and val.KSPPSTVL is not null ;

prompt
prompt *** TIMEZONE DETAILS ***

set lines 220
col SESSIONTIMEZONE for a25
col DBTIMEZONE for a25
SELECT SESSIONTIMEZONE, dbtimezone FROM DUAL;

prompt
prompt *** DBMS_SCHEDULER DEFAULT TIMEZONE DETAILS ***

col TIMEZONE for a30
select value as TIMEZONE from dba_scheduler_global_attribute WHERE attribute_name = 'DEFAULT_TIMEZONE' ;

/*
prompt
prompt *** Last 20 DB startup timezones used ***

SET SPACE 1 LINESIZE 80 PAGES 1000
SET SPACE 1 LINESIZE 80 PAGES 1000
SELECT * FROM (
select to_char(ORIGINATING_TIMESTAMP,'YYYY/MM/DD HH24:MI:SS TZH:TZM')
from V$DIAG_ALERT_EXT
WHERE trim(COMPONENT_ID)='rdbms'
and MESSAGE_TEXT like ('PMON started with%')
order by originating_timestamp desc )
WHERE rownum < 20 ;
*/

prompt
prompt *** fixed_date init parameter ***

set lines 220
col NAME for a38
col DESCRIPTION for a66
col VALUE for a25
col CON_ID for 99999
col INST_ID for 99999
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
 where nam.indx = val.indx and nam.ksppinm like 'fixed_date' ;

prompt
prompt *** CURRENT TIMESTAMP DETAILS ***

col current_timestamp for a38
col localtimestamp for a38
col SYSTIMESTAMP for a38
select current_timestamp, localtimestamp, SYSTIMESTAMP from dual ;

prompt
prompt *** CDB RESOURCE DETAILS ***

set lines 220 pages 100
col NAME for a32
col DESCRIPTION for a80
col VALUE for a15
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('db_domain','db_files','db_writer_processes','processes','sessions','open_cursors','session_cached_cursors','session_max_open_files','cursor_sharing','job_queue_processes')
--  and  val.KSPPSTVL is not null
order by 1,2 ;

prompt
prompt *** Current processes and sessions Details ***

select inst_id, resource_name, current_utilization, max_utilization from gv$resource_limit where resource_name in ('processes','sessions') order by 1,2 ;

prompt
prompt *** GLOBAL_NAME DETAILS *** ENFORCE FQDN ***

col VALUE$ for a32
col COMMENT$ for a32
col RESOURCE_NAME for a32
select value$, comment$ from sys.props$ where name = 'GLOBAL_DB_NAME';
col DESCRIPTION for a64
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE, nam.con_id from x$ksppi nam, x$ksppsv val where nam.indx = val.indx and nam.ksppinm in ('global_names')
order by 1,2 ;


prompt
prompt *** DATABASE STATUS DETAILS ***

col INSTANCE_NAME for a18
col STATUS for a12
col DATABASE_STATUS for a12
col VERSION for a12
col LOGINS for a12
col LOG_MODE for a12
col OPEN_MODE for a12
col DATABASE_ROLE for a18
col DB_UNIQUE_NAME for a14
col OPEN_MODE for a20
col STARTUP_TIME for a22
col SYSDATE for a22
col HOST_NAME heading "HOST_NAME" for a23
col NAME FORMAT a10
col flashback_on FORMAT a12
col force_logging FORMAT a13
col current_scn for 9999999999999999
SELECT DISTINCT instance_number,instance_name,status,database_status,logins,cast(substr(host_name,1,19) as VARCHAR2(22))||'...' "HOST_NAME...",version,startup_time,sysdate FROM gv$instance order by 1;
SELECT DISTINCT inst_id, dbid,name,db_unique_name,log_mode,open_mode,database_role,flashback_on,force_logging,current_scn,sysdate FROM gv$database order by 1 ;

prompt
prompt *** DATA GUARD DETAILS ***

col dataguard_broker for a16 tru
col remote_archive for a14
col supplemental_log_data_min for a25
col supplemental_log_data_pk for a24
col supplemental_log_data_ui for a24
col SWITCHOVER_STATUS for a32
select remote_archive,supplemental_log_data_min,supplemental_log_data_pk,supplemental_log_data_ui,switchover_status,dataguard_broker from v$database;

prompt
prompt *** RECOVERY AREA DETAILS ***

show parameter db_recovery_file_dest

col NAME for a32
col DESCRIPTION for a65
col VALUE for a55
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like '%flashback_retention%'
  and  val.KSPPSTVL is not null
order by 1;

col name for a40
col space_limit_MB for 9999999999999999
col space_used_MB for 9999999999999999
col space_reclaimable_MB for 9999999999999999
SELECT name,space_limit/1024/1024 space_limit_MB,space_used/1024/1024 space_used_MB,space_reclaimable/1024/1024 space_reclaimable_MB FROM v$recovery_file_dest;
SELECT * FROM v$flash_Recovery_area_usage;

prompt
prompt *** Archive Logging? ***

archive log list ;

prompt
prompt *** BCT DETAILS *** listed at CDB level only ***

col FILENAME for a80
select * from v$block_change_tracking;

prompt
prompt *** PLATFORM and CREATED DETAILS ***

col PLATFORM_NAME for a32
select CONTROLFILE_CREATED, CREATED DB_CREATED, PLATFORM_ID, PLATFORM_NAME  from v$database;

prompt
prompt *** CPU LIMIT ***

col DESCRIPTION for a50
col VALUE for a15
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'cpu_count' and  val.KSPPSTVL is not null ;

prompt
prompt *** CPU - CORE DETAILS ***

set pagesize 299 lines 299
col STAT_NAME for a22
col VALUE for a26
select STAT_NAME,to_char(VALUE) as VALUE ,COMMENTS from v$osstat where stat_name IN ('NUM_CPUS','NUM_CPU_CORES','NUM_CPU_SOCKETS')
union
select STAT_NAME,VALUE/1024/1024/1024 || ' GB' ,COMMENTS from v$osstat where stat_name IN ('PHYSICAL_MEMORY_BYTES') ;

prompt
prompt *** DB SIZE DETAILS ***

select sum(bytes)/1024/1024/1024 DB_Size_in_GB from v$datafile;
select sum(bytes)/1024/1024/1024 DB_Free_Space_in_GB from dba_free_space;

prompt
prompt *** VERSION DETAILS ***

col BANNER for a80
SELECT banner FROM v$version;

prompt
prompt *** REGISTRY DETAILS ***

col COMP_ID for a18
col COMP_NAME for a55
select comp_id,comp_name,version,status from dba_registry
order by 1;

prompt
prompt *** UNIFIED AUDITING DETAILS *** FALSE = mixed mode

SELECT value FROM v$option WHERE parameter = 'Unified Auditing';

prompt
prompt *** Viewing PDB$SEED related info in CDB_* views DETAILS *** Always set exclude_seed_cdb_view to FALSE in multitenant envs

show parameter _exclude_seed_cdb_view

/*
prompt
prompt *** ENCRYPTION DETAILS ***

SET LINESIZE 220
col STATUS for a15
col USER for a8
col CON_ID for 99999
col CREATOR for a10
col KEY_USE for a11
col KEY_ID for a55
col CREATION_TIME for a36
col ACTIVATION_TIME for a36
col WALLET_ORDER for a12
col FULLY_BACKED_UP for a15
col wrl_parameter for a48
SELECT * FROM v$encryption_wallet;

prompt
prompt *** TDE KEYS ***

SELECT CON_ID, CREATOR, USER, CREATION_TIME, ACTIVATION_TIME, KEY_USE, key_id FROM v$encryption_keys order by CON_ID;

prompt
prompt *** TDE KEYSTORES ***

col TAG for a18
col CREATOR_PDBNAME for a25
col ACTIVATING_PDBNAME for a25
col ORIGIN for a8
select con_id,tag,substr(key_id,1,6)||'...' "KEY_ID...",creator,key_use,keystore_type,origin,creator_pdbname,activating_pdbname from v$encryption_keys order by con_id ;

prompt
prompt *** PDBs ***

col NAME for a10
col CREATION_TIME for a25
col OPEN_TIME for a35
select con_id, NAME, DBID, GUID, OPEN_MODE, RESTRICTED, CREATION_TIME, OPEN_TIME, local_undo
from v$pdbs order by 1 ;

prompt
prompt *** PDB VIOLATIONS ***

set lines 220
col TIME for a29
col NAME for a18
col CAUSE for a25
col MESSAGE for a50
select time, type, name, cause, status, message from PDB_PLUG_IN_VIOLATIONS order by name;
*/

prompt
prompt *** MULTITENNANT DETAILS ***

select cdb from v$database;

prompt
prompt *** ALERT LOG LOCATION ***

col alert_log for a95
select vd.value||'/alert_'||vi.instance_name||'.log' "alert_log" from v$diag_info vd ,v$instance vi where vd.name like 'Diag Trace';

prompt
prompt *** PROXY DETAILS ***

col SESSION_USER for a22
col SESSION_SCHEMA for a22
col CURRENT_SCHEMA for a22
col PROXY_USER for a22

select sys_context('userenv','session_user') session_user,
       sys_context('userenv','session_schema') session_schema,
       sys_context('userenv','current_schema') current_schema,
       sys_context('userenv','proxy_user') proxy_user
from dual;

prompt
prompt *** Current Session Details ***

@init.sql
