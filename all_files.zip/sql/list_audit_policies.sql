-- $Name$ list_audit_policies.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** Audit Review -- DBA_OBJ_AUDIT_OPTS ***
prompt
select OWNER, OBJECT_NAME, OBJECT_TYPE FROM DBA_OBJ_AUDIT_OPTS order by OWNER ;
PROMPT
PROMPT Audit Policies
SET LINESIZE 200
COLUMN audit_option FORMAT A15
COLUMN condition_eval_opt FORMAT A10
COLUMN audit_condition FORMAT A50

SELECT audit_option,
       condition_eval_opt,
       audit_condition
FROM   audit_unified_policies
Where audit_condition != 'NONE';

prompt *** Audit By Access -- DBA_STMT_AUDIT_OPTS ***

set lines 220 pages 100
col USER_NAME format a18
col AUDIT_OPTION for a35
select USER_NAME,AUDIT_OPTION,SUCCESS,FAILURE
from sys.dba_stmt_audit_opts
order by USER_NAME, AUDIT_OPTION ;
prompt
prompt *** Review last archive timestamp ***
prompt
COLUMN audit_trail FORMAT A20
COLUMN last_archive_ts FORMAT A40
select * from DBA_AUDIT_MGMT_LAST_ARCH_TS;


/*
audit CREATE SESSION;
audit CREATE USER ;
audit ALTER USER  ;
audit DROP USER ;
audit CREATE PROFILE ;
audit ALTER PROFILE ;
audit DROP PROFILE ;
audit ALTER SYSTEM ;
audit CREATE ANY TABLE ;
audit ALTER ANY TABLE ;
audit DROP ANY TABLE ;
audit CREATE ANY PROCEDURE ;
audit ALTER ANY PROCEDURE ;
audit DROP ANY PROCEDURE ;
audit CREATE EXTERNAL JOB ;
audit CREATE ANY JOB ;
audit CREATE ANY LIBRARY ;
audit ALTER DATABASE ;
audit GRANT ANY PRIVILEGE ;
audit GRANT ANY OBJECT PRIVILEGE ;
audit GRANT ANY ROLE ;

audit ALTER ANY PROCEDURE by access ;	
audit ALTER ANY TABLE by access ;
audit ALTER DATABASE by access ;
audit ALTER PROFILE by access ;	
audit ALTER SYSTEM by access ;
audit ALTER USER by access ;
audit audit SYSTEM by access ;	
audit CREATE ANY JOB by access ;	
audit CREATE ANY LIBRARY by access ;		
audit CREATE ANY PROCEDURE by access ;		
audit CREATE ANY TABLE by access ;		
audit CREATE EXTERNAL JOB by access ;		
audit CREATE PUBLIC DATABASE LINK by access ;		
audit CREATE SESSION by access ;		
audit CREATE USER by access ;		
audit DATABASE LINK by access ;		
audit DIRECTORY by access ;		
audit DROP ANY PROCEDURE by access ;		
audit DROP ANY TABLE by access ;		
audit DROP PROFILE by access ;		
audit DROP USER by access ;	
audit EXEMPT ACCESS POLICY by access ;		
audit GRANT ANY OBJECT PRIVILEGE by access ;		
audit GRANT ANY PRIVILEGE by access ;
audit GRANT ANY ROLE by access ;	
audit PROFILE by access ;	
audit PUBLIC SYNONYM by access ;		
audit ROLE by access ;		
audit SYSTEM audit by access ;		
audit SYSTEM GRANT by access ;	
audit AUDIT, INSERT, UPDATE, DELETE ON SYS.AUD$ by access ;
audit AUDIT, INSERT, UPDATE, DELETE ON AUDSYS.AUD$UNIFIED by access ;
*/
