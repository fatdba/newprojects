-- $Name$
-- $Log$: Modified - 11 Jan 2020
--                 - 27 Jan 2020 - SC - Cast on userhost for easier reading in ExaCC hosts
--
-- $Author$: Shawn Craven

set lines 340 pages 100
COL timestamp#	FORMAT A20      HEADING 'Time Stamp'
COL os_username	FORMAT A20      HEADING 'UserID'
COL username	FORMAT A20      HEADING 'Name'
COL userhost	FORMAT A25      HEADING 'Host'
COL EXTENDED_TIMESTAMP FOR A35  HEADING 'Timestamp'
COL ACTION_NAME FORMAT A18      HEADING 'ACTION_NAME'
select os_username,  username, cast(substr(userhost,1,19) as VARCHAR2(22))||'...' "USER_HOST...", timestamp, action_name,
       logoff_time, sessionid, returncode, extended_timestamp, os_process
       --,instance_number
from dba_audit_trail
where action between 100 and 102
and   username not in ('DBSNMP','SYSMAN','SYSTEM')
and   timestamp > sysdate -4 ;
