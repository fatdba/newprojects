col pga_target_for_estimate for 999,999,999,999,999,999
col ESTD_EXTRA_BYTES_RW for 999,999,999,999,999,999

PROMPT *** MEMORY TARGET Advisor ***
select pga_target_for_estimate,pga_target_factor,estd_extra_bytes_rw from v$pga_target_advice;

PROMPT *** SGA Advisor ***
select sga_size,sga_size_factor,estd_db_time from v$sga_target_advice;

PROMPT *** MEMORY TARGET Advisor *** 
select memory_size,memory_size_factor,estd_db_time from v$memory_target_advice;
