-- $Name$ list_noncdb_users.sql
--
-- $Log$: Modified - 05 May 2022  - SC - Creation
--                 - 19 Sep 2022  - SC - Removed password_change_date column as it only exists in 19c and up

-- $Author$: Shawn Craven

set lines 220 pages 100
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a22
col COMMON for a6
col LAST_LOGIN for a22
col PASSWORD_CHANGE_DATE for a22
col PASSWORD_EXPIRY_DATE for a22
col CON_ID for 999999
--select username, account_status, created, profile, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, to_char(password_change_date, 'DD-MON-RRRR hh24:mi:ss') as password_change_date, to_char(expiry_date, 'DD-MON-RRRR hh24:mi:ss') as password_expiry_date, password_versions from dba_users 
select username, account_status, created, profile, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, to_char(expiry_date, 'DD-MON-RRRR hh24:mi:ss') as password_expiry_date, password_versions from dba_users 
where ORACLE_MAINTAINED != 'Y'
order by 1 ;
