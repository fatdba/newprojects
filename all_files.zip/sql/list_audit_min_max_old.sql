SELECT DBID "CURRENT DBID" FROM V$DATABASE;

SET TIMING ON
set lines 220 
col "Earliest" format a30
col "Latest" format a30

PROMPT Counting the DBIDs and the number of audit entries each
PROMPT Could take a while...
col TIMESTAMP# for A3
SELECT DBID,COUNT(*),MIN(NTIMESTAMP#) "Earliest", MAX(NTIMESTAMP#) "Latest"
FROM sys.AUD$
GROUP BY DBID;
