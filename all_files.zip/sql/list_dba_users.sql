-- $Name$ list_dba_users.sql
--
-- $Log$: Modified - 16 Jun 2015 - SC - Creation.
--                 - 02 Mar 2023 - SC - Modified query to user dba_role_privs view.
--                 - 12 Sep 2023 - SC - Modified GRANTEE column width from a12 to a22.
--                 
-- $Author$: Shawn Craven (scraven@renaps.com)
--
set lines 220 pages 100

prompt
prompt *** Summary of all users with the DBA role assigned ***
prompt

col GRANTEE for a22
col GRANTED_ROLE for a12 
col ADMIN_OPTION for a12 
col DELEGATE_OPTION for a12
col DEFAULT_ROLE for a12
col COMMON for a12
col INHERITED for a12
select * from dba_role_privs where granted_role='DBA' order by GRANTEE ;
