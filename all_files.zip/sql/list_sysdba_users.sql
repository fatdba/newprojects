-- $Name$: list_sysdba_users.sql
--
-- $Log$:  Modified - 04 Sept 2018 - SC - Creation
--                    19 June 2020 - SC - Added CATALOG_ROLE query
--                    27 May 2023  - SC - Cleanup the v$pwfile_users query.
--
-- $Author$: Shawn Craven (scraven@renaps.com)

set lines 220

col CON_ID format 99999
col COMMON format a6
col SYSDBA format a6
col SYSOPER format a6
col SYSASM format a6
col SYSBACKUP format a10
col SYSDG format a6
col SYSKM format a6
col USERNAME format a15
col ACCOUNT_STATUS format a15
col EXTERNAL_NAME format a15
col PASSWORD_PROFILE format a16
col LAST_LOGIN for a20
col LOCK_DATE for a20
col EXPIRY_DATE for a20

prompt
prompt *** Users with SYSDBA ***
prompt
select CON_ID
,COMMON
,USERNAME
,SYSDBA
,SYSOPER
,SYSASM
,SYSBACKUP
,SYSDG
,SYSKM
,ACCOUNT_STATUS
,PASSWORD_PROFILE
,to_char(LAST_LOGIN, 'DD-MON-RRRR hh24:mi:ss')  as LAST_LOGIN
,to_char(LOCK_DATE, 'DD-MON-RRRR hh24:mi:ss')   as LOCK_DATE
,to_char(EXPIRY_DATE, 'DD-MON-RRRR hh24:mi:ss') as EXPIRY_DATE
,EXTERNAL_NAME
,AUTHENTICATION_TYPE
from v$pwfile_users
order by CON_ID ;

col GRANTEE for a32
col GRANTED_ROLE for a32

prompt
prompt *** Roles and Users with %_CATALOG_ROLE privs ***
prompt

SELECT grantee,
       granted_role,
       default_role
  FROM dba_role_privs
 WHERE 1 = 1
   AND grantee IN ('DBA','SYS','SYSTEM')
   AND granted_role IN ('DELETE_CATALOG_ROLE','EXECUTE_CATALOG_ROLE','SELECT_CATALOG_ROLE')
 ORDER BY 1, 2;
