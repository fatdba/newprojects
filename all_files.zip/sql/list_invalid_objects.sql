-- $Name$ list_invalid_objects.sql
-- 
-- $Log$: Modified - 04 Sep 2015 - SC - Creation
--                 - 05 Feb 2020 - SC - Modified report output 
--                 - 12 Feb 2020 - SC - Modified to recompile TYPE objects 
--                 - 03 Sep 2024 - SC - Ignoring invalid synonyms
--
-- $Author$: Shawn Craven

-- Set environment settings for output display
SET PAGESIZE 1000
SET LINESIZE 120

COLUMN owner FORMAT A30
COLUMN object_name FORMAT A30
COLUMN object_type FORMAT A30
COLUMN comp_id FORMAT A20
COLUMN comp_name FORMAT A40
COLUMN version FORMAT A12
COLUMN status FORMAT A15
COLUMN dbname FORMAT A15

-- Output the database name for context
PROMPT DATABASE NAME
PROMPT =============
SELECT sys_context('USERENV','DB_NAME') DBNAME FROM dual;

-- Count and display the number of invalid objects excluding synonyms
PROMPT COUNT OF INVALID OBJECTS (EXCLUDING SYNONYMS)
PROMPT ===========================================
SELECT count(*) 
FROM dba_objects 
WHERE status='INVALID' 
AND object_type != 'SYNONYM';

-- Display the count of invalid objects grouped by object type and owner, excluding synonyms
PROMPT INVALID OBJECTS GROUPED BY OBJECT TYPE AND OWNER (EXCLUDING SYNONYMS)
PROMPT =============================================================
SELECT owner, object_type, count(*) 
FROM dba_objects 
WHERE status='INVALID' 
AND object_type != 'SYNONYM' 
GROUP BY owner, object_type;

-- Display the contents of the DBA registry, applicable for versions >= 9.2.0
PROMPT DBA_REGISTRY CONTENTS (VIEW DOES NOT EXIST IN VERSIONS < 9.2.0)
PROMPT ================================================================
SELECT comp_id, comp_name, version, status 
FROM dba_registry;

-- List all invalid objects excluding synonyms
PROMPT LIST OF INVALID OBJECTS (EXCLUDING SYNONYMS)
PROMPT ============================================
SELECT owner, object_name, object_type 
FROM dba_objects 
WHERE status='INVALID' 
AND object_type != 'SYNONYM';

-- Generate the script to recompile invalid objects excluding synonyms
SET HEADING OFF
SET PAGESIZE 0
SET LINESIZE 79
SET VERIFY OFF
SET ECHO OFF
SET FEEDBACK OFF

--spool validate_all.sql  -- Uncomment to save the recompile commands to a file

SELECT
    DECODE(OBJECT_TYPE, 
           'PACKAGE BODY', 'ALTER PACKAGE ' || OWNER || '.' || CHR(34) || OBJECT_NAME || CHR(34) || ' COMPILE BODY;',
           'ALTER ' || OBJECT_TYPE || ' ' || OWNER || '.' || CHR(34) || OBJECT_NAME || CHR(34) || ' COMPILE;'
    )
FROM dba_objects
WHERE status = 'INVALID' 
AND object_type IN ('PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'TYPE', 'VIEW')
AND object_type != 'SYNONYM'
ORDER BY owner, object_type, object_name;

--spool off  -- Uncomment to stop saving the output to the file

-- Reset environment settings
SET HEADING ON
SET PAGESIZE 100
SET LINESIZE 220
SET VERIFY ON
SET FEEDBACK ON
SET ECHO OFF