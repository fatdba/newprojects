col PROXY for a18
col CLIENT for a18
select * from proxy_users;

ALTER USER &PROXY_TO GRANT CONNECT THROUGH &YOUR_ACCOUNT ;

select * from proxy_users;
