-- $Name$: list_nondefault_schema_object_owners.sql
--
-- $Log$:  Modified - 04 Sept 2015 - creation
--
-- $Author$: Shawn Craven

prompt
prompt *** Non Default Schemas ***
prompt
set lines 220
col OWNER for a25
select distinct owner from dba_objects where OWNER not in 
('APPQOSSYS','AUDSYS','DBSNMP','DBSFWUSER','GSMADMIN_INTERNAL','MDSYS','ORACLE_OCM','OUTLN','PUBLIC','CTXSYS','OJVMSYS','ORDSYS','ORDDATA','REMOTE_SCHEDULER_AGENT','SYS','SYSTEM','WMSYS','XDB')
ORDER BY 1 ;
