-- $Name$: chg_sys_system_passwds.sql
--
-- $Log$:  Modified - 12 Jun 2023 - SC - Creation
--
-- Note: Passwords are echoed in clear text. Future enhancement required.
--
-- $Author$: Shawn Craven (scraven@renaps.com)


SET SERVEROUTPUT ON SIZE UNLIMITED

-- Prompt for the new SYS password
ACCEPT new_sys_password PROMPT 'Enter the new password for SYS: ' HIDE

-- Prompt for the new SYSTEM password
ACCEPT new_system_password PROMPT 'Enter the new password for SYSTEM: ' HIDE

-- Clear the buffer to partially obfuscate the password
SET TERMOUT OFF
/
SET TERMOUT ON

-- Define a PL/SQL block to change the SYS and SYSTEM passwords
DECLARE
  new_sys_pass VARCHAR2(100) := '&new_sys_password';
  new_system_pass VARCHAR2(100) := '&new_system_password';
BEGIN
  EXECUTE IMMEDIATE 'ALTER USER SYS IDENTIFIED BY "' || new_sys_pass || '"';
  EXECUTE IMMEDIATE 'ALTER USER SYSTEM IDENTIFIED BY "' || new_system_pass || '"';
  DBMS_OUTPUT.PUT_LINE('Passwords changed successfully.');
END;
/
