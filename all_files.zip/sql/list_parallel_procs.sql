-- $Name$
-- $Log$: Modified - 15 Aug 2011
-- $Author$: Shawn Craven

prompt *** Parallel Process Details ***

col username for a12
col "QC SID" for A6
col SID for A6
col "Inst" form A3
col "QC/Slave" for A10
col "Requested DOP" for 9999
col "Actual DOP" for 9999
col "slave set" for  A10
col "Event" for a26
set pages 100
set lines 1200

select
  decode(px.qcinst_id,NULL,username,
        ' - '||lower(substr(s.program,length(s.program)-4,4) ) ) "Username",
  decode(px.qcinst_id,NULL, 'QC', '(Slave)') "QC/Slave" ,
  to_char( px.server_set) "Slave Set",
  to_char(s.sid) "SID",
  to_char(s.inst_id) "Inst",
  decode(px.qcinst_id, NULL ,to_char(s.sid) ,px.qcsid) "QC SID",
  px.req_degree "Requested DOP",
  px.degree "Actual DOP" ,
  s.event "Event"
from
  gv$px_session px,
  gv$session s
where
  px.sid=s.sid (+)  and
  px.serial#=s.serial# and
  px.inst_id = s.inst_id
order by 6 , 5 asc, 1 desc ;

