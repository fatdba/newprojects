-- $Name$ cr_validate_all.sql
-- $Log$: Modified - 04 Sept 2015
-- $Author$: Shawn Craven

set pages 1000
set lines 120
col owner format a30
col object_name format a30
col object_type format a30
col comp_id format a20
col comp_name format a40
col version format a12
col status format a15
col dbname format a15
--spool INVALID_OBJECTS_AND_REGISTRY_INFO.lst
PROMPT DATABASE NAME
PROMPT =============
select sys_context('USERENV','DB_NAME') DBNAME from dual;
PROMPT COUNT OF INVALID OBJECTS
PROMPT ========================
select count(*) from dba_objects where status='INVALID';
PROMPT INVALID OBJECTS GROUPED BY OBJECT TYPE AND OWNER
PROMPT ================================================
select owner,object_type,count(*) from dba_objects where status='INVALID' group by owner,object_type;
PROMPT DBA_REGISTRY CONTENTS (VIEW DOES NOT EXISIT IN VERSIONS < 9.2.0)
PROMPT ================================================================
select comp_id,comp_name,version,status from dba_registry;
--spool off
--spool INVALID_OBJECTS.lst
PROMPT LIST OF INVALID OBJECTS
PROMPT =======================
select owner,object_name,object_type from dba_objects where status='INVALID';
--spool off
----
set heading off
set pagesize 0
set linesize 79
set verify off
set echo off
set feedback off

--spool validate_all.sql

select
    decode( OBJECT_TYPE, 'PACKAGE BODY',
    'alter package ' || OWNER||'.'||chr(34)||OBJECT_NAME||chr(34)|| ' compile body ;',
    'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||chr(34)||OBJECT_NAME||chr(34)|| ' compile ;' )
from
   dba_objects
where
   STATUS = 'INVALID' and OBJECT_TYPE in
   ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW' )
order by OWNER, OBJECT_TYPE, OBJECT_NAME;

--spool off

set heading on
set pagesize 0
set linesize 220
set verify on
set feedback on
set echo off
