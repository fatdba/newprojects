-- $Name$ list_dbms_scheduler_jobs.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** DBMS_SCHEDULER JOB DETAILS ***
prompt

set lines 200
col OWNER format a20
col JOB_NAME format a35
col NEXT_RUN_DATE for a45
col STATE for a22
select OWNER, JOB_NAME, ALLOW_RUNS_IN_RESTRICTED_MODE "ALLOW_RUN_RESTRICTED", ENABLED, STATE, SYSTEM, NEXT_RUN_DATE 
  from dba_scheduler_jobs 
 where OWNER not in ('ORACLE_OCM','SYS','SYSTEM')
 order by 1, 2;
