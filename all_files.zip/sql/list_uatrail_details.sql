 -- $Name$ list_uatrail_details.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

set lines 220 pages 100
col event_timestamp for a30
col dbusername for a12
col sql_text for a80
col client_program_name for a32
col action_name for a32
select event_timestamp, dbusername, sql_text,client_program_name,action_name
from unified_audit_trail 
--where dbusername not in ('SYS','SYSTEM')
where dbusername not like 'SYS%'
order by event_timestamp desc ;
