-- $Name$: lag.sql
--
-- $Log$: Modified - 11 Mar 2019 - created
--        Modified - 05 Apr 2021 - Added thread details
--        Modified - 05 Aug 2021 - Added Archive Destination Status
--
-- $Author$: Shawn Craven (scraven@renaps.com)

alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';

PROMPT
PROMPT *** Data Guard Status ***
PROMPT
set pages 1000 lines 250
col dataguard_broker for a16 tru
col remote_archive for a14
col SWITCHOVER_STATUS for a32
col FLASHBACK_ON for a12
select db_unique_name,FLASHBACK_ON,remote_archive,switchover_status,dataguard_broker,database_role,PROTECTION_LEVEL,PROTECTION_MODE from v$database;

PROMPT
PROMPT *** MRP Status ***
PROMPT
select INST_ID,PID,PROCESS,STATUS,THREAD#,SEQUENCE#,BLOCK# from gv$managed_standby;

--set feedback off
set timing off
--spool lag.txt
SELECT sum(ARCH.SEQUENCE# - APPL.SEQUENCE#) "Logs Behind"
FROM
(SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,
(SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL
WHERE
ARCH.THREAD# = APPL.THREAD# ;

col SOURCE_DB_UNIQUE_NAME for a22
col NAME for a25
col VALUE for a25
col TIME_COMPUTED for a20
col DATUM_TIME for a19
SELECT * FROM v$dataguard_stats;

set linesize 400
col Values for a65
col Recover_start for a21
select to_char(START_TIME,'dd.mm.yyyy hh24:mi:ss') "Recover_start",to_char(item)||' = '||to_char(sofar)||' '||to_char(units)||' '|| to_char(TIMESTAMP,'dd.mm.yyyy hh24:mi') "Values" from v$recovery_progress where start_time=(select max(start_time) from v$recovery_progress);

col units format a8
col GAP format a30
col COMMENTS for a20
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
select INST_ID,START_TIME,UNITS,TIMESTAMP applied_until,sysdate current_time,comments from gv$recovery_progress where ITEM='Last Applied Redo' order by INST_ID ;

PROMPT
PROMPT *** Archive Destination Status ***
PROMPT
col DEST_NAME for a30
select DEST_ID,dest_name,status,type,srl,recovery_mode from v$archive_dest_status where dest_id=1;

PROMPT
PROMPT *** Highest Sequence Details ***
PROMPT
SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Last Sequence Received", APPL.SEQUENCE# "Last Sequence Applied", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Difference" FROM (SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,(SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL WHERE ARCH.THREAD# = APPL.THREAD# ORDER BY 1;
PROMPT
PROMPT *** Alert Log Location ***
PROMPT
col alert_log for a95
select vd.value||'/alert_'||vi.instance_name||'.log' "alert_log" from v$diag_info vd ,v$instance vi where vd.name like 'Diag Trace';
