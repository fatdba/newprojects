-- $Name$ list_priv_capture_privs.sql
--
-- $Log$  Modified - 04 Aug 2022 - GF - Creation

-- $Author$: Shawn Craven

set lines 220 pages 100
set linesize 200
COLUMN name FORMAT A15
COLUMN description FORMAT a28
COLUMN roles FORMAT A8
COLUMN context FORMAT A72
COLUMN run_name FORMAT A17
SET LINESIZE 200

SELECT name,
       description,
       type,
       enabled,
       roles,
       context,
       run_name
FROM   dba_priv_captures
ORDER BY name;
