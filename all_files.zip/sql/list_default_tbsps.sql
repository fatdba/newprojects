-- $Name$ list_default_tbsps.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** DEFAULT TBSP DETAILS ***
prompt

col PROPERTY_NAME for a30
col PROPERTY_VALUE for a28
SELECT PROPERTY_NAME, PROPERTY_VALUE
FROM DATABASE_PROPERTIES
WHERE PROPERTY_NAME IN ('DEFAULT_PERMANENT_TABLESPACE','DEFAULT_TEMP_TABLESPACE') ;

prompt
prompt (syntax to remedy if required)
prompt ALTER DATABASE DEFAULT TABLESPACE USERS ;
prompt ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TEMP ;
