--------------------------------------------------------------------------------
--
-- Name:	init.sql
-- Purpose:	Initializes sqlplus variables for 156 character terminal
--		width and other settings.
--
-- Author:	Tanel Poder
-- Copyright:	(c) http://www.tanelpoder.com
-- 
-- Other:	Some settings Windows specific
--		Assumes SQLPATH variable set to point to TPT script directory
--
--------------------------------------------------------------------------------

-- this must be here to avoid logon problems when SQLPATH env variable is unset
def SQLPATH=""


-- set SQLPATH variable to either Unix or Windows format

def SQLPATH=$SQLPATH -- (Unix)
--def SQLPATH=%SQLPATH%


-- def _start=start   -- Windows
-- def _start=firefox -- Unix/Linux
def _start=open -- MacOS

def _delete="rm -f"

def _tpt_tempdir=&SQLPATH/tmp

-- some internal variables required for TPT scripts

	define _ti_sequence=0
	define _tptmode=normal
	define _xt_seq=0

  define all='"select /*+ no_merge */ sid from v$session"'

-- you should change linesize to match terminal width - 1 only 
-- if you don't have a terminal with horizontal scrolling
-- capability (cmd.exe and Terminator terminal do have horizontal scrolling)

	set linesize 999

-- set truncate after linesize on

    -- set truncate on

-- set pagesize larger to avoid repeting headings

	set pagesize 5000

-- fetch 10000000 bytes of long datatypes. good for
-- querying DBA_VIEWS and DBA_TRIGGERS

	set long 10000000
	set longchunksize 10000000

-- larger arraysize for faster fetching of data
-- note that arraysize can affect outcome of experiments
-- like buffer gets for select statements etc.

	set arraysize 500

-- normally I keep this commented out, otherwise
-- a DBMS_OUTPUT.GET_LINES call is made after all
-- PL/SQL executions from sqlplus. this may distort
-- execution statistics for experiments

	--set serveroutput on size unlimited

-- to have less garbage on screen

	set verify off

-- to trim trailing spaces from spool files

	set trimspool on

-- to trim trailing spaces from screen output

	set trimout on

-- don't use tabs instead of spaces for "wide blanks"
-- this can mess up the vertical column locations in output

	set tab off

-- this makes describe command better to read and more
-- informative in case of complex datatypes in columns
				
	set describe depth 1 linenum on indent on

-- you can make sqlplus run any command as your editor
-- I could use "start notepad" on windows if you want to 
-- return control back to sqlplus immediately after launching
-- notepad (so that you can continue typing in sqlplus

	define _editor="vi -c 'set notitle'"  
--	define _external_editor="/Applications/Terminator.app/Contents/MacOS/Terminator vi "  

-- assign the tracefile name to trc variable

    def trc=unknown

	column tracefile noprint new_value trc

	-- its nice to have termout off here as otherwise this would be
	-- displayed on the screen
	set termout off

	select value ||'/'||(select instance_name from v$instance) ||'_ora_'||
	       (select spid||case when traceid is not null then '_'||traceid else null end
                from v$process where addr = (select paddr from v$session
	                                         where sid = (select sid from v$mystat
	                                                    where rownum = 1
	                                               )
	                                    )
	       ) || '.trc' tracefile
	from v$parameter where name = 'user_dump_dest';

-- make default date format nicer

	alter session set nls_date_format = 'YYYYMMDD HH24:MI:SS';

-- include username and connect identifier in prompt

--	column pr new_value _pr
--	select initcap('&_user@&_connect_identifier> ') pr from dual;
--	set sqlprompt "&_pr"
--	column _pr clear


-- format some more columns for common DBA queries

	col first_change# for 99999999999999999
	col next_change# for 99999999999999999
	col checkpoint_change# for 99999999999999999
	col resetlogs_change# for 99999999999999999
	col plan_plus_exp for a100
	col value_col_plus_show_param ON HEADING  'VALUE'  FORMAT a100

-- set html format

@@htmlset nowrap "&_user@&_connect_identifier report"

-- set seminar logging file

DEF _tpt_tempfile=sqlplus_tmpfile

col seminar_logfile new_value seminar_logfile
col tpt_tempfile new_value _tpt_tempfile

select 
    to_char(sysdate, 'YYYYMMDD-HH24MISS') seminar_logfile 
  , instance_name||'-'||to_char(sysdate, 'YYYYMMDD-HH24MISS') tpt_tempfile
from v$instance;

def seminar_logfile=&SQLPATH/logs/&_tpt_tempfile..log

-- spool sqlplus output
spool &seminar_logfile append

set editfile afiedit.sql

-- reset termout back to normal

	set termout on

-- the Who am I script

def   mysid="NA"
def _i_spid="NA"
def _i_cpid="NA"
def _i_opid="NA"
def _i_serial="NA"
def _i_inst="NA"
def _i_host="NA"
def _i_user="&_user"
def _i_conn="&_connect_identifier"

col i_username head USERNAME for a20
col i_sid head SID for a5 new_value mysid
col i_serial head SERIAL# for a8 new_value _i_serial
col i_cpid head CPID for a15 new_value _i_cpid
col i_spid head SPID for a15 new_value _i_spid
col i_opid head OPID for a5 new_value _i_opid
col i_host_name head HOST_NAME for a25 new_value _i_host
col i_instance_name head INST_NAME for a12 new_value _i_inst
col i_ver head VERSION for a10
col i_startup_day head STARTED for a8
col _i_user noprint new_value _i_user
col _i_conn noprint new_value _i_conn
col i_myoraver noprint new_value myoraver

select 
	s.username			i_username, 
	i.instance_name	i_instance_name, 
	--i.host_name			i_host_name, 
        cast(substr(i.host_name,1,30) as VARCHAR2(22))||'...' "HOST_NAME...",
	to_char(s.sid) 			i_sid, 
	to_char(s.serial#)		i_serial, 
	(select substr(banner, instr(banner, 'Release ')+8,10) from v$version where rownum = 1) i_ver,
	(select  substr(substr(banner, instr(banner, 'Release ')+8),
	 		1,
			instr(substr(banner, instr(banner, 'Release ')+8),'.')-1)
	 from v$version 
	 where rownum = 1) i_myoraver,
	to_char(startup_time, 'YYYYMMDD') i_startup_day, 
	p.spid				i_spid, 
	trim(to_char(p.pid))		i_opid, 
	s.process			i_cpid, 
	s.saddr				saddr, 
	p.addr				paddr,
	lower(s.username) "_i_user",
	upper('&_connect_identifier') "_i_conn"
from 
	v$session s, 
	v$instance i, 
	v$process p
where 
	s.paddr = p.addr
and 
	sid = (select sid from v$mystat where rownum = 1);

-- Windows CMD.exe specific stuff

--host title &_i_user@&_i_conn [sid=&mysid ser#=&_i_serial spid=&_i_spid inst=&_i_inst host=&_i_host cpid=&_i_cpid opid=&_i_opid]
--host doskey /exename=sqlplus.exe desc=set lines 80 sqlprompt ""$Tdescribe $*$Tset lines 299 sqlprompt "SQL> "

-- short xterm title
host echo -ne "\033]0;&_i_user@&_i_inst &mysid[&_i_spid]\007"
-- long xterm title
--host echo -ne "\033]0;host=&_i_host inst=&_i_inst sid=&mysid ser#=&_i_serial spid=&_i_spid cpid=&_i_cpid opid=&_i_opid\007"


def myopid=&_i_opid
def myspid=&_i_spid
def mycpid=&_i_cpid

undef _i_spid _i_inst _i_host _i_user _i_conn _i_cpid
