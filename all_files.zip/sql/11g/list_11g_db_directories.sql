set lines 220
set pages 9000
col OWNER format a8
col DIRECTORY_NAME format a25
col DIRECTORY_PATH format a100
col ORIGIN_CON_ID  format 9999
select OWNER, DIRECTORY_NAME, DIRECTORY_PATH from dba_directories
order by DIRECTORY_NAME ;
