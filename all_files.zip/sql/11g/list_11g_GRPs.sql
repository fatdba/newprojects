alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';

prompt list of GRPs
set lines 220
column name format a45
col time for a31
column scn format 99999999999999
select NAME, TIME, SCN, GUARANTEE_FLASHBACK_DATABASE, DATABASE_INCARNATION# from v$restore_point order by TIME ;

prompt oldest_flashback_time
select oldest_flashback_time from v$flashback_database_log;
