PROMPT
PROMPT *** Network and ACL assignments ***
PROMPT

set lines 220
COL host FOR A30
COL acl  FOR A60
COL principal FOR A30
COL privilege FOR A30

SELECT host, lower_port, upper_port, acl
FROM   dba_network_acls;

PROMPT
PROMPT *** Privileges associated with the ACLs ***
PROMPT

SELECT acl,
       principal,
       privilege,
       is_grant,
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date,
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date
FROM   dba_network_acl_privileges
ORDER  BY acl, principal, privilege ;
