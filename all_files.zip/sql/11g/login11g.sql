-- $Name$
-- $Log$: Modified - 04 Sept 2018
-- $Author$: Shawn Craven

set linesize 132
set pagesize 71
set time on
set serveroutput on size 1000000 format wrapped 
column object_name format a31; 
column owner format a12; 
column r_owner format a12; 
column table_owner format a12; 
column index_owner format a12; 
column timestamp format a20; 
column db_link format a17; 
column segment_name format a31; 
column name format a31; 
column user_name format a10; 
column username format a10; 
column host format a9; 
column archive_name format a45; 
column log_owner format a12; 
column master_owner format a12; 
column next format a30; 
column master_link format a17; 
column interval format a27; 
column log_user format a11; 
column priv_user format a11; 
column schema_user format a11; 
column column_position format 99 heading "POS"; 
column column_name format a30; 
set long 2000 
set arraysize 1 
set trimspool on 
set tab off 
set termout off break on today 
column today new_value _date 
column name new_value _dbname 
column user new_value _dbuser 
column global_name new_value gname 
define gname=idle 
define _dbname=who 
define _dbuser=ha 
alter session set NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS'; 
select to_char(sysdate,'DD-MON-YY') today from dual; 
col global_name noprint 
--multitennant
--select upper(sys_context ('userenv', 'con_name')) || '@' || lower(sys_context('userenv', 'db_name')) global_name from dual;
--select upper(sys_context ('userenv', 'con_name')) || '@' || lower(sys_context('userenv', 'db_unique_name')) global_name from dual;
--select upper(sys_context ('userenv', 'con_name')) || '@' || lower(sys_context('userenv', 'instance_name')) global_name from dual;
--non CDB
--select name from sys.v_$database;
--select db_unique_name name from sys.v_$database ;
select db_unique_name name from sys.v$database ;
--select instance_name name from sys.v_$instance ;
break on name
clear breaks 
break on user 
select user from dual; 
clear breaks 
set termout on 
set sqlprompt "&_dbname. (&_dbuser) SQL> "
--set sqlprompt "&gname. (&_dbuser) SQL> "
define_editor=vi
