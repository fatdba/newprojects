-- $Name$ info.sql
-- $Log$: Modified - 04 Sep 2018
--                 - 18 Jan 2019
--                 - 03 Feb 2019 - SC - updated long columns to use cast
--                 - 14 Mar 2019 - SC - Cleaned up DG broker details
--                 - 28 May 2019 - SC - Cleaned up MEMORY details--
--                 - 23 Jul 2019 - SC - Added Direct and async I/O check
--
-- $Author$: Shawn Craven

set serveroutput ON lines 2000 pages 2000 echo OFF

prompt *** SPFILE DETAILS ***
col NAME for a32
col DESCRIPTION for a35
col VALUE for a75
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'spfile%'
  and  val.KSPPSTVL is not null
order by 1;

prompt *** BACKGROUND DETAILS ***
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'background%'
  and  val.KSPPSTVL is not null
order by 1;

prompt *** AUDIT DETAILS ***
col NAME for a32
col DESCRIPTION for a48
col VALUE for a45
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('audit_trail','audit_file_dest','audit_sys_operations','audit_syslog_level')
--  and  val.KSPPSTVL is not null
order by 1;

prompt *** Direct and Asynchronous I/O Details      ***
prompt *** disk_asynch_io S/B true                  *** 
prompt *** ignore filesystemio_options if using ASM ***
col NAME for a32
col DESCRIPTION for a48
col VALUE for a45
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('disk_asynch_io','filesystemio_options')
--  and  val.KSPPSTVL is not null
order by 1;

prompt *** DEFAULT CREATE DETAILS ***
col NAME for a32
col DESCRIPTION for a40
col VALUE for a35
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('db_create_file_dest','db_create_online_log_dest_1','db_create_online_log_dest_2')
--  and  val.KSPPSTVL is not null
order by 1;


show parameter diag
prompt
prompt *** MEMORY PARAMETER DETAILS ***
col NAME for a32
col DESCRIPTION for a66
col VALUE for a25
col CON_ID for 99999
col INST_ID for 99999
select distinct nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('streams_pool_size','memory_target','memory_max_target','sga_target','sga_max_size','db_cache_size','shared_pool_size','large_pool_size','java_pool_size','pga_aggregate_limit','pga_aggregate_target')
--  and  val.KSPPSTVL is not null
order by 1;

prompt
prompt *** v$sgainfo ***
col BYTES for 999,999,999,999,999
select * from v$sgainfo ;

prompt *** CPU LIMIT ***

col DESCRIPTION for a50
col VALUE for a15 
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'cpu_count' and  val.KSPPSTVL is not null ;

prompt *** PARALLEL_MAX_SERVERS ***

select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'parallel_max_servers' and  val.KSPPSTVL is not null ;

prompt *** SGA DYNAMIC COMPONENTS ***

SELECT component, current_size/1024/1024 as size_mb, min_size/1024/1024 as min_size_mb
FROM v$sga_dynamic_components
WHERE current_size > 0
ORDER BY component;

prompt

prompt *** HUGEPAGES/LARGE PAGES DETAILS ***

select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like 'use_large_pages' and  val.KSPPSTVL is not null ;

ALTER session SET NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

prompt *** CHARACTERSET DETAILS ***
COLUMN parameter FORMAT A30
COLUMN value FORMAT A30
SELECT *
FROM   nls_database_parameters
WHERE  parameter in ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET','NLS_DATE_FORMAT') order by 1;

prompt *** DATABASE DETAILS ***
col INSTANCE_NAME for a18
col STATUS for a12
col DATABASE_STATUS for a12
col VERSION for a12
col LOGINS for a12
col LOG_MODE for a12
col OPEN_MODE for a12
col DATABASE_ROLE for a18
col DB_UNIQUE_NAME for a18
col OPEN_MODE for a20
col STARTUP_TIME for a22
col SYSDATE for a22
col HOST_NAME heading "HOST_NAME" for a23
col NAME FORMAT a10
col flashback_on FORMAT a12
col force_logging FORMAT a13
col current_scn for 9999999999999999
SELECT DISTINCT instance_number,instance_name,status,database_status,logins,cast(substr(host_name,1,19) as VARCHAR2(22))||'...' "HOST_NAME...",version,startup_time,sysdate FROM gv$instance order by 1;
SELECT DISTINCT inst_id, dbid,name,db_unique_name,log_mode,open_mode,database_role,flashback_on,force_logging,current_scn,sysdate FROM gv$database order by 1 ;

prompt *** DATA GUARD DETAILS ***
col dataguard_broker for a16 tru
col remote_archive for a14
col supplemental_log_data_min for a25
col supplemental_log_data_pk for a24
col supplemental_log_data_ui for a24
col SWITCHOVER_STATUS for a32
select remote_archive,supplemental_log_data_min,supplemental_log_data_pk,supplemental_log_data_ui,switchover_status,dataguard_broker from v$database;

prompt *** RECOVERY AREA DETAILS ***

show parameter db_recovery_file_dest

col NAME for a32
col DESCRIPTION for a65
col VALUE for a45
select nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm like '%flashback_retention%'
  and  val.KSPPSTVL is not null
order by 1;

col name for a40
col space_limit_MB for 9999999999999999
col space_used_MB for 9999999999999999
col space_reclaimable_MB for 9999999999999999
SELECT name,space_limit/1024/1024 space_limit_MB,space_used/1024/1024 space_used_MB,space_reclaimable/1024/1024 space_reclaimable_MB FROM v$recovery_file_dest;
SELECT * FROM v$flash_Recovery_area_usage;

prompt *** BCT DETAILS ***
col FILENAME for a80
select * from v$block_change_tracking;

prompt *** VERSION DETAILS ***
col BANNER for a80
SELECT banner FROM v$version;

prompt *** REGISTRY DETAILS ***
col COMP_ID for a18
col COMP_NAME for a55
select comp_id,comp_name,version,status from dba_registry
order by 1;

prompt *** RESOURCE DETAILS ***
set lines 200 pages 200
col RESOURCE_NAME for a32
select inst_id, resource_name, current_utilization, max_utilization from gv$resource_limit where resource_name in ('processes','sessions') order by inst_id ;

prompt 
col NAME for a32
col DESCRIPTION for a40
col VALUE for a15
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from x$ksppi nam, x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('processes','sessions','open_cursors','session_cached_cursors')
--  and  val.KSPPSTVL is not null
order by 1;


prompt *** UNIFIED AUDITING DETAILS *** FALSE = mixed mode
SELECT value FROM v$option WHERE parameter = 'Unified Auditing';

/*
prompt *** ENCRYPTION DETAILS ***
SET LINESIZE 220
col STATUS for a15
col USER for a8
col CON_ID for 99999
col CREATOR for a10
col KEY_USE for a11
col KEY_ID for a55
col CREATION_TIME for a36
col ACTIVATION_TIME for a36
col WALLET_ORDER for a12
col FULLY_BACKED_UP for a15
col wrl_parameter for a48
SELECT * FROM v$encryption_wallet;

prompt *** TDE KEYS ***

SELECT CON_ID, CREATOR, USER, CREATION_TIME, ACTIVATION_TIME, KEY_USE, key_id FROM v$encryption_keys order by CON_ID;

prompt *** TDE KEYSTORES ***

col TAG for a18
col CREATOR_PDBNAME for a25
col ACTIVATING_PDBNAME for a25
col ORIGIN for a8
select con_id,tag,substr(key_id,1,6)||'...' "KEY_ID...",creator,key_use,keystore_type,origin,creator_pdbname,activating_pdbname from v$encryption_keys order by con_id ;

prompt *** PDBs ***

col NAME for a10
col CREATION_TIME for a25
col OPEN_TIME for a35
select con_id, NAME, DBID, GUID, OPEN_MODE, RESTRICTED, CREATION_TIME, OPEN_TIME, local_undo
from v$pdbs order by 1 ;

prompt *** PDB VIOLATIONS ***

set lines 220
col TIME for a29
col NAME for a18
col CAUSE for a25
col MESSAGE for a50
select time, type, name, cause, status, message from PDB_PLUG_IN_VIOLATIONS order by name;
*/

prompt *** ALERT LOG LOCATION ***
col alert_log for a95
select vd.value||'/alert_'||vi.instance_name||'.log' "alert_log" from v$diag_info vd ,v$instance vi where vd.name like 'Diag Trace';
prompt
prompt *** Current Session Details ***
prompt
--@d:\dbadmin\sql\init.sql
@/software/dbadmin/sql/init.sql
