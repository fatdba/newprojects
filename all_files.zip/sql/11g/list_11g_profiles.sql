set lines 220 pages 100
col PROFILE for a30
col LIMIT for a55
col CON_ID for 99999
select PROFILE,RESOURCE_NAME,RESOURCE_TYPE,LIMIT from dba_profiles order by 1,3,2 ;
