set lines 220
col ACTION_TIME for a30
col ACTION for a15
col NAMESPACE for a15
col BUNDLE_SERIES for a15
col VERSION for a22
col COMMENTS for a25
select action_time, action, namespace, version, id, bundle_series, comments from registry$history
order by 1 DESC ;
