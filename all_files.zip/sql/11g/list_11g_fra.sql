PROMPT
PROMPT *** FRA details ***
PROMPT
set lines 100
col name format a60
select name, floor(space_limit / 1024 / 1024) "Size MB", ceil(space_used / 1024 / 1024) "Used MB"
from v$recovery_file_dest;
PROMPT 
PROMPT *** FRA Occupants ***
PROMPT
SELECT * FROM V$FLASH_RECOVERY_AREA_USAGE;
set lines 220
PROMPT
PROMPT *** Location and size of the FRA ***
PROMPT
col NAME for a32
col DESCRIPTION for a40
col VALUE for a35
col CON_ID for 99999
col INST_ID for 99999
select nam.inst_id INSTANCE, nam.ksppinm NAME, nam.ksppdesc DESCRIPTION, val.KSPPSTVL VALUE
  from sys.x$ksppi nam, sys.x$ksppsv val
where nam.indx = val.indx and nam.ksppinm in ('db_flashback_retention_target','db_recovery_file_dest_size','db_recovery_file_dest')
order by NAME desc;
PROMPT
PROMPT *** Size, Used, Reclaimable ***
SELECT
  ROUND((A.SPACE_LIMIT / 1024 / 1024 / 1024), 2) AS FLASH_IN_GB, 
  ROUND((A.SPACE_USED / 1024 / 1024 / 1024), 2) AS FLASH_USED_IN_GB, 
  ROUND((A.SPACE_RECLAIMABLE / 1024 / 1024 / 1024), 2) AS FLASH_RECLAIMABLE_GB,
  SUM(B.PERCENT_SPACE_USED)  AS PERCENT_OF_SPACE_USED
FROM
  V$RECOVERY_FILE_DEST A,
  V$FLASH_RECOVERY_AREA_USAGE B
GROUP BY
  SPACE_LIMIT, 
  SPACE_USED , 
  SPACE_RECLAIMABLE ;
