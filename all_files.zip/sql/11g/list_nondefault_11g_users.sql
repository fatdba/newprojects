-- $Name$
-- $Log$: Modified - 15 Sept 2015

-- $Author$: Shawn Craven
PROMPT RUN in 11g or older to review all accounts

set lines 220 pages 100
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a26
col AUTHENTICATION_TYPE for a19
select username, account_status, created, profile, password_versions, AUTHENTICATION_TYPE from dba_users
where username not in ('ANONYMOUS','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','LBACSYS','MDDATA','MDSYS','MGMT_VIEW','OLAP_SYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','OWBSYS_AUDIT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','WMSYS','XDB','XS$NULL')
order by 1 ;
