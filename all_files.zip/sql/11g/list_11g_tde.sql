-- $Name$
-- $Log$: Created  - 04 Nov 2018
-- $Log$: Modified - 05 Jun 2020
--
-- $Author$: Shawn Craven

prompt
prompt *** Database ENCRYPTION DETAILS ***
SET LINESIZE 220
col WRL_PARAMETER for a48
SELECT * FROM gv$encryption_wallet order by 1;
prompt
prompt *** Instance ENCRYPTION DETAILS ***
SELECT * FROM v$encryption_wallet order by 1 ;
