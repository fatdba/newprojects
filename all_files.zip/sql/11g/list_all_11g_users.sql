-- $Name$
-- $Log$: Modified - 15 Sept 2015

-- $Author$: Shawn Craven
PROMPT RUN in 11g or older to review all accounts

set lines 220 pages 100
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a26
col AUTHENTICATION_TYPE for a19
select username, account_status, created, profile, password_versions, AUTHENTICATION_TYPE from dba_users 
order by 1 ;
