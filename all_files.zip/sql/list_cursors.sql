col DIV for a55
WITH C AS
(
    SELECT '---- ' || MACHINE AS DIV
    , COUNT(*) AS CNT
    FROM V$OPEN_CURSOR C
    JOIN V$SESSION S
      ON C.SID = S.SID
    GROUP BY MACHINE
)
SELECT * FROM C
UNION ALL
SELECT '* OPEN CURSORS'
    , SUM(CNT) 
    FROM C
    UNION ALL
    SELECT 'ALLOWED CURSORS'
    , TO_NUMBER(VALUE)
    FROM V$PARAMETER
    WHERE NAME = 'open_cursors'
    UNION ALL
    SELECT '* OPEN SESSIONS', COUNT(*)
      FROM v$session
     union all
    SELECT 'ALLOWED SESSIONS', to_number(value)
      FROM v$parameter
     WHERE name = 'sessions'
     union all
    SELECT '* CURRENT PROCESSES' ,  current_utilization
    from v$resource_limit
     WHERE resource_name = 'processes'
     union all
    SELECT 'ALLOWED PROCESSES', to_number(value)
      FROM v$parameter
     WHERE name = 'processes' ;