-- $Name$ list_active_sessions.sql
-- $Log$: Modified - 14 Sept 2016
-- $Author$: Shawn Craven

set lines 300 pages 100
COLUMN SID FORMAT 99999 HEAD 'SID'
COLUMN SERIAL# FORMAT 99999
COLUMN SPID FORMAT a8 HEAD 'SPID'
COLUMN OSUSER FORMAT a8 truncated
COLUMN USERNAME FORMAT a15 truncated
COLUMN PROGRAM FORMAT a18 truncated
COLUMN MACHINE FORMAT a18 truncated
COLUMN "Program/Machine" FORMAT a18 truncated
COLUMN "LOGIN TIME" FORMAT a11
COLUMN STATUS FORMAT a1 truncated
COLUMN ACTIVE FORMAT a10
COLUMN CLIENT_INFO for a12
COLUMN program for a35
COLUMN service_name for a15
SELECT s.inst_id, s.sid, s.serial#, p.spid, s.osuser, s.username, s.client_info, s.program,
cast(substr(s.service_name,1,19) as VARCHAR2(22))||'...' "SERVICE...",
       to_char(s.logon_time, 'MM.DD HH24:MI') "LOGIN TIME", s.machine, s.status,
       floor(s.last_call_et/3600)||':'||
       floor(mod(s.last_call_et,3600)/60)||':'||
       mod(mod(s.last_call_et,3600),60) "ACTIVE"
  FROM gv$session s, gv$process p
 WHERE s.paddr = p.addr (+)
   AND s.status = 'ACTIVE'
   AND s.type <> 'BACKGROUND'
   AND s.username not in ('SYS')
ORDER BY last_call_et;
