-- $Name$ list_hidden_parameter.sql
--
-- $Log$: Modified - 16 Jun 2016 - SC - Creation
--
-- $Author$: Shawn Craven

col PARAMETER for a55
col VALUE for a18

select ksppinm as PARAMETER, ksppstvl as VALUE from x$ksppi a, x$ksppsv b
where a.indx=b.indx and ksppinm = lower('&&HIDDEN_PARAM') ;

undefine HIDDEN_PARAM
