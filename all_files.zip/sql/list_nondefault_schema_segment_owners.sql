-- $Name$: list_nondefault_schema_segment_owners.sql
--
-- $Log$:  Modified - 04 Sept 2015 - creation
--
-- $Author$: Shawn Craven

prompt
prompt *** Non Default Schemas with Segments ***
prompt
col OWNER for a25
select distinct owner from dba_segments where OWNER not in 
('AUDSYS','DBSNMP','GSMADMIN_INTERNAL','MDSYS','OUTLN','CTXSYS','OJVMSYS','ORDSYS','ORDDATA','SYS','SYSTEM','WMSYS','XDB')
ORDER BY 1 ;

