-- $Name$ list_all_noncdb_users.sql
--
-- $Log$: Modified - 04 Sept 2017 - SC - Creation
--                 - 22 Sept 2022 - SC - Modified and added additional columns
--
-- $Author$: Shawn Craven
--

set lines 220 pages 100
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a22
col COMMON for a6
col LAST_LOGIN for a38
col CON_ID for 999999
select username, account_status, created, profile, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, to_char(expiry_date, 'DD-MON-RRRR hh24:mi:ss') as password_expiry_date, password_versions from cdb_users 
where CON_ID = 0
order by 1 ;