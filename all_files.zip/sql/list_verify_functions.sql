-- Name: list_verify_functions.sql
--
--  - Modified - 16 Jun 2019 - SC - Creation
--  - Modified - 29 Apr 2024 - SC - Expanded notes regarding password lifetime and profile purposes
--
-- Author: Shawn Craven
--
-- Note: This script lists functions related to password verification.
--       It is essential to regularly verify passwords to ensure the security of
--       the database system. Password lifetime and complexity requirements are
--       enforced through profiles, which dictate the rules for creating and
--       managing user passwords.
--       A profile defines settings such as password complexity requirements,
--       password expiration policies, and account lockout thresholds.
--       The 'PASSWORD_VERIFY_FUNCTION' resource name is commonly used in
--       profiles to specify a function that validates password complexity.
--       By querying the DBA_PROFILES table, this script provides insight into
--       the password verification settings enforced at the database level.
--

SET LINESIZE 220
COLUMN OWNER FORMAT A16
COLUMN CREATED FORMAT A22
COLUMN RESOURCE_NAME FORMAT A32

SELECT OWNER,
       OBJECT_NAME,
       OBJECT_TYPE,
       CREATED,
       LAST_DDL_TIME,
       STATUS
  FROM DBA_OBJECTS
 WHERE OWNER = 'SYS'
   AND OBJECT_TYPE = 'FUNCTION'
   AND (OBJECT_NAME LIKE '%VERIFY%'
        OR OBJECT_NAME LIKE '%VRF%'
        OR OBJECT_NAME LIKE '%PSWD_COMPLEX%')
 ORDER BY 1, 2;

PROMPT
PROMPT If LIMIT = FROM ROOT - Common Profile (CDB)
COLUMN LIMIT FORMAT A35
COLUMN PROFILE FORMAT A35

SELECT COMMON,
       PROFILE,
       RESOURCE_NAME,
       LIMIT
  FROM DBA_PROFILES
 WHERE RESOURCE_NAME = 'PASSWORD_VERIFY_FUNCTION';