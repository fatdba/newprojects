set lines 220

select o.CON_ID,o.OWNER,o.OBJECT_NAME,o.OBJECT_TYPE,o.CREATED,o.LAST_DDL_TIME,o.STATUS 
from v$containers c 
left join cdb_objects o on o.con_id = c.con_id
where o.OWNER='SYS' 
and o.OBJECT_TYPE='FUNCTION' 
and o.OBJECT_NAME ='&&Function_name' 
order by 1,2 ;

PROMPT
PROMPT if LIMIT = FROM ROOT - Common Profile (CDB)
col LIMIT for a35
col PROFILE for a35
select COMMON, profile,resource_name,limit from dba_profiles where resource_name = 'PASSWORD_VERIFY_FUNCTION';
