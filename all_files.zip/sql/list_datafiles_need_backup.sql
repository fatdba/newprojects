-- $Name$ list_datafiles_need_backup.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** Check for datafiles not backed up last 8 days ***
prompt
set pages 9000
SELECT d.file#
  FROM v$datafile d,
       v$database b
 WHERE d.file# NOT IN (SELECT m.file#
                         FROM v$backup_datafile m
                        WHERE m.completion_time > SYSDATE-8
                          AND m.creation_change# = d.creation_change#
                       GROUP by m.file#)
   AND d.file# NOT IN (SELECT h.file#
                         FROM v$backup h
                        WHERE h.time > SYSDATE-8)
   AND d.creation_time < SYSDATE-1 
   ORDER by 1;
