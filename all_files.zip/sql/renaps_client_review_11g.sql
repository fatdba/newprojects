-- Script Name: renaps_client_review_11g.sql
--
-- Author: Shawn Craven
--
-- Description: This script collects detailed information about the client's Oracle 11g database.
--              It includes SPFILE details, memory configuration, audit settings, resource limits,
--              recovery configurations, invalid objects, and other critical database insights.
--
-- Note: Ensure this script is run with SYSDBA privileges on the database. Adjust specific queries
--       based on the database version and the client�s requirements.
--
-- Modified: 04 Sep 2018 - SC - Initial creation
--           18 Jan 2019 - SC - Minor updates
--           03 Feb 2019 - SC - Updated column formatting
--           14 Mar 2019 - SC - Cleaned up DG broker details
--           28 May 2019 - SC - Improved memory details section
--           23 Jul 2019 - SC - Added Direct and Async I/O checks
--           27 Sep 2021 - SC - Expanded NLS parameters and DB size details
--           25 Jan 2022 - SC - Added PLATFORM and CREATED details
--

-- Session Configuration
SET PAGESIZE 9999
SET LINESIZE 200
SET TRIMSPOOL ON
SET ECHO OFF
SET HEADING ON
SET FEEDBACK OFF

-- Define variables for dynamic file naming
COL db_name NEW_VALUE _dbname
COL logname NEW_VALUE logname

-- Fetch Database Name
SELECT LOWER(SYS_CONTEXT('USERENV', 'DB_NAME')) AS db_name FROM DUAL;

-- Generate a unique log file name
SELECT 'renaps_client_review_' || NAME || '_' || TO_CHAR(SYSDATE, 'YYYY-MM-DD_HH24MISS') AS logname
FROM V$DATABASE;

-- Start Spooling
SPOOL '&logname..txt'

PROMPT
PROMPT Copyright (C) 2023 Renaps
PROMPT
PROMPT Renaps client information collection routine
PROMPT
PROMPT Script Support enquiries to scraven@renaps.com
PROMPT
PROMPT ******************************
PROMPT ******** Begin Report ********
PROMPT ******************************

-- ====================================================================================
-- Section 1: General Database Information
-- ====================================================================================
PROMPT
PROMPT *** General Database Information ***
PROMPT

COL EXECUTION_DETAILS FOR A55
SELECT 'HOSTNAME      : ' || HOST_NAME || CHR(10) ||
       'DATABASE NAME : ' || NAME || CHR(10) ||
       'DATE          : ' || SYSTIMESTAMP AS EXECUTION_DETAILS
FROM V$DATABASE, V$INSTANCE;

-- ====================================================================================
-- Section 2: SPFILE Details
-- ====================================================================================
PROMPT
PROMPT *** SPFILE DETAILS ***
PROMPT

COL NAME FOR A32
COL DESCRIPTION FOR A35
COL VALUE FOR A75
SELECT NAM.KSPPINM AS NAME, NAM.KSPPDESC AS DESCRIPTION, VAL.KSPPSTVL AS VALUE
FROM X$KSPPI NAM, X$KSPPSV VAL
WHERE NAM.INDX = VAL.INDX
  AND NAM.KSPPINM LIKE 'spfile%'
  AND VAL.KSPPSTVL IS NOT NULL
ORDER BY 1;

-- ====================================================================================
-- Section 3: Memory Configuration
-- ====================================================================================
PROMPT
PROMPT *** MEMORY CONFIGURATION DETAILS ***
PROMPT

COL NAME FOR A32
COL DESCRIPTION FOR A66
COL VALUE FOR A25
COL INST_ID FOR 99999
SELECT DISTINCT NAM.INST_ID AS INSTANCE,
       NAM.KSPPINM AS NAME,
       NAM.KSPPDESC AS DESCRIPTION,
       VAL.KSPPSTVL AS VALUE
FROM X$KSPPI NAM, X$KSPPSV VAL
WHERE NAM.INDX = VAL.INDX
  AND NAM.KSPPINM IN ('streams_pool_size',
                      'memory_target',
                      'memory_max_target',
                      'sga_target',
                      'sga_max_size',
                      'db_cache_size',
                      'shared_pool_size',
                      'large_pool_size',
                      'java_pool_size',
                      'pga_aggregate_limit',
                      'pga_aggregate_target')
ORDER BY 1;

-- ====================================================================================
-- Section 4: Data Guard Configuration
-- ====================================================================================
PROMPT
PROMPT *** DATA GUARD CONFIGURATION DETAILS ***
PROMPT

COL dataguard_broker FOR A16
COL remote_archive FOR A14
COL supplemental_log_data_min FOR A25
COL supplemental_log_data_pk FOR A24
COL supplemental_log_data_ui FOR A24
COL SWITCHOVER_STATUS FOR A32
SELECT REMOTE_ARCHIVE,
       SUPPLEMENTAL_LOG_DATA_MIN,
       SUPPLEMENTAL_LOG_DATA_PK,
       SUPPLEMENTAL_LOG_DATA_UI,
       SWITCHOVER_STATUS,
       DATAGUARD_BROKER
FROM V$DATABASE;

-- ====================================================================================
-- Section 5: Invalid Objects
-- ====================================================================================
PROMPT
PROMPT *** INVALID OBJECTS DETAILS ***
PROMPT

PROMPT Count of Invalid Objects
SELECT COUNT(*) AS INVALID_OBJECTS_COUNT
FROM DBA_OBJECTS
WHERE STATUS = 'INVALID';

PROMPT Invalid Objects Grouped by Owner and Object Type
SELECT OWNER, OBJECT_TYPE, COUNT(*) AS OBJECT_COUNT
FROM DBA_OBJECTS
WHERE STATUS = 'INVALID'
GROUP BY OWNER, OBJECT_TYPE;

PROMPT Detailed List of Invalid Objects
COL OWNER FOR A30
COL OBJECT_NAME FOR A30
COL OBJECT_TYPE FOR A30
SELECT OWNER, OBJECT_NAME, OBJECT_TYPE
FROM DBA_OBJECTS
WHERE STATUS = 'INVALID';

-- ====================================================================================
-- Section 6: Tablespace and File Details
-- ====================================================================================
PROMPT
PROMPT *** TABLESPACE AND FILE DETAILS ***
PROMPT

COL FILE_NAME FOR A108
COL SIZE_MB FOR 999,999,999.99
COL FREE_MB FOR 999,999,999.99
COL MAXSIZE_MB FOR 999,999,999.99

PROMPT Data File Details
SELECT FILE_ID,
       FILE_NAME,
       BYTES / 1024 / 1024 AS SIZE_MB,
       MAXBYTES / 1024 / 1024 AS MAXSIZE_MB,
       AUTOEXTENSIBLE,
       (INCREMENT_BY * BLOCK_SIZE) / 1024 / 1024 AS EXT_MB
FROM DBA_DATA_FILES
ORDER BY 1;

PROMPT Tablespace Usage Summary
COL TABLESPACE_NAME FOR A30
SELECT TABLESPACE_NAME,
       ROUND(SUM(BYTES) / 1024 / 1024, 2) AS SIZE_MB,
       ROUND(SUM(FREE_SPACE.BYTES) / 1024 / 1024, 2) AS FREE_MB,
       ROUND((SUM(BYTES) - SUM(FREE_SPACE.BYTES)) / SUM(BYTES) * 100, 2) AS USED_PERCENT
FROM DBA_DATA_FILES DF
LEFT JOIN DBA_FREE_SPACE FREE_SPACE
  ON DF.TABLESPACE_NAME = FREE_SPACE.TABLESPACE_NAME
GROUP BY DF.TABLESPACE_NAME
ORDER BY TABLESPACE_NAME;

-- ====================================================================================
-- Section 7: Registry and Patch History
-- ====================================================================================
PROMPT
PROMPT *** REGISTRY AND PATCH HISTORY ***
PROMPT

COL COMP_ID FOR A18
COL COMP_NAME FOR A55
SELECT COMP_ID, COMP_NAME, VERSION, STATUS
FROM DBA_REGISTRY
ORDER BY 1;

PROMPT Patch Application History
COL ACTION FOR A15
COL VERSION FOR A22
SELECT * FROM SYS.REGISTRY$HISTORY;

-- ====================================================================================
-- Finalization
-- ====================================================================================
PROMPT ******************************
PROMPT ******** End of Report *******
PROMPT ******************************

SPOOL OFF