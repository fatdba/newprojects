select sum(bytes)/1024/1024/1024 DB_Size_in_GB from v$datafile;
select sum(bytes)/1024/1024/1024 DB_Free_Space_in_GB from dba_free_space;

