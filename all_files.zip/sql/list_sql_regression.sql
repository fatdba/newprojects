-- $Name$
-- $Log$: Modified - 04 Sept 2018
--
-- $Author$: Shawn Craven

col BEGIN_INTERVAL_TIME for a30
col node for 999
col snap_id for 999999999
select ss.snap_id, ss.instance_number node, begin_interval_time, sql_id, plan_hash_value,
     nvl(executions_delta,0) execs,
    (elapsed_time_delta/decode(nvl(executions_delta,0),0,1,executions_delta))/1000000 avg_etime,
    (buffer_gets_delta/decode(nvl(buffer_gets_delta,0),0,1,executions_delta)) avg_lio,
    (S.ROWS_PROCESSED_DELTA/decode(nvl(S.ROWS_PROCESSED_DELTA,0),0,1,executions_delta)) rows_processed
    from DBA_HIST_SQLSTAT S, DBA_HIST_SNAPSHOT SS
 where sql_id = '&sql_id'
 and ss.snap_id = S.snap_id
   and ss.instance_number = S.instance_number
   and executions_delta > 0
   and begin_interval_time >= sysdate-31
 order by 1, 2, 3 ;
