-- $Name$ list_key_public_grants.sql
-- $Log$: Modified - 04 Sep 2015 - SC - Creation
--                 - 04 Mar 2021 - SC - Added grantee to output for completeness
--
-- $Author$: Shawn Craven

col GRANTEE for a8
col TABLE_NAME for a25
select grantee, table_name from dba_tab_privs
where grantee='PUBLIC'
and privilege ='EXECUTE'
and table_name in
('UTL_FILE', 'UTL_SMTP', 'UTL_TCP', 'UTL_HTTP',
'DBMS_RANDOM', 'DBMS_LOB', 'DBMS_SQL',
'DBMS_SYS_SQL', 'DBMS_JOB',
'DBMS_BACKUP_RESTORE',
'DBMS_OBFUSCATION_TOOLKIT') order by 2 ;
