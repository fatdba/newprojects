-- Space Monitoring How To - v1.1 - 01-Dec-2022 - Fixing procedures - Shawn Craven

--http://oracle-help.com/scripts/performance-tuninghow-find-database-growth-monthly-wise/

/*
ALTER USER renaps QUOTA 250M ON users ;
GRANT CREATE SESSION TO renaps;
GRANT CREATE TABLE, CREATE SEQUENCE TO renaps ;
GRANT SELECT ON sys.dba_data_files TO renaps;
GRANT SELECT ON sys.dba_free_space TO renaps;
GRANT SELECT ON sys.dba_segments TO renaps;
GRANT CREATE JOB TO renaps;
GRANT EXECUTE ON SYS.DEFAULT_IN_MEMORY_JOB_CLASS TO renaps;
*/

alter session set nls_date_format='dd-mm-yyyy hh24:mi';

--cleanup (if necessary)
--drop table TABLESPACE_SIZE_HISTORY purge;
--drop table OBJECT_SIZE_HISTORY purge;
--drop table SIZE_HIST_RUN_LOG purge;
--drop table TABLESPACE_MONTHLY_AGGREGATE purge;
--drop table OBJECT_MONTHLY_AGGREGATE purge;

-- Monitoring Identity Columns Tables:
CREATE TABLE renaps.tablespace_size_history
        (
                id NUMBER GENERATED ALWAYS
AS IDENTITY                          ,
        tablespace_name VARCHAR2(30) ,
        total_space_mb  NUMBER       ,
        used_space_mb   NUMBER       ,
        free_space_mb   NUMBER       ,
        pct_free        NUMBER       ,
        insert_date     DATE         ,
        PRIMARY KEY(id)
        )
tablespace USERS;

CREATE INDEX renaps.ts_size_hist_ins_date_idx
ON renaps.tablespace_size_history
        (
                trunc(insert_date)
        )
tablespace USERS;

CREATE INDEX renaps.ts_size_hist_ts_name_idx
ON renaps.tablespace_size_history
        (
                tablespace_name
        )
tablespace USERS;

CREATE TABLE renaps.object_size_history
        (
                id NUMBER GENERATED ALWAYS
AS IDENTITY                   ,
        seg_name        VARCHAR2(30) ,
        seg_owner       VARCHAR2(30) ,
        seg_type        VARCHAR2(30) ,
        mb              NUMBER       ,
        num_blks        NUMBER       ,
        tablespace_name VARCHAR2(30) , -- FK to tablespace_size_history
        insert_date     DATE         ,
        PRIMARY KEY(id)
        )
tablespace USERS;

CREATE INDEX renaps.obj_size_hist_ins_date_idx
ON renaps.object_size_history
        (
                trunc(insert_date)
        )
tablespace USERS;

---
CREATE TABLE renaps.size_hist_run_log
        (
                id NUMBER GENERATED ALWAYS
AS IDENTITY                      ,
        script_name VARCHAR2(50) ,
        run_time    DATE         ,
        status      VARCHAR2(50) ,
        PRIMARY KEY(id)
        )
tablespace USERS;

CREATE TABLE renaps.tablespace_monthly_aggregate
        (
                id NUMBER GENERATED ALWAYS
AS IDENTITY                          ,
        tablespace_name   VARCHAR2(55) ,
        month_tracked     VARCHAR2(55) ,
        start_date        DATE         ,
        end_date          DATE         ,
        beginning_size_mb NUMBER       ,
        ending_size_mb    NUMBER       ,
        change_mb         NUMBER       ,
        pct_change        NUMBER       ,
        PRIMARY KEY(id)
        )
tablespace USERS;

CREATE INDEX renaps.ts_mnth_aggr_ts_name_idx
ON renaps.tablespace_monthly_aggregate
        (
                tablespace_name
        )
tablespace USERS;

CREATE TABLE renaps.object_monthly_aggregate
        (
                id                 NUMBER GENERATED ALWAYS
AS IDENTITY				,
                month_tracked      VARCHAR2(55) ,
                SEG_NAME           VARCHAR2(30) ,
                SEG_OWNER          VARCHAR2(30) ,
                SEG_TYPE           VARCHAR2(30) ,
                tablespace_name    VARCHAR2(55) ,
                beginning_seg_mb   NUMBER       ,
                ending_seg_mb      NUMBER       ,
                change_mb          NUMBER       ,
                pct_change_mb      NUMBER       ,
                beginning_num_blks NUMBER       ,
                ending_num_blks    NUMBER       ,
                change_blks        NUMBER       ,
                pct_change_blks    NUMBER       ,
                start_date         DATE         ,
                end_date           DATE
        )
tablespace USERS;

CREATE INDEX renaps.obj_mnth_aggr_ts_name_idx
ON renaps.object_monthly_aggregate
        (
                tablespace_name
        )
tablespace USERS;

CREATE INDEX renaps.obj_mnth_aggr_seg_name_idx
ON renaps.object_monthly_aggregate
        (
                seg_name
        )
tablespace USERS;


CREATE OR REPLACE PROCEDURE renaps.object_size_hist_insert_p ( return_code OUT NUMBER )
IS
        BEGIN
                return_code := 0;
                INSERT INTO
                        renaps.object_size_history
                        (
                                seg_name        ,
                                seg_owner       ,
                                seg_type        ,
                                mb              ,
                                num_blks        ,
                                tablespace_name ,
                                insert_date
                        )
                SELECT
                        segment_name           ,
                        owner                  ,
                        segment_type           ,
                        ROUND(bytes/1024/1024) ,
                        blocks                 ,
                        tablespace_name        ,
                        sysdate
                FROM
                        sys.dba_segments
                WHERE
                        segment_type in ('TABLE'     ,
                                        'INDEX'      ,
                                        'LOBSEGMENT' ,
                                        'LOBINDEX');
                
                COMMIT;
                INSERT INTO
                        renaps.object_size_history
                        (
                                seg_name        ,
                                seg_owner       ,
                                seg_type        ,
                                mb              ,
                                num_blks        ,
                                tablespace_name ,
                                insert_date
                        )
                SELECT
                        segment_name    ,
                        owner           ,
                        segment_type    ,
                        tot_mb          ,
                        tot_blks        ,
                        tablespace_name ,
                        sysdate
                FROM
                        (
                                SELECT
                                        segment_name                            ,
                                        owner                                   ,
                                        segment_type                            ,
                                        sum(ROUND(bytes/1024/1024)) as tot_mb   ,
                                        sum(blocks)                 as tot_blks ,
                                        tablespace_name
                                FROM
                                        dba_segments
                                WHERE
                                        segment_type in ('INDEX PARTITION' ,
                                                        'LOB PARTITION'    ,
                                                        'TABLE PARTITION'  ,
                                                        'TABLE SUBPARTITION')
                                GROUP BY
                                        segment_name ,
                                        owner        ,
                                        segment_type ,
                                        tablespace_name ) part_segs;
                
                COMMIT;
        EXCEPTION
                WHEN OTHERS THEN RETURN_CODE := 1;
        END object_size_hist_insert_p;
/
        BEGIN
                renaps.object_size_hist_insert_p;
        END;
/

CREATE OR REPLACE PROCEDURE renaps.tablespace_month_aggr_insert_p ( return_code OUT NUMBER )
IS
li_month NUMBER;
li_yr    NUMBER;
        BEGIN
                return_code := 0;
                SELECT
                        extract(month FROM sysdate)-1
                into
                        li_month
                FROM
                        dual;
                
                IF
                        li_month in (2,3,4,5,6,7,8,9,10,11,12)
                THEN
                        SELECT
                                extract(year FROM sysdate)
                        into
                                li_yr
                        FROM
                                dual;
                
                ELSIF
                        li_month = 0
                THEN
                        SELECT
                                extract(year FROM sysdate)-1
                        into
                                li_yr
                        FROM
                                dual;
                
                END IF;
                IF
                        li_month = 0
                THEN
                        li_month := 12;
                END IF;
                INSERT INTO
                        renaps.tablespace_monthly_aggregate
                        (
                                id                ,
                                tablespace_name   ,
                                month_tracked     ,
                                start_date        ,
                                end_date          ,
                                beginning_size_mb ,
                                ending_size_mb    ,
                                change_mb         ,
                                pct_change
                        )
                SELECT
                        renaps.size_hist_seq.NEXTVAL ,
                        tablespace_name              ,
                        decode(li_month ,
                                        1 , 'JAN' ,
                                                2 , 'FEB' ,
                                                        3 , 'MAR' ,
                                                                4 , 'APR' ,
                                                                        5 , 'MAY' ,
                                                                                6 , 'JUN' ,
                                                                                        7 , 'JUL' ,
                                                                                                8 , 'AUG' ,
                                                                                                        9 , 'SEP' ,
                                                                                                                10 , 'OCT' ,
                                                                                                                        11 , 'NOV' ,
                                                                                                                                12, 'DEC') ||' ' ||li_yr as month_tracked ,
                        start_date    ,
                        end_date      ,
                        start_used_mb ,
                        end_used_mb   ,
                        change_mb     ,
                        pct_chng
                FROM
                        (
                                SELECT
                                        start_used.tablespace_name as tablespace_name                ,
                                        start_used.start_date                                        ,
                                        end_used.end_date                                            ,
                                        start_used.start_used_mb                                     ,
                                        end_used.end_used_mb                                         ,
                                        (end_used.end_used_mb-start_used.start_used_mb)                                      as change_mb ,
                                        100                  -(ROUND((start_used.start_used_mb/end_used.end_used_mb),2)*100) as pct_chng
                                FROM
                                        (
                                                SELECT
                                                        id                             ,
                                                        tablespace_name                ,
                                                        used_space_mb as start_used_mb ,
                                                        insert_date   as start_date
                                                FROM
                                                        renaps.tablespace_size_history
                                                WHERE
                                                        insert_date IN
                                                        (
                                                                SELECT
                                                                        min(insert_date)
                                                                FROM
                                                                        renaps.tablespace_size_history
                                                                WHERE
                                                                        insert_date between to_date('' ||li_month ||'/01/' ||li_yr ||' 00:00:00' ||'', 'MM/DD/YYYY HH24:MI:SS')
                                                                AND     LAST_DAY(to_date('' ||li_month ||'/01/' ||li_yr ||' 23:59:59' ||'', 'MM/DD/YYYY HH24:MI:SS')) ) ) start_used ,
                                        (
                                                SELECT
                                                        id                           ,
                                                        tablespace_name              ,
                                                        used_space_mb as end_used_mb ,
                                                        insert_date   as end_date
                                                FROM
                                                        renaps.tablespace_size_history
                                                WHERE
                                                        insert_date IN
                                                        (
                                                                SELECT
                                                                        max(insert_date)
                                                                FROM
                                                                        renaps.tablespace_size_history
                                                                WHERE
                                                                        insert_date between to_date('' ||li_month ||'/01/' ||li_yr ||' 00:00:00' ||'', 'MM/DD/YYYY HH24:MI:SS')
                                                                AND     LAST_DAY(to_date('' ||li_month ||'/01/' ||li_yr ||' 23:59:59' ||'', 'MM/DD/YYYY HH24:MI:SS')) ) ) end_used
                                WHERE
                                        start_used.tablespace_name = end_used.tablespace_name ) tots;
                
                COMMIT;
        EXCEPTION
                WHEN OTHERS THEN RETURN_CODE := 1;
        END tablespace_month_aggr_insert_p;
/

CREATE OR REPLACE PROCEDURE renaps.object_month_aggr_insert_p ( return_code OUT NUMBER )
IS
li_month NUMBER;
li_yr    NUMBER;
        BEGIN
                return_code := 0;
                SELECT
                        extract(month FROM sysdate)-1
                into
                        li_month
                FROM
                        dual;
                
                IF
                        li_month in (2,3,4,5,6,7,8,9,10,11,12)
                THEN
                        SELECT
                                extract(year FROM sysdate)
                        into
                                li_yr
                        FROM
                                dual;
                
                ELSIF
                        li_month = 0
                THEN
                        SELECT
                                extract(year FROM sysdate)-1
                        into
                                li_yr
                        FROM
                                dual;
                
                END IF;
                IF
                        li_month = 0
                THEN
                        li_month := 12;
                END IF;
                INSERT INTO
                        renaps.object_monthly_aggregate
                        (
                                id                 ,
                                month_tracked      ,
                                SEG_NAME           ,
                                SEG_OWNER          ,
                                SEG_TYPE           ,
                                tablespace_name    ,
                                beginning_seg_mb   ,
                                ending_seg_mb      ,
                                change_mb          ,
                                pct_change_mb      ,
                                beginning_num_blks ,
                                ending_num_blks    ,
                                change_blks        ,
                                pct_change_blks    ,
                                start_date         ,
                                end_date
                        )
                SELECT
                        renaps.size_hist_seq.NEXTVAL ,
                        decode(li_month ,
                                        1 , 'JAN' ,
                                                2 , 'FEB' ,
                                                        3 , 'MAR' ,
                                                                4 , 'APR' ,
                                                                        5 , 'MAY' ,
                                                                                6 , 'JUN' ,
                                                                                        7 , 'JUL' ,
                                                                                                8 , 'AUG' ,
                                                                                                        9 , 'SEP' ,
                                                                                                                10 , 'OCT' ,
                                                                                                                        11 , 'NOV' ,
                                                                                                                                12, 'DEC') ||' ' ||li_yr as month_tracked ,
                        seg_name        ,
                        seg_owner       ,
                        seg_type        ,
                        tablespace_name ,
                        start_mb        ,
                        end_mb          ,
                        change_mb       ,
                        pct_change_mb   ,
                        start_blks      ,
                        end_blks        ,
                        change_blks     ,
                        pct_change_blks ,
                        start_date      ,
                        end_date
                FROM
                        (
                                SELECT
                                        start_used.seg_name                                    ,
                                        start_used.seg_owner                                   ,
                                        start_used.seg_type                                    ,
                                        start_used.tablespace_name                             ,
                                        start_used.start_mb                                    ,
                                        end_used.end_mb                                        ,
                                        (end_used.end_mb-start_used.start_mb)                                  as change_mb     ,
                                        (100            -(ROUND((start_used.start_mb/end_used.end_mb),2)*100)) as pct_change_mb ,
                                        start_used.start_blks                                                                   ,
                                        end_used.end_blks                                                                       ,
                                        (end_used.end_blks-start_used.start_blks)                                    as change_blks                                ,
                                        (100              -(ROUND((start_used.start_blks/end_used.end_blks),2)*100)) as pct_change_blks                            ,
                                        start_used.start_date                                                                                                      ,
                                        end_used.end_date
                                FROM
                                        (
                                                SELECT
                                                        id              ,
                                                        seg_name        ,
                                                        seg_owner       ,
                                                        seg_type        ,
                                                        tablespace_name ,
                                                        decode(mb ,
                                                                        0 , 1 ,
                                                                                mb) as start_mb   ,
                                                        num_blks                    as start_blks ,
                                                        insert_date                 as start_date
                                                FROM
                                                        renaps.object_size_history
                                                WHERE
                                                        trunc(insert_date) IN
                                                        (
                                                                SELECT
                                                                        min(trunc(insert_date))
                                                                FROM
                                                                        renaps.object_size_history
                                                                WHERE
                                                                        insert_date between to_date('' ||li_month ||'/01/' ||li_yr ||' 00:00:00' ||'', 'MM/DD/YYYY HH24:MI:SS')
                                                                AND     LAST_DAY(to_date('' ||li_month ||'/01/' ||li_yr ||' 23:59:59' ||'', 'MM/DD/YYYY HH24:MI:SS')) ) ) start_used ,
                                        (
                                                SELECT
                                                        id              ,
                                                        seg_name        ,
                                                        seg_owner       ,
                                                        seg_type        ,
                                                        tablespace_name ,
                                                        decode(mb ,
                                                                        0 , 1 ,
                                                                                mb) as end_mb   ,
                                                        num_blks                    as end_blks ,
                                                        insert_date                 as end_date
                                                FROM
                                                        renaps.object_size_history
                                                WHERE
                                                        trunc(insert_date) IN
                                                        (
                                                                SELECT
                                                                        max(trunc(insert_date))
                                                                FROM
                                                                        renaps.object_size_history
                                                                WHERE
                                                                        insert_date between to_date('' ||li_month ||'/01/' ||li_yr ||' 00:00:00' ||'', 'MM/DD/YYYY HH24:MI:SS')
                                                                AND     LAST_DAY(to_date('' ||li_month ||'/01/' ||li_yr ||' 23:59:59' ||'', 'MM/DD/YYYY HH24:MI:SS')) ) ) end_used
                                WHERE
                                        start_used.tablespace_name = end_used.tablespace_name
                                AND     start_used.seg_name        = end_used.seg_name
                                AND     start_used.seg_type        = end_used.seg_type
                                AND     start_used.seg_owner       = end_used.seg_owner ) tots;
                
                COMMIT;
        EXCEPTION
                WHEN OTHERS THEN RETURN_CODE := 1;
        END object_month_aggr_insert_p;
/



--DBMS_SCHEDULER Jobs
exec dbms_scheduler.drop_job('"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"');
        BEGIN
                DBMS_SCHEDULER.RUN_JOB ( job_name => '"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"' ,
                USE_CURRENT_SESSION               => TRUE );
        END;
/
--exec dbms_scheduler.run_job('"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"');
exec dbms_scheduler.drop_job('"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"');
        BEGIN
                DBMS_SCHEDULER.RUN_JOB ( job_name => '"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"' ,
                USE_CURRENT_SESSION               => TRUE );
        END;
/

--exec dbms_scheduler.run_job('"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"');


        BEGIN
                DBMS_SCHEDULER.CREATE_JOB ( job_name => '"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"'                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                job_type                             => 'PLSQL_BLOCK'                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                job_action                           => '
INSERT INTO renaps.tablespace_size_history ( tablespace_name,total_space_mb,used_space_mb,free_space_mb,pct_free,insert_date )
SELECT ddf.tablespace_name,                             --TS name
ROUND(ddf.bytes/1024/1024),                             --total mb
ROUND((ddf.bytes - NVL(dfs.bytes,0))/1024/1024),        --used mb
ROUND(NVL(dfs.bytes,0)/1024/1024),                      --free mb
ROUND(((NVL(dfs.bytes,0)/1024)/(ddf.bytes/1024))* 100), --pct_used
sysdate
FROM (SELECT tablespace_name, SUM(bytes) bytes
FROM dba_data_files
GROUP BY tablespace_name) ddf,
(SELECT tablespace_name, SUM(bytes) bytes, MAX(bytes) lfe
FROM dba_free_space
GROUP BY tablespace_name) dfs
WHERE dfs.tablespace_name(+) = ddf.tablespace_name;

COMMIT ;
' ,
                number_of_arguments                  => 0                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                start_date                           => TO_TIMESTAMP_TZ('2022-11-03 11:00:00.000000000 AMERICA/NEW_YORK','YYYY-MM-DD HH24:MI:SS.FF TZR')                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                repeat_interval                      => 'FREQ=DAILY;BYDAY=MON,TUE,THU,FRI,SAT,SUN'                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                end_date                             => NULL                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                enabled                              => FALSE                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                auto_drop                            => FALSE                                                                                                                                                                                                                                                                                                                                                                                                                 ,
                comments                             => 'Insert tablespace details - Daily' );
                DBMS_SCHEDULER.SET_ATTRIBUTE ( name  => '"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"' ,
                        attribute                    => 'store_output'                               ,
                        value                        => TRUE );
                DBMS_SCHEDULER.SET_ATTRIBUTE ( name  => '"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"' ,
                        attribute                    => 'logging_level'                              ,
                        value                        => DBMS_SCHEDULER.LOGGING_OFF );
                DBMS_SCHEDULER.enable ( name         => '"RENAPS"."TABLESPACE_SIZE_HIST_INSERT_JOB"' );
        END;
/

-- create RENAPS user DDL
CREATE USER "RENAPS" IDENTIFIED BY VALUES 'S:025F8CD3FBC7E53137E04A8971C55B4A5B1678C9B93833B117A1156621BD;T:9A12F7723B556435D06B83A338E7F2338E31A403ABE4571E64565C51468B460DC26720A3751821EB3DE0AF5BC9C790DD571373742E818B1A41110CD6A2D26FEE2BA2624C086AFF10E738BE443D38E34C'
      DEFAULT TABLESPACE "USERS"
      TEMPORARY TABLESPACE "TEMP";

  DECLARE
  TEMP_COUNT NUMBER;
  SQLSTR VARCHAR2(200);
BEGIN
  SQLSTR := 'ALTER USER "RENAPS" QUOTA 262144000 ON "USERS"';
  EXECUTE IMMEDIATE SQLSTR;
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -30041 THEN
      SQLSTR := 'SELECT COUNT(*) FROM USER_TABLESPACES
              WHERE TABLESPACE_NAME = ''USERS'' AND CONTENTS = ''TEMPORARY''';
      EXECUTE IMMEDIATE SQLSTR INTO TEMP_COUNT;
      IF TEMP_COUNT = 1 THEN RETURN;
      ELSE RAISE;
      END IF;
    ELSE
      RAISE;
    END IF;
END;
/

GRANT "RESOURCE" TO "RENAPS";
GRANT CREATE SESSION TO "RENAPS";
GRANT CREATE TABLE TO "RENAPS";
GRANT CREATE SEQUENCE TO "RENAPS";
GRANT CREATE JOB TO "RENAPS";
GRANT SELECT ON "SYS"."DBA_SEGMENTS" TO "RENAPS";
GRANT SELECT ON "SYS"."DBA_FREE_SPACE" TO "RENAPS";
GRANT SELECT ON "SYS"."DBA_DATA_FILES" TO "RENAPS";
GRANT EXECUTE ON "SYS"."DEFAULT_IN_MEMORY_JOB_CLASS" TO "RENAPS";
ALTER USER "RENAPS" DEFAULT ROLE ALL;
