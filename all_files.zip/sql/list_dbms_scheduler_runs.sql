-- $Name$ list_dbms_scheduler_runs.sql
--
-- $Log$: Created  - 04 Sept 2016
--        Modified - 
--
-- $Author$: Shawn Craven

prompt
prompt *** DBMS_SCHEDULER JOB RUN DETAILS - LAST 8 DAYS ***
set lines 220
col JOB_NAME for a32
col STATUS for a10
col ACTUAL_START_DATE for a45
col RUN_DURATION for a18
 
SELECT owner, job_name,status,error#, actual_start_date, run_duration FROM dba_scheduler_job_run_details  
WHERE  owner not in ('ORACLE_OCM','SYS')
AND    actual_start_date > sysdate -8  
ORDER BY actual_start_date ;
