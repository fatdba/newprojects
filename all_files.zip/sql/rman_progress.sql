alter session set NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS';

set lines 200 pages 200 
col dbsize_mbytes      for 99,999,990.00 justify right head "DBSIZE_MB"
col input_mbytes       for 99,999,990.00 justify right head "READ_MB"
col output_mbytes      for 99,999,990.00 justify right head "WRITTEN_MB"
col output_device_type for a10           justify left head "DEVICE"
col complete           for 990.00        justify right head "COMPLETE %" 
col compression        for 990.00        justify right head "COMPRESS|% ORIG"
col est_complete       for a20           head "ESTIMATED COMPLETION"
col recid              for 9999999       head "ID"

select recid
     , output_device_type
     , dbsize_mbytes
     , input_bytes/1024/1024 input_mbytes
     , output_bytes/1024/1024 output_mbytes
     , (output_bytes/input_bytes*100) compression
     , (mbytes_processed/dbsize_mbytes*100) complete
     , to_char(start_time + (sysdate-start_time)/(mbytes_processed/dbsize_mbytes),'DD-MON-YYYY HH24:MI:SS') est_complete
  from v$rman_status rs
     , (select sum(bytes)/1024/1024 dbsize_mbytes from v$datafile) 
 where status='RUNNING'
   and output_device_type is not null;
   
-- checking % completion

col client_info format a35
col event format a40

select
  sid,
  start_time,
  totalwork
  sofar, 
 (sofar/totalwork) * 100 pct_done
from 
   v$session_longops
where 
   totalwork > sofar
AND 
   opname NOT LIKE '%aggregate%'
AND 
   opname like 'RMAN%';

-- checking RMAN state
   
select 
   sid, 
   spid, 
   client_info, 
   event, 
   seconds_in_wait, 
   p1, p2, p3
 from 
   v$process p, 
   v$session s
 where 
   p.addr = s.paddr
 and 
   client_info like 'rman channel=%';
