-- $Name$ list_schema_objects.sql
--
-- $Log$  Modified - 04 Aug 2016  - SC - Creation.
--
-- $Author$: Shawn Craven


SET echo OFF
SET pages 32766
SET lines 140
SET heading ON
SET feedback OFF
SET newpage 1
SET trimspool ON

COLUMN host_name FORMAT a22
COLUMN RUN_DATE FORMAT a40
COLUMN owner FORMAT a30

@report_header.sql

/*
SELECT SYSTIMESTAMP "RUN_DATE", i.instance_name, d.NAME "DATABASE_NAME",
       i.host_name, i.status, i.logins
  FROM SYS.v_$instance i, SYS.v_$database d;

SET heading OFF
SELECT RPAD('GLOBAL_NAME',24)||' : '||g.global_name||CHR(10)||
       RPAD(n1.parameter,24)||' : '||n1.value||CHR(10)||
       RPAD(n2.parameter,24)||' : '||n2.value||CHR(10)||
       RPAD('LOG_MODE',24)||' : '||d.log_mode
  FROM nls_database_parameters n1,
       nls_database_parameters n2,
       v$database d,
       global_name g
 WHERE n1.parameter = 'NLS_CHARACTERSET'
   AND n2.parameter = 'NLS_NCHAR_CHARACTERSET'
 ORDER BY 1;
SET heading ON
*/

PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Object Counts;
PROMPT ===============================================================================;

SELECT owner, object_type, status, COUNT(*)
  FROM (SELECT owner, object_type, object_name, status
          FROM dba_objects
         WHERE (object_type,object_name) NOT IN (SELECT owner,table_name FROM dba_nested_tables)
           AND (owner,object_name) NOT IN (SELECT owner,index_name
                                             FROM dba_indexes
                                            WHERE index_type = 'LOB')
        UNION ALL
        SELECT owner, 'NESTED TABLE' as OBJECT_TYPE, table_name as OBJECT_NAME, '---' as STATUS
          FROM dba_nested_tables
        UNION ALL
        SELECT owner, 'LOB INDEX' as OBJECT_TYPE, index_name as OBJECT_NAME, status
          FROM dba_indexes
         WHERE index_type = 'LOB'
        UNION ALL
        SELECT idx_owner as OWNER, 'CONTEXT INDEX' as OBJECT_TYPE, idx_name as OBJECT_NAME, idx_status as STATUS
          FROM ctxsys.ctx_indexes
         WHERE idx_owner != 'CTXSYS'
       )
 WHERE owner NOT IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
   AND (owner,object_type,object_name) NOT IN (SELECT owner,object_type,original_name
                                                 FROM dba_recyclebin)
 GROUP BY owner, object_type, status
 ORDER BY owner, object_type, status;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Constraint Counts;
PROMPT ===============================================================================;

SELECT owner, constraint_type, status, COUNT(*)
  FROM dba_constraints
 WHERE owner NOT IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
) 
   AND table_name NOT IN (SELECT original_name
                            FROM dba_recyclebin
                           WHERE type = 'TABLE'
                             AND owner  IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
))
 GROUP BY owner, constraint_type, status
 ORDER BY owner, constraint_type, status;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Public Synonym Counts;
PROMPT ===============================================================================;

col TABLE_OWNER for a32
SELECT table_owner, COUNT(*)
  FROM dba_synonyms s
 WHERE owner = 'PUBLIC'
   AND table_owner NOT IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 GROUP BY table_owner
 ORDER BY 1;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Locked Statistics Counts;
PROMPT ===============================================================================;

SELECT owner, 'TAB' type, stattype_locked, COUNT(*)
  FROM dba_tab_statistics s
 WHERE stattype_locked IS NOT NULL
   AND owner NOT IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 GROUP BY owner, stattype_locked
UNION ALL
SELECT owner, 'IND' type, stattype_locked, COUNT(*)
  FROM dba_ind_statistics s
 WHERE stattype_locked IS NOT NULL
   AND owner NOT IN( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
) 
 GROUP BY owner, stattype_locked
 ORDER BY 1,2,3;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Tab Privileges by Owner;
PROMPT ===============================================================================;

COLUMN privilege FORMAT A32

SELECT owner, privilege, COUNT(*)
  FROM dba_tab_privs
 WHERE grantee != grantor
   AND owner not  IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
   AND table_name NOT LIKE 'BIN$%'
 GROUP BY owner, privilege
 ORDER BY 1,2;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Tab Privileges by Grantee;
PROMPT ===============================================================================;

col GRANTEE for a32

SELECT grantee, privilege, COUNT(*)
  FROM dba_tab_privs
 WHERE grantee != grantor
   AND grantee NOT IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
   AND table_name NOT LIKE 'BIN$%'
 GROUP BY grantee, privilege
 ORDER BY 1,2;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Sys Privileges by Grantee;
PROMPT ===============================================================================;

SELECT grantee, COUNT(*)
  FROM dba_sys_privs
 WHERE grantee not  IN  ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 GROUP BY grantee
 ORDER BY 1,2;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Role Grants by Grantee;
PROMPT ===============================================================================;

SELECT grantee, COUNT(*)
  FROM dba_role_privs
 WHERE grantee  NOT  IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 GROUP BY grantee
 ORDER BY 1,2;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Tablespace Quotas by Grantee;
PROMPT ===============================================================================;

COLUMN username FORMAT A30

SELECT username, tablespace_name, max_bytes
  FROM dba_ts_quotas
 WHERE username NOT  IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 ORDER BY 1,2;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT DBA_JOBS;
PROMPT ===============================================================================;

COLUMN log_user FORMAT A20
COLUMN priv_user FORMAT A20
COLUMN schema_user FORMAT A20

SELECT log_user, priv_user, schema_user, COUNT(*)
  FROM dba_jobs
 GROUP BY log_user, priv_user, schema_user
 ORDER BY 1,2,3;


PROMPT
PROMPT
PROMPT ===============================================================================;
PROMPT Refresh Groups and Children;
PROMPT ===============================================================================;

SELECT rowner, COUNT(*)
  FROM dba_refresh
 WHERE rowner NOT  IN ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 GROUP BY rowner
 ORDER BY 1;

SELECT owner, rowner, COUNT(*)
  FROM dba_refresh_children
 WHERE rowner NOT  IN  ( 
'ADINFO', 
'ANONYMOUS',
'APEX_PUBLIC_USER',
'APPQOSSYS',
'BI',
'CTXSYS',
'DBSNMP',
'DIP',
'EXFSYS',
'FLOWS_30000',
'FLOWS_FILES',
'GGATEDBA',
'GGATE',
'GGATECDC',
'GRIDUSER',
'HR',
'IX',
'LBACSYS',
'MDDATA',
'MDSYS',
'MGMT_VIEW',
'OE',
'OLAPSYS',
'ORACLE_OCM',
'ORDDATA',
'ORDPLUGINS',
'ORDSYS',
'OUTLN',
'OWBSYS',
'PERFSTAT',
'PM',
'PUBLIC',
'SH',
'SI_INFORMTN_SCHEMA',
'SPATIAL_CSW_ADMIN_USER',
'SPATIAL_WFS_ADMIN_USR',
'SQLTXADMIN',
'SQLTXPLAIN',
'SYS',
'SYSMAN',
'SYSTEM',
'TSMSYS',
'WKPROXY',
'WKSYS',
'WK_TEST',
'WMSYS',
'XDB',
'XS$NULL',
'APEX_PUBLIC_USER',
'SQLTXADMIN',
'SQLTXPLAIN',
'DROBETE',
'BMCCARTNEY',
'HSTEPHEN',
'BNILSEN',
'SCRAVEN',
'SRECSKY',
'ABHAMJEE',
'KREARDAN',
'APEX_040200',
'APEX_030200',
'GGATE',
'GGATECDC',
'GGATEDBA',
'ADINFO',
'APPQOSSYS' 
)
 GROUP BY owner, rowner
 ORDER BY 1;


PROMPT
PROMPT

