-- $Name$ plan.sql
-- $Log$: Modified - 04 Sept 2017

-- $Author$: Shawn Craven

col username for a10
col machine for a20
col event format a20
col module format a20
set long 1000000
set long 200000 pages 5000 lines 131 doc off
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
select name,sysdate from v$database;
set lines 200 pages 200
set linesize 1000
column txt format a121 word_wrapped
--spool /tmp/long_running.txt
select name from v$database;
select sql_fulltext from v$sql where sql_id like '&sql_id';
--select * from table(dbms_xplan.display_cursor('&&sql_id',null,'ADVANCED')); 
select * from table(dbms_xplan.display_cursor('&sql_id',null,'ALL'));

undefine sql_id
