alter session set NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS';
column owner format a10
col master for a20
col mview_name for a25
select owner, mview_name, refresh_mode, refresh_method, last_refresh_type, last_refresh_date, compile_state, STALE_SINCE from dba_mviews order by LAST_REFRESH_DATE;

