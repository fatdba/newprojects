-- Script Name: list_cdb_parameters.sql
--
-- Author: Shawn Craven
--
-- Note: This script is to be run after POST CDB customization steps are complete and is designed to capture evidence of certain important database parameters.
--
-- Modified: 22 Jun 2016 - SC - Creation.
--         : 22 May 2024 - SC - Modified to be alphabetic order as well as prompt the user as each parameter is being shown.
--         : 12 Jun 2024 - SC - Added new parameters for review: compatible, db_create_file_dest, db_create_online_log_dest_1, db_recovery_file_dest_size, diagnostic_dest, global_name.
--
--

prompt Displaying the audit parameter:
show parameter audit;

prompt Displaying the AWR snapshot time offset parameter:
show parameter AWR_SNAPSHOT_TIME_OFFSET;

prompt Displaying the audit trail parameter:
show parameter audit_trail;

prompt Displaying the AWR PDB autoflush enabled parameter:
show parameter awr_pdb_autoflush_enabled;

prompt Displaying the compatible parameter:
show parameter compatible;

prompt Displaying the control file record keep time parameter:
show parameter control_file_record_keep_time;

prompt Displaying the control files parameter:
show parameter control_files;

prompt Displaying the control management pack access parameter:
show parameter control_management_pack_access;

prompt Displaying the DB block checking parameter:
show parameter db_block_checking;

prompt Displaying the DB block checksum parameter:
show parameter db_block_checksum;

prompt Displaying the DB cache parameter:
show parameter db_cache;

prompt Displaying the DB create file destination parameter:
show parameter db_create_file_dest;

prompt Displaying the DB create online log destination parameter:
show parameter db_create_online_log_dest_1;

prompt Displaying the DB files parameter:
show parameter db_files;

prompt Displaying the DB flashback retention target parameter:
show parameter db_flashback_retention_target;

prompt Displaying the DB recovery file destination parameter:
show parameter db_recovery_file_dest;

prompt Displaying the DB recovery file destination size parameter:
show parameter db_recovery_file_dest_size;

prompt Displaying the DB writer processes parameter:
show parameter db_writer_processes;

prompt Displaying the diagnostic destination parameter:
show parameter diagnostic_dest;

prompt Displaying the dispatchers parameter:
show parameter dispatchers;

prompt Displaying the global name parameter:
show parameter global_name;

prompt Displaying the global names parameter:
show parameter global_names;

prompt Displaying the job queue parameter:
show parameter job_queue;

prompt Displaying the job queue processes parameter:
show parameter job_queue_processes;

prompt Displaying the keep time parameter:
show parameter Keep_time;

prompt Displaying the log archive destination 1 parameter:
show parameter log_archive_dest_1;

prompt Displaying the log archive format parameter:
show parameter log_archive_format;

prompt Displaying the max PDBs parameter:
show parameter max_pdbs;

prompt Displaying the max shared servers parameter:
show parameter max_shared_servers;

prompt Displaying the memory max target parameter:
show parameter memory_max_target;

prompt Displaying the memory target parameter:
show parameter memory_target;

prompt Displaying the open cursors parameter:
show parameter open_cursors;

prompt Displaying the open links parameter:
show parameter open_links;

prompt Displaying the open links per instance parameter:
show parameter open_links_per_instance;

prompt Displaying the parallel max servers parameter:
show parameter parallel_max_servers;

prompt Displaying the PGA parameter:
show parameter pga;

prompt Displaying the pool parameter:
show parameter pool;

prompt Displaying the processes parameter:
show parameter processes;

prompt Displaying the SGA parameter:
show parameter sga;

prompt Displaying the SGA max size parameter:
show parameter sga_max_size;

prompt Displaying the SGA target parameter:
show parameter sga_target;

prompt Displaying the session cached cursors parameter:
show parameter session_cached_cursors;

prompt Displaying the session max open files parameter:
show parameter session_max_open_files;

prompt Displaying the sessions parameter:
show parameter sessions;

prompt Displaying the shared servers parameter:
show parameter shared_servers;

prompt Displaying the undo tablespace parameter:
show parameter undo_tablespace;

prompt Displaying the use large pages parameter:
show parameter use_large_pages;
