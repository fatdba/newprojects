-- $Name$ list_profile_PASSWORD_VERIFY_FUNCTION.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** PROFILE PASSWORD_VERIFY_FUNCTION DETAILS ***
prompt

set lines 220
col PROFILE for a18
col LIMIT   for a30
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles
 where PROFILE not in ('MGMT_INTERNAL_USER_PROFILE')
   and RESOURCE_NAME like '%VERIFY_FUNCTION%'
 order by PROFILE ;
