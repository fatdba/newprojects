-- $Name$ list_profile_PASSWORD_LIFE_TIME.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** PROFILE PASSWORD LIFETIME DETAILS ***
prompt

set lines 220 pages 100
col PROFILE for a30
col LIMIT for a55
col RESOURCE_NAME for a55
col CON_ID for 99999
--select PROFILE,RESOURCE_NAME,RESOURCE_TYPE,LIMIT,COMMON from dba_profiles order by 1,3,2 ;
select CON_ID, PROFILE,RESOURCE_NAME,RESOURCE_TYPE,LIMIT,COMMON
  from cdb_profiles
 where RESOURCE_NAME = 'PASSWORD_LIFE_TIME'
--   and PROFILE = 'DEFAULT'
 order by 1,2,3 ;
