-- $Name$ cr_renaps_dba_users.sql
--
-- $Log$  Modified - 04 Sep 2016 - SC - Creation
--
-- $Author$: Shawn Craven

accept username prompt "Enter User:"
accept password prompt "Enter New Password:" hide

PROMPT
PROMPT *** Create RENAPS DBA &username ****
PROMPT

--drop user &username cascade ;

CREATE USER &username IDENTIFIED BY "&password"
      DEFAULT TABLESPACE "USERS"
      TEMPORARY TABLESPACE "TEMP"
      PROFILE "R$OLT_DBA"
      PASSWORD EXPIRE ;

GRANT "DBA" TO &username ;
GRANT UNLIMITED TABLESPACE TO &username ;
ALTER USER &username DEFAULT ROLE ALL;

audit insert table, update table, delete table by &username by access ;

undefine &username
undefine &password
