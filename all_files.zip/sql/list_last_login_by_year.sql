-- $Name$ list_last_login_by_year.sql
--
-- $Log$: Modified - 20 Jul 2022 - SC - Creation.
--                 - 03 Sep 2022 - SC - Modified LAST_LOGIN to a to_char and added the prompts.
--                 - 03 Sep 2024 - SC - Added 2023 range.
--
-- $Author$: Shawn Craven

set lines 220 pages 100

col USERNAME for a22
col ACCOUNT_STATUS for a18
col PROFILE for a18

prompt
prompt *** Last logins for 2016 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2016','dd-mon-yyyy') and to_date('31-DEC-2016','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2017 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2017','dd-mon-yyyy') and to_date('31-DEC-2017','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2018 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2018','dd-mon-yyyy') and to_date('31-DEC-2018','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2019 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2019','dd-mon-yyyy') and to_date('31-DEC-2019','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2020 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2020','dd-mon-yyyy') and to_date('31-DEC-2020','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2021 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2021','dd-mon-yyyy') and to_date('31-DEC-2021','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2022 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2022','dd-mon-yyyy') and to_date('31-DEC-2022','dd-mon-yyyy') order by 1 ;
prompt
prompt *** Last logins for 2023 ***
prompt
select username, account_status, created, profile, password_versions, common, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, con_id from cdb_users where CON_ID = 0 and last_login between to_date('01-JAN-2023','dd-mon-yyyy') and to_date('31-DEC-2023','dd-mon-yyyy') order by 1 ;

