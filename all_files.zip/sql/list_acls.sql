-- $Name$ list_acls.sql.sql
--
-- $Log$  Modified - 04 Sep 2016 - SC - Creation
--
-- $Author$: Shawn Craven

PROMPT
PROMPT *** Network and ACL Assignments ***
PROMPT

SET LINESIZE 220

COLUMN host FORMAT A32
COLUMN acl FORMAT A55
COLUMN acl_owner FORMAT A10

SELECT HOST,
       LOWER_PORT,
       UPPER_PORT,
       ACL,
       ACLID,
       ACL_OWNER
FROM   dba_host_acls
ORDER BY host;

PROMPT
PROMPT *** Privileges associated with the ACLs ***
PROMPT

COLUMN host FORMAT A32
COLUMN start_date FORMAT A11
COLUMN end_date FORMAT A11
COLUMN principal FORMAT A25
COLUMN privilege FORMAT A25

SELECT host,
       lower_port,
       upper_port,
       ace_order,
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date,
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date,
       grant_type,
       inverted_principal,
       principal,
       principal_type,
       privilege
FROM   dba_host_aces
ORDER BY host, ace_order;
