-- $Name$ list_last_passwd_chg.sql
--
-- $Log$: Modified - 02 Nov 2020 - SC - Creation
--
-- $Author$: Shawn Craven

col name form a30
col Last_Changed form a25
   SELECT name,ptime "Last_Changed"
   FROM sys.user$ a, dba_users b
   where a.name=b.username
-- and NAME like 'SYS%'
   order by 1;