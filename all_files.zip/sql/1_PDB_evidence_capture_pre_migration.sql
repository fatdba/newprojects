-- $Name$ 1_PDB_evidence_capture_pre_migration.sql
--
-- $Log$: Modified - 28 Aug 2016 - SC - Creation
--
-- $Author$: Shawn Craven
--
-- Note: To be run with SYSDBA privileges
--

-- Report Header Details

SET FEEDBACK OFF ;

col FILE_NAME NEW_VALUE SPOOL_FILE NOPRINT
col DATABASE_REPORT   for a80
col 'ORACLE_HOME: '   for a60
col 'Database Name: ' for a32
col 'Server Name: '   for a32
col 'Report Date: '   for a32

SELECT UPPER(instance_name) || '_' ||
TO_CHAR(SYSDATE,'DDMONYYYY_HH24MISS') || '.out' FILE_NAME
FROM v$instance ;

SPOOL /tmp/&SPOOL_FILE

SELECT
  LPAD('ORACLE_HOME: ', 20) ||
  RPAD(sys_context('USERENV', 'ORACLE_HOME'), 60) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Database Name: ', 20) ||
  RPAD(sys_context('USERENV', 'DB_NAME'), 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Instance Name: ', 20) ||
  RPAD(sys_context('USERENV', 'INSTANCE_NAME'), 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('DB Unique Name: ', 20) ||
  RPAD(sys_context('USERENV', 'DB_UNIQUE_NAME'), 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Container Type: ', 20) ||
  RPAD(CASE
         WHEN SYS_CONTEXT('USERENV', 'CON_NAME')='CDB$ROOT' THEN 'CDB'
         ELSE 'PDB'
       END, 22) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Server Name: ', 20) ||
  RPAD(sys_context('USERENV', 'HOST'), 32) AS database_report
FROM dual
UNION ALL
SELECT
  LPAD('Report Date: ', 20) ||
  RPAD(TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS'), 22) AS database_report
FROM dual;

ALTER session SET NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

SET serveroutput ON lines 2000 pages 2000 echo OFF

PROMPT ***
PROMPT Review &&PDB instance details
PROMPT ***
@/dbadmin/sql/info.sql
PROMPT ***
PROMPT Review and capture &&PDB init details
PROMPT ***
create pfile='${ORACLE_HOME}/dbs/init&&PDB.ora.premigration' from spfile;
PROMPT ***
PROMPT Review &&PDB timezone details
PROMPT ***
@/dbadmin/sql/list_db_timezone.sql
PROMPT ***
PROMPT Review &&PDB AWR details
PROMPT ***
@/dbadmin/sql/list_awr_details.sql
PROMPT ***
PROMPT Review &&PDB Default Tablespace Details
PROMPT ***
@/dbadmin/sql/list_default_tbsps.sql
PROMPT ***
PROMPT Review &&PDB ACL Details
PROMPT ***
@/dbadmin/sql/list_acls.sql
PROMPT ***
PROMPT Review &&PDB non default DBMS_SCHEDULER details
PROMPT ***
@/dbadmin/sql/list_dbms_scheduler_jobs.sql
PROMPT ***
PROMPT Review &&PDB invalids
PROMPT ***
@/dbadmin/sql/cr_validate_all.sql
PROMPT ***
PROMPT Review &&PDB invalid indexes
PROMPT ***
@/dbadmin/sql/list_invalid_indexes.sql
PROMPT ***
PROMPT Review &&PDB tablespace and datafile details 
PROMPT ***
@/dbadmin/sql/list_tbs_space.sql
PROMPT ***
PROMPT Review &&PDB CDB/nonCDB profile details
PROMPT ***
@/dbadmin/sql/list_profiles.sql
PROMPT ***
PROMPT Review &&PDB verify function details - used by profiles
PROMPT ***
@/dbadmin/sql/list_verify_functions.sql
PROMPT ***
PROMPT Review &&PDB SYSDBA user details
PROMPT ***
@/dbadmin/sql/list_sysdba_users.sql
PROMPT ***
PROMPT Review &&PDB user details
PROMPT ***
@/dbadmin/sql/list_all_noncdb_users.sql
PROMPT ***
PROMPT &&PDB power users
PROMPT ***
@/dbadmin/sql/list_all_pdb_power_users.sql
PROMPT ***
PROMPT Review &&PDB restricted session user details
PROMPT ***
@/dbadmin/sql/list_restricted_session_users.sql
PROMPT ***
PROMPT Review &&PDB proxy user details
PROMPT ***
@/dbadmin/sql/list_proxy_access.sql
PROMPT ***
PROMPT Review &&PDB service details
PROMPT ***
@/dbadmin/sql/list_services.sql
PROMPT ***
PROMPT Review &&PDB DB link details
PROMPT ***
@/dbadmin/sql/list_db_links.sql
PROMPT ***
PROMPT Review &&PDB Matview details
PROMPT ***
@/dbadmin/sql/list_matviews.sql
PROMPT ***
PROMPT Review &&PDB DB directory details
PROMPT ***
@/dbadmin/sql/list_db_directories.sql
PROMPT ***
PROMPT Review &&PDB SQL Plan Baseline details
PROMPT ***
@/dbadmin/sql/list_sql_plan_baselines.sql
PROMPT ***
PROMPT Review &&PDB compression details
PROMPT ***
@/dbadmin/sql/list_compression.sql
PROMPT ***
PROMPT Review &&PDB bad synonyms
PROMPT ***
@/dbadmin/sql/list_bad_synonyms.sql
PROMPT ***
PROMPT Review &&PDB audited objects and users
PROMPT ***
@/dbadmin/sql/list_audit_policies.sql
PROMPT
PROMPT *** End of Capture ***
PROMPT
PROMPT Review /dbadmin/migrations/&&CDB/&&PDB/evidence_review_&&PDB..out
PROMPT
undefine CDB
undefine PDB
