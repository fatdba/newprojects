PROMPT
PROMPT ALERT LOG LOCATION ***
PROMPT
col alert_log for a95
select vd.value||'/alert_'||vi.instance_name||'.log' "alert_log" from v$diag_info vd ,v$instance vi where vd.name like 'Diag Trace';
