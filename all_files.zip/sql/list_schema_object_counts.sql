-- $Name$ list_schema_object_counts.sql
--
-- $Log$  Modified - 04 Dec 2017 - SC - Creation
--
-- $Author$: Shawn Craven

col OWNER for a18
select owner, object_type, count(0)
from cdb_users c, dba_objects d 
where c.username = d.owner
and c.oracle_maintained = 'N'
--and c.username != 'DBNAME'
group by owner, object_type
order by owner, object_type ;
