-- Script Name: list_asm_info.sql
--
-- Author: Shawn Craven
--
-- Note: This script gathers detailed ASM information for operational DBA support.
--       It includes details on memory parameters, instance information, ASM disk groups, disks,
--       instances accessing diskgroups, current ASM disk operations, free ASM disks, disk space summary,
--       diskgroup compatibility, and alert log location.
--
-- Modified: 04 Nov 2019 - SC - Creation.
--         : 04 Jul 2024 - SC - Added more ASM specific details and improved formatting.
--

SET serveroutput ON
SET lines 2000
SET pages 2000
:wq
-- Display memory parameters
SHOW PARAMETER memory_target
SHOW PARAMETER memory_max_target
SHOW PARAMETER sga_target
SHOW PARAMETER sga_max_size
SHOW PARAMETER pga
SHOW PARAMETER recovery
SHOW PARAMETER spfile
SHOW PARAMETER diag
SHOW PARAMETER background

-- Set date format
ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

-- Display instance details
COL host_name FORMAT a38
COL name FORMAT a10
COL flashback_on FORMAT a10
COL force_logging FORMAT a10
COL current_scn FORMAT 9999999999999999

SELECT DISTINCT 
    instance_number,
    instance_name,
    status,
    database_status,
    logins,
    host_name,
    version,
    startup_time,
    SYSDATE
FROM gv$instance;

-- Display Oracle version
SELECT banner FROM v$version;

-- Set additional formatting
ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';
SELECT SYSDATE FROM dual;
SET WRAP OFF
SET LINES 400
SET PAGES 999

-- Display ASM Disk Groups
COL "Group Name" FORMAT a25
COL "Disk Name" FORMAT a30
COL "State" FORMAT a15
COL "Type" FORMAT a7
COL "Free GB" FORMAT 999,999

PROMPT
PROMPT ASM Disk Groups
PROMPT ===============
SELECT 
    group_number "Group",
    name "Group Name",
    state "State",
    type "Type",
    total_mb / 1024 "Total GB",
    free_mb / 1024 "Free GB"
FROM v$asm_diskgroup
ORDER BY 1;

-- Display ASM Disks
PROMPT
PROMPT ASM Disks
PROMPT =========
COL "Group" FORMAT 999
COL "Disk" FORMAT 999
COL "Header" FORMAT a9
COL "Mode" FORMAT a8
COL "Redundancy" FORMAT a10
COL "Failure Group" FORMAT a20
COL "Path" FORMAT a50

SELECT 
    group_number "Group",
    disk_number "Disk",
    header_status "Header",
    mode_status "Mode",
    state,
    redundancy,
    total_mb "Total MB",
    free_mb "Free MB",
    name "Disk Name",
    failgroup "Failure Group",
    path
FROM v$asm_disk
ORDER BY group_number, path, disk_number;

-- Display Instances currently accessing these diskgroups
PROMPT
PROMPT Instances currently accessing these diskgroups
PROMPT ==============================================
COL "Instance" FORMAT a8

SELECT 
    c.group_number "Group",
    g.name "Group Name",
    c.instance_name "Instance"
FROM v$asm_client c
JOIN v$asm_diskgroup g ON g.group_number = c.group_number
ORDER BY 1, 2, 3;

-- Display Current ASM disk operations
PROMPT
PROMPT Current ASM disk operations
PROMPT ===========================
SELECT * FROM v$asm_operation;

-- Display free ASM disks and their paths
PROMPT
PROMPT Free ASM disks and their paths
PROMPT ===========================
COL "Path" FORMAT a60

SELECT 
    header_status, 
    mode_status, 
    path 
FROM v$asm_disk
WHERE header_status IN ('FORMER', 'CANDIDATE')
ORDER BY 1;

-- Display ASM disks space summary
PROMPT
PROMPT ASM disks space summary
PROMPT ===========================
SET LINES 200
SET PAGES 200

COL grp_name FORMAT a20
COL grp_state FORMAT a10
COL path FORMAT a45

SELECT 
    a.name grp_name,
    a.state grp_state,
    a.type grp_type,
    b.path,
    b.header_status,
    b.mode_status,
    b.mount_status,
    b.total_mb,
    b.free_mb
FROM v$asm_diskgroup a
JOIN v$asm_disk b ON a.group_number = b.group_number(+)
ORDER BY 1, 4;

-- Display Diskgroup compatibility information
PROMPT
PROMPT Diskgroup compatibility information
PROMPT ===========================
COL compatibility FORMAT a10
COL database_compatibility FORMAT a10
COL name FORMAT a20

SELECT 
    group_number,
    name,
    compatibility,
    database_compatibility
FROM v$asm_diskgroup
ORDER BY 1;

-- Display ASM Diskgroup attributes
PROMPT
PROMPT ASM Diskgroup attributes
PROMPT ===========================
COL name FORMAT a30
COL value FORMAT a50

SELECT 
    group_number,
    name,
    value
FROM v$asm_attribute
ORDER BY 1, 2;

-- Display alert log location
PROMPT
PROMPT *** ALERT LOG LOCATION ***
PROMPT
COL alert_log FORMAT a95

SELECT 
    vd.value || '/alert_' || vi.instance_name || '.log' "alert_log" 
FROM v$diag_info vd 
JOIN v$instance vi ON vd.name LIKE 'Diag Trace';

-- Display current session details
PROMPT
PROMPT *** Current Session Details ***
PROMPT
@init.sql
