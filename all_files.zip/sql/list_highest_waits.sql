SELECT  vs.username ,
        vsw.wait_class,
        vsw.EVENT AS wait_type ,
        vsw.WAIT_TIME_MICRO / 1000 AS wait_time_ms ,
        vsw.TIME_REMAINING_MICRO / 1000 AS time_remaining_ms ,
        vsw.STATE ,
        de.SEGMENT_NAME ,
        de.SEGMENT_TYPE, 
        de.OWNER ,
        de.TABLESPACE_NAME
FROM    V$SESSION_WAIT vsw
        JOIN V$SESSION vs ON vsw.SID = vs.SID
        LEFT JOIN DBA_EXTENTS de ON vsw.p1 = de.file_id
                                    AND vsw.p2 BETWEEN de.BLOCK_ID AND (de.BLOCK_ID + de.BLOCKS)
WHERE   vsw.wait_class <> 'Idle'
        AND vs.username IS NOT NULL 
ORDER BY wait_time_ms DESC;

prompt
prompt dentify session waits
prompt
column event format a30 
column username format a20 
column state format a10 trunc 
column p1 format 999999999999 heading "P1" 
column p2 format 999999999999 heading "P2" 
column p3 format 99999 heading "P3" 
set lin 132 


SELECT username, V$SESSION_WAIT.sid, V$SESSION_WAIT.event, V$SESSION_WAIT.seq#,
     V$SESSION_WAIT.seconds_in_wait, V$SESSION_WAIT.wait_time, V$SESSION_WAIT.p1 , V$SESSION_WAIT.p2, V$SESSION_WAIT.p3,
     V$SESSION_WAIT.state, V$SESSION_WAIT.p1raw, V$SESSION_WAIT.p2raw, V$SESSION_WAIT.p3raw
   FROM V$SESSION_WAIT, V$SESSION 
WHERE V$SESSION_WAIT.SID = V$SESSION.SID 
  AND NOT(event like 'SQL%') 
  AND NOT(event like '%message%') 
  AND NOT(event like '%timer%') 
  AND NOT(event like '%pipe get%') 
  AND NOT(event like '%jobq slave wait%') 
  AND NOT(event like '%null event%') 
  AND NOT(event like '%wakeup time%') 
  ORDER BY wait_time desc, event 
/