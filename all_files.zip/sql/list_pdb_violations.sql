-- $Name$ list_pdb_violations.sql
--
-- $Log$  Modified - 04 Sep 2016 - SC - Creation
--
-- $Author$: Shawn Craven

set lines 220
col TIME for a29
col NAME for a18
col CAUSE for a25
col MESSAGE for a92
select time, type, name, cause, status, message from PDB_PLUG_IN_VIOLATIONS order by name;
