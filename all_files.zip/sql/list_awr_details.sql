-- $Name$ list_awr_details.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** AWR Details ***
prompt

set lines 220 pages 100
ALTER session SET NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

PROMPT
PROMPT *** DATABASE DETAILS ***
PROMPT
col INSTANCE_NAME for a18
col STATUS for a12
col DATABASE_STATUS for a12
col VERSION for a12
col LOGINS for a12
col LOG_MODE for a12
col OPEN_MODE for a12
col DATABASE_ROLE for a18
col DB_UNIQUE_NAME for a14
col OPEN_MODE for a20
col STARTUP_TIME for a22
col SYSDATE for a22
col HOST_NAME heading "HOST_NAME" for a23
col NAME FORMAT a10
col flashback_on FORMAT a12
col force_logging FORMAT a13
col current_scn for 9999999999999999
SELECT DISTINCT instance_number,instance_name,status,database_status,logins,cast(substr(host_name,1,19) as VARCHAR2(22))||'...' "HOST_NAME...",version,startup_time,sysdate FROM gv$instance order by 1;
SELECT DISTINCT inst_id, dbid,name,db_unique_name,log_mode,open_mode,database_role,flashback_on,force_logging,current_scn,sysdate FROM gv$database order by 1 ;
PROMPT
PROMPT *** cdb_hist_wr_control Details ***
PROMPT
set lines 220
col SNAP_INTERVAL for a18
col RETENTION for a18
select CON_ID,DBID,SNAP_INTERVAL,RETENTION from cdb_hist_wr_control order by con_id ;
--select CON_ID,DBID,SNAP_INTERVAL,RETENTION from dba_hist_wr_control order by con_id ;

PROMPT
PROMPT *** oldest and newest AWR snapshots
PROMPT
set LINES 200
column begin_interval_time format a40
column end_interval_time format a40

SELECT  snap_id, begin_interval_time, end_interval_time
  FROM  SYS.WRM$_SNAPSHOT
 WHERE  snap_id = ( SELECT MIN (snap_id) FROM SYS.WRM$_SNAPSHOT)
 UNION
SELECT  snap_id, begin_interval_time, end_interval_time
  FROM  SYS.WRM$_SNAPSHOT
 WHERE  snap_id = ( SELECT MAX (snap_id) FROM SYS.WRM$_SNAPSHOT) ;
PROMPT
PROMPT *** baseline details (if any)
PROMPT
col BASELINE_NAME for a35
col START_SNAP_TIME for a25
col END_SNAP_TIME for a25
SELECT baseline_id,baseline_name,baseline_type,start_snap_id,end_snap_id FROM dba_hist_baseline order by baseline_id ;
PROMPT 
PROMPT run the following to see baseline details
PROMPT SELECT * FROM TABLE(DBMS_WORKLOAD_REPOSITORY.SELECT_BASELINE_DETAILS(BASELINE_ID));
PROMPT

SET lines 200 pages 1000
SELECT metric_name, metric_unit, average, minimum, maximum
FROM TABLE(DBMS_WORKLOAD_REPOSITORY.SELECT_BASELINE_METRIC('Sept_Month_end_hour_1_baseline'))
ORDER BY metric_name;
