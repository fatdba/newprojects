-- Script Name: list_fra_reclaimable.sql
--
-- Author: Shawn Craven
--
-- Description: This script lists the reclaimable status of archived logs in the Fast Recovery Area (FRA).
--              It helps determine which archived logs are eligible for deletion, allowing efficient management of FRA space.
--
-- Note: Ensure that the query is executed with appropriate privileges, and be cautious when considering manual deletion
--       of archived logs, as this could impact recovery scenarios.
--
-- Modified: 16 Jun 2014 - SC - Creation
--

column deleted format a7
column reclaimable format a11
set linesize 120

select applied, deleted, backup_count,
       decode(rectype,11,'YES','NO') reclaimable,
       count(*) as count,
       to_char(min(completion_time),'DD-MON hh24:mi') first_time,
       to_char(max(completion_time),'DD-MON hh24:mi') last_time,
       min(sequence#) first_seq,
       max(sequence#) last_seq
from v$archived_log
left outer join sys.x$kccagf using(recid)
where is_recovery_dest_file='YES'
group by applied, deleted, backup_count, decode(rectype,11,'YES','NO')
order by min(sequence# ;