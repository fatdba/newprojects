-- $Name$: list_user_last_login.sql
--
-- $Log$:  Modified - 10 Feb 2022 - creation
--
-- $Author$: Shawn Craven

/*
col OWNER for a22
select owner, last_login, object_type, count(0)
from cdb_users c, dba_objects d 
where c.username = d.owner
and c.oracle_maintained = 'N'
group by owner, last_login, object_type
order by owner, object_type ;
*/

alter session set NLS_TIMESTAMP_TZ_FORMAT='DD.MM.YYYY HH24:MI:SS';

accept older_than prompt "Enter older than SYSDATE - days:"

col USERNAME for a22
col LAST_LOGIN for a22
select username, last_login
from cdb_users
where oracle_maintained = 'N'
and last_login < sysdate - &older_than
order by username ;
