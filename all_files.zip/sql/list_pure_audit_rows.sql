-- $Name$ list_pure_audit_rows.sql
--
-- $Log$  Modified - 09 Feb 2022 - SC - Creation
--
-- $Author$: Shawn Craven

set lines 330 pages 100
col EVENT_TIMESTAMP for a30
col AUDIT_TYPE for a14
col OS_USERNAME for a18
col USERHOST for a38
col DBUSERNAME for a18
col ACTION_NAME for a20
col RETURN_CODE for 999999
col AUTHENTICATION_TYPE for a32
col SQL_TEXT for a55
select EVENT_TIMESTAMP,DBUSERNAME,ACTION_NAME,RETURN_CODE,AUDIT_TYPE,OS_USERNAME,cast(substr(userhost,1,16) as VARCHAR2(16))||'...' "HOST_NAME...",SQL_TEXT 
from unified_audit_trail 
where DBUSERNAME not in ('SYSTEM')
and EVENT_TIMESTAMP > sysdate -45
order by EVENT_TIMESTAMP asc;
