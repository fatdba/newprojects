-- $Name$ list_compression.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt *** Table-Index Compression Details  ***
set lines 220 pages 100
col OWNER for a25
col TABLE_NAME for a40
col TABLESPACE_NAME for a35
col COMPRESS_FOR for a12
col NUM_ROWS for 9,999,999,999
select OWNER, TABLE_NAME, TABLESPACE_NAME, COMPRESSION, COMPRESS_FOR, NUM_ROWS
from DBA_TABLES
where COMPRESS_FOR is not null 
and OWNER not in ('CTXSYS','MDSYS','SYS','SYSTEM','DBSNMP','ORDDATA','OLAPSYS','GSMADMIN_INTERNAL','WMSYS','XDB')
order by OWNER, TABLE_NAME, TABLESPACE_NAME ;
