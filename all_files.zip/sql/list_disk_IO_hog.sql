--scraven
set lines 160
set pages 500

col disk_reads for 999999999999

SELECT sql_id
     , executions
     , disk_reads disk_reads
     , round(disk_reads/executions) reads_per_exe
FROM
(
   SELECT ROUND(disk_reads) disk_reads
        , Executions
        , sql_id
        , ROW_NUMBER() OVER (PARTITION BY sql_text ORDER BY disk_reads * executions DESC) topsql
   FROM
   (
       SELECT   AVG(s.disk_reads) OVER (PARTITION BY sql_text) disk_reads
              , MAX(s.executions) OVER (PARTITION BY sql_text) executions
              , s.sql_id
              , s.sql_text
       FROM     v$sql      s
            ,   v$sql_plan p
       WHERE    s.hash_value = p.hash_value 
       AND      p.operation  = 'TABLE ACCESS' 
       AND      p.options    = 'FULL' 
       AND      p.object_owner NOT IN ('SYS','SYSTEM')
       AND      s.executions > 1
   ) 
   ORDER BY disk_reads * executions desc
)
WHERE TopSQL = 1
AND   rownum <= 20;
