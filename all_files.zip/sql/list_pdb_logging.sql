COLUMN pdb_name FORMAT A20
COLUMN force_logging FORMAT A15
COLUMN force_nologging FORMAT A15

SELECT pdb_id,
       pdb_name,
       logging,
       force_logging,
       force_nologging
FROM   cdb_pdbs
ORDER BY 1;
