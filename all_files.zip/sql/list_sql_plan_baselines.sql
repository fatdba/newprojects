-- $Name$ list_sql_plan_baselines.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

prompt
prompt *** SQL PLAN BASELINE DETAILS ***
prompt

select * FROM dba_sql_plan_baselines;
