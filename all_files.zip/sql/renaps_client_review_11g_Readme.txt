# renaps_client_review_11g_Readme.txt - Jan 22, 2024
# Renaps client information collection SQL script README

## Overview:

This SQL script is designed to be executed against the clients' Oracle database as the SYS user. If the client is running multitenant, the script should be run at least twice - once in the CDB and once in each PDB. The output will be saved to a file named `renaps_client_review_<DBNAME>_YYYY-MM-DD_HHMISS.txt`. The script has been tested on Oracle versions 11g, 12c, 18c, and 19c.

## Prerequisites:

- Connect to the Oracle database as the SYS user or with a user having sufficient privileges.

## Usage:

1. Connect to the Oracle database using SQL*Plus or another SQL client:
   
    sqlplus sys/password@<database> as sysdba

2. Run the SQL script:

    @renaps_client_review_11g.sql;

## Output Explanation:

The output will be saved to a file named `renaps_client_review_<DBNAME>_YYYY-MM-DD_HHMISS.txt`. Review the file for key information and check for any reported issues or errors.

## Contact Information:

For support or inquiries, contact Renaps Support Team:
- Email: scraven@renaps.com

