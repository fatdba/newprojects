-- $Name$ list_lowest_scn.sql
-- $Log$: Created  - 04 Sept 2017
--
-- $Author$: Shawn Craven

select current_scn from v$database ;
select min(fhscn) from x$kcvfh ;
select min(f.fhscn) from x$kcvfh f, v$datafile d where f.hxfil =d.file# and d.enabled != 'READ ONLY' ;
