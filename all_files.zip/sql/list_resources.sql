set lines 220
col resource_name format a15
select INST_ID, resource_name, current_utilization, max_utilization, limit_value
  from gv$resource_limit
 where resource_name in ('sessions', 'processes') order by 1,2 ;

