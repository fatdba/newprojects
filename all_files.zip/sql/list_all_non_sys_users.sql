set lines 120
set pages 9000
select distinct owner 
from dba_segments
where owner in (select username from dba_users where default_tablespace not in ('SYSTEM','SYSAUX')) 
order by owner ;


SELECT username
  FROM dba_users u
 WHERE EXISTS (
    SELECT 1
      FROM dba_objects o
     WHERE o.owner = u.username ) ;
     
set lines 120
set pages 9000
select name from v$database;
select distinct owner
  from dba_segments
 where owner not in (
'SYSTEM', 'XDB', 'SYS', 'TSMSYS', 'MDSYS', 'EXFSYS', 'WMSYS', 'ORDSYS', 'OUTLN', 'DBSNMP')
order  by owner ;     
