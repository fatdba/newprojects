-- $Name$: list_stats_dbms_scheduler_runs.sql
--
-- $Log$: Created  - 04 Sep 2016
--        Modified - 04 Oct 2024
--
-- $Author$: Shawn Craven

-- Script: Retrieves DBMS_SCHEDULER job run details from the last 8 days
-- Purpose: Provides an overview of the recent job executions excluding system jobs.
-- Usage: To check the status, start time, and duration of jobs scheduled through DBMS_SCHEDULER.

PROMPT
PROMPT *** DBMS_SCHEDULER JOB RUN DETAILS - LAST 8 DAYS ***

SET LINESIZE 220
SET PAGESIZE 100
SET FEEDBACK OFF
SET HEADING ON
SET TIMING ON

COLUMN JOB_NAME FORMAT A32
COLUMN STATUS FORMAT A10
COLUMN ACTUAL_START_DATE FORMAT A45
COLUMN RUN_DURATION FORMAT A18
COLUMN OWNER FORMAT A15

SELECT 
    owner, 
    job_name,
    status,
    error#,
    TO_CHAR(actual_start_date, 'YYYY-MM-DD HH24:MI:SS') AS actual_start_date, 
    run_duration 
FROM 
    dba_scheduler_job_run_details
WHERE 
    owner NOT IN ('ORACLE_OCM', 'SYS', 'SYSTEM') 
    AND actual_start_date > SYSDATE - 8
ORDER BY 
    actual_start_date;

PROMPT
PROMPT *** End of Report ***
