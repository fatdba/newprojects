-- $Name$ list_invalid_logins.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

col AUDIT_TYPE for a22
col OS_USERNAME for a22
col USERHOST for a25
col TERMINAL for a22
col DBUSERNAME for a22
col EVENT_TIMESTAMP for a29
col SQL_TEXT for a55
set lines 330 pages 100
select AUDIT_TYPE, OS_USERNAME, USERHOST, TERMINAL, INSTANCE_ID, DBUSERNAME, EVENT_TIMESTAMP, RETURN_CODE
from unified_audit_trail 
where action_name='LOGON' 
and EVENT_TIMESTAMP > sysdate -1/24
order by EVENT_TIMESTAMP ;
