-- $Name$: list_nondefault_users.sql
--
-- $Log$:  Modified - 04 Sept 2015 - creation
--
-- $Author$: Shawn Craven

prompt
prompt *** Non Default User with last login time ***
prompt
set lines 220
col OWNER for a22
select owner, last_login, object_type, count(0)
from cdb_users c, dba_objects d 
where c.username = d.owner
and c.oracle_maintained = 'N'
group by owner, last_login, object_type
order by owner, object_type ;
