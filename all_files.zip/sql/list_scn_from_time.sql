-- $Name$
-- $Log$: Modified - 06 Feb 2015 - SC - creation
--
-- $Author$: Shawn Craven


col SCN for 999999999999999999
prompt Format --> DD/MM/YYYY HH24:MI:SS
select timestamp_to_scn(to_timestamp('&ENTER_TIME','DD/MM/YYYY HH24:MI:SS')) as scn from dual;
