-- $Name$ list_fra2.sql
-- $Log$: Created  - 04 Sept 2016
--        Modified - 01 Jun  2020 - SC - Added additional default schemas to ignore
--
-- $Author$: Shawn Craven

PROMPT
PROMPT *** FRA details ***
PROMPT
set lines 100
col name format a60
select name, floor(space_limit / 1024 / 1024) "Size MB", ceil(space_used / 1024 / 1024) "Used MB"
from v$recovery_file_dest;
PROMPT 
PROMPT *** FRA Occupants ***
PROMPT
SELECT * FROM V$FLASH_RECOVERY_AREA_USAGE;
set lines 220
PROMPT
PROMPT *** Location and size of the FRA ***
PROMPT
show parameter db_recovery_file_dest
show parameter db_flashback_retention_target
PROMPT
PROMPT *** Size, Used, Reclaimable ***
SELECT
  ROUND((A.SPACE_LIMIT / 1024 / 1024 / 1024), 2) AS FLASH_IN_GB, 
  ROUND((A.SPACE_USED / 1024 / 1024 / 1024), 2) AS FLASH_USED_IN_GB, 
  ROUND((A.SPACE_RECLAIMABLE / 1024 / 1024 / 1024), 2) AS FLASH_RECLAIMABLE_GB,
  SUM(B.PERCENT_SPACE_USED)  AS PERCENT_OF_SPACE_USED
FROM
  V$RECOVERY_FILE_DEST A,
  V$FLASH_RECOVERY_AREA_USAGE B
GROUP BY
  SPACE_LIMIT, 
  SPACE_USED , 
  SPACE_RECLAIMABLE ;

