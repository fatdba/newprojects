col NAMESPACE for a25
col SCHEMA for a25
col PACKAGE for a25
SELECT namespace, schema, package, type 
  FROM dba_context
 WHERE schema = '&SCHEMA' ;
