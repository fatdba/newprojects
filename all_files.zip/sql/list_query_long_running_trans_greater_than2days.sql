--generates kill syntax based on logon_time > 2 days ago

alter session set NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS';

  set heading on pagesize 999 linesize 250
  col instance for a8
  col sid for 999999
  col machine for a9
  col host_name format a20
  col command format a80 hea 'kill command'
  col osuser for a9
  col USED_UBLK hea 'USED|UBLK'
  col USED_UREC hea 'USED|UREC'
  col "SPID (OS process)" for a12 hea 'SPID|(OS process)'
  --spool ${SPOOL_FILE}
  select i.instance_name INSTANCE, b.sid, b.serial#, b.osuser, b.username, b.sql_id, b.status, to_char(to_date(a.start_time, 'mm/dd/yy hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') as
  "START TIME TRANSACTION", to_char(b.LOGON_TIME,'YYYY-MM-DD HH24:MI:SS') LOGON_TIME, p.SPID as "SPID (OS process)", b.machine, a.cr_get, a.cr_change, a.used_ublk,
  a.used_urec, a.log_io, a.phy_io, b.last_call_et from gv$instance i, gv$transaction a, gv$session b, gv$process p
  where  a.inst_id  = b.inst_id
  and    a.ses_addr = b.saddr
  and    p.inst_id  = b.inst_id
  and    p.addr     = b.paddr
  and    i.inst_id  = b.inst_id
  and    to_date(a.start_time, 'mm/dd/yy hh24:mi:ss') < sysdate - 2
  order  by 7,1;

