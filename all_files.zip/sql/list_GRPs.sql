-- $Name$ cr_renaps_dba_users.sql
--
-- $Log$  Modified - 16 Jun 2016 - SC - Creation
--                 - 14 Mar 2022 - SC - Added GRP_SIZE_GB
--
-- $Author$: Shawn Craven

alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';

prompt list of GRPs
set lines 220
column name format a45
col time for a31
column scn format 99999999999999
select CON_ID, NAME, TIME, SCN, GUARANTEE_FLASHBACK_DATABASE, DATABASE_INCARNATION#, STORAGE_SIZE/1024/1024/1024 GRP_SIZE_GB from v$restore_point order by CON_ID, TIME ;

column oldest_flashback_time for a21
select oldest_flashback_time from v$flashback_database_log;
