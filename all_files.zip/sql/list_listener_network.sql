set lines 220
col TYPE    for a15
col NETWORK for a15
col VALUE   for a105
select INST_ID,TYPE,NETWORK,VALUE from gv$listener_network order by 1,2,4 ;

