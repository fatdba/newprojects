-- $Name$ list_segment.sql
-- $Log$: Modified - 04 Sept 2018
-- $Author$: Shawn Craven

set lines 120
set pages 9000

col owner form A22
col segment_name form A30
col segment_type form A18
col tablespace_name form A25
col blocks form 99999999
col extents form 99999999

select  OWNER,
        SEGMENT_NAME,
        SEGMENT_TYPE,
        TABLESPACE_NAME,
        BLOCKS,
        EXTENTS
  from  dba_segments
 where  tablespace_name = upper('&TABLESPACE')
--and  owner not like 'SYS%'
--and  segment_type != 'TABLE'
order  by OWNER, SEGMENT_NAME ;
-- order  by blocks ;
