-- $Name$: 01_post_CDB_build.sql
--
-- $Log$:  Modified - 16 Jun 2023 - SC - Creation.
--                  - 10 Jul 2023 - SC - Added alter system set archive_lag_target=900;
--                  - 04 Jun 2024 - SC - Added C##CVBACKUP and C##TRANSPORTDG common user creation statements.
--                  - 26 Jun 2024 - SC - Modified C##TRANSPORTDG grants and reporting checks.
--
-- Note: This script performs all post CDB build steps to customize to client standards
--
-- $Author$: Shawn Craven

prompt
prompt CDB - Create pre custimization PFILE as backup
prompt
create pfile='${ORACLE_HOME}/dbs/init${ORACLE_UNQNAME}.ora.pre_CDB_customization' from spfile;
! ls -l ${ORACLE_HOME}/dbs/init${ORACLE_UNQNAME}.ora*

prompt
prompt CDB - Move old audit segments from SYSTEM tablespace or else orachk will complain (even if unified auditing is enabled)
prompt Review current tablespace table segments are located in
prompt
col table_name for a32
SELECT table_name, tablespace_name FROM dba_tables WHERE table_name IN ('AUD$', 'FGA_LOG$');

prompt
prompt CDB - Review audit table sizes
prompt
column segment_name for a10
select segment_name,bytes/1024/1024 size_in_megabytes from dba_segments where segment_name in ('AUD$','FGA_LOG$');

prompt
prompt CDB - Move table AUD$ to SYSAUX tbsp
prompt
BEGIN
DBMS_AUDIT_MGMT.set_audit_trail_location(
audit_trail_type => DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD,
audit_trail_location_value => 'SYSAUX');
END;
/

prompt
prompt CDB - Move table FGA_LOG$ to SYSAUX
prompt
BEGIN
DBMS_AUDIT_MGMT.set_audit_trail_location(
audit_trail_type => DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD,--this moves table FGA_LOG$
audit_trail_location_value => 'SYSAUX');
END;
/

prompt
prompt Force audit_trail to 'DB,EXTENDED'
alter system set audit_trail=db,extended  scope=spfile;

prompt
prompt Review current tablespace table segments are located in
prompt
col table_name for a32
SELECT table_name, tablespace_name FROM dba_tables WHERE table_name IN ('AUD$', 'FGA_LOG$');

prompt
prompt Perform the following only if the database is EE
prompt
SET SERVEROUTPUT ON;
DECLARE
  v_edition VARCHAR2(100);
  v_flashback_status VARCHAR2(10) := 'disabled';
BEGIN
  -- Retrieve the database edition
  SELECT banner INTO v_edition
  FROM v$version
  WHERE banner LIKE 'Oracle Database%';

  -- Check if the edition is Enterprise
  IF v_edition LIKE '%Enterprise%' THEN
    -- Enable flashback
    EXECUTE IMMEDIATE 'ALTER DATABASE FLASHBACK ON';
    v_flashback_status := 'enabled';

    -- Modify AWR_SNAPSHOT_TIME_OFFSET
    EXECUTE IMMEDIATE 'ALTER SYSTEM SET AWR_SNAPSHOT_TIME_OFFSET=1000000 SCOPE=BOTH';
  END IF;

  -- Echo the status of flashback
  DBMS_OUTPUT.PUT_LINE('Flashback: ' || v_flashback_status);

  -- Echo AWR_SNAPSHOT_TIME_OFFSET only for Enterprise Edition
  IF v_edition LIKE '%Enterprise%' THEN
    DBMS_OUTPUT.PUT_LINE('AWR_SNAPSHOT_TIME_OFFSET: 1000000');
  END IF;
END;
/

prompt
prompt Create client password verify functions
prompt
@list_verify_functions.sql
@cr_OLT_1_pswd_complex_f.sql
@list_verify_functions.sql

prompt
prompt Modfify PASSWORD_LIFE_TIME to unlimited for the DEFAULT profile
prompt
@list_profile_PASSWORD_LIFE_TIME.sql
ALTER PROFILE DEFAULT LIMIT PASSWORD_LIFE_TIME unlimited ;
@list_profile_PASSWORD_LIFE_TIME.sql

prompt
prompt Create client common profiles
prompt
@list_profiles.sql
@cr_OLT_4_common_profiles.sql
@list_profiles.sql
@list_profile_PASSWORD_LIFE_TIME.sql

prompt
prompt Set hidden parameter _exclude_seed_cdb_view to FALSE in multitenant envs
prompt
col PARAMETER for a55
col VALUE for a18

select ksppinm as PARAMETER, ksppstvl as VALUE from x$ksppi a, x$ksppsv b
where a.indx=b.indx and ksppinm = '_exclude_seed_cdb_view' ;

alter system set "_exclude_seed_cdb_view"=FALSE scope=both;

select ksppinm as PARAMETER, ksppstvl as VALUE from x$ksppi a, x$ksppsv b
where a.indx=b.indx and ksppinm = '_exclude_seed_cdb_view' ;

prompt
prompt Set archive_lag_target to 900 - Ensuring archive log swiutches every 15 minutes
prompt
select ksppinm as PARAMETER, ksppstvl as VALUE from x$ksppi a, x$ksppsv b
where a.indx=b.indx and ksppinm = 'archive_lag_target' ;

alter system set archive_lag_target=900;

select ksppinm as PARAMETER, ksppstvl as VALUE from x$ksppi a, x$ksppsv b
where a.indx=b.indx and ksppinm = 'archive_lag_target' ;

-- SC prompt
-- SC prompt Create CDB level EXPORT DB Directory dynamically
-- SC prompt

-- SC !export CLUSTER_NAME=$(hostname -s | sed 's/..$//')-scan
-- SC !mkdir -p /export/${CLUSTER_NAME}/${ORACLE_UNQNAME}/RMAN
-- SC !mkdir -p /export/${CLUSTER_NAME}/${ORACLE_UNQNAME}/EXPORT
-- SC !mkdir -p /export/${CLUSTER_NAME}/${ORACLE_UNQNAME}/pdb_images

prompt
prompt CDB - Create post custimization PFILE as backup
prompt
create pfile='${ORACLE_HOME}/dbs/init${ORACLE_UNQNAME}.ora.post_CDB_customization' from spfile;
! ls -l ${ORACLE_HOME}/dbs/init${ORACLE_UNQNAME}.ora*

prompt
prompt List important CDB init parameter values *** Please Review! ***
prompt
@list_parameters_CDB.sql

prompt
prompt List CDB patch details
prompt
@list_cdb_patch_details

prompt
prompt Modify the DBSNMP user for OEM Cloud Control
prompt
grant execute on UTL_FILE to DBSNMP;
grant inherit privileges on user SYS to DBSNMP;
ALTER USER DBSNMP IDENTIFIED BY VALUES 'S:E09A2577C198138E3047E5479DB37D48015974A71882A8F13401BB0C27C8;T:280D7906D6B17ABE1B55959B12FCEFDB4E0538714D120D1B528A65E4107483F709A663341A51697F566C9DBB759D216CB515CA55BF79307EC3A49C1E52FF03B768F4DC908F6F498FB654B812B71C6068';
alter user dbsnmp account unlock;

prompt
prompt Create the C##REMOTE_CLONE_USER common user
prompt
CREATE USER c##remote_clone_user IDENTIFIED BY "ChangeM3n0w!" CONTAINER=ALL;
GRANT CREATE SESSION, CREATE PLUGGABLE DATABASE TO c##remote_clone_user CONTAINER=ALL;
ALTER USER C##REMOTE_CLONE_USER profile C##R$OLT_APP ;
ALTER USER C##REMOTE_CLONE_USER IDENTIFIED BY VALUES 'S:B7B850113337113C7C1488AE9DD17102D4EF59DC144B21547736AC014146;T:026E1FA9B46233673AC261EE0176BC5B9C8971CC4FE8E0523FFD11ACC085EDC2905F086D79B9977DCC9CB03442950B606CACE277372E3B0533B460C4C50977AB42B943B99F1F46776E026BC74D66001C';

prompt
prompt Create the C##TRANSPORTDG common user
prompt
CREATE USER C##TRANSPORTDG IDENTIFIED BY "ChangeM3n0w!" CONTAINER=ALL;
GRANT CONNECT, CREATE SESSION TO C##TRANSPORTDG CONTAINER=ALL;
ALTER USER C##TRANSPORTDG profile C##R$OLT_APP ;
ALTER USER C##TRANSPORTDG IDENTIFIED BY VALUES 'S:A3FDECAA4211C7405A63F0939A5C2C341E5E0C1F1BF2E1139807C09BE86F;T:25836C326385E194D5BA4001D2DB10205099B043DCDE531C9441FBB7A268222042467531A6501B5C21495694BE5B515D9F1F3F10A68CCC4A7C0C5EE629B27797D6B14A8C02E0A50CF8B11DE18E7C5152;AB3EF8A119BF1177';
grant sysoper to C##TRANSPORTDG;

--prompt
--prompt Modifying redo_transport_user to C##TRANSPORTDG
--show parameter redo_transport_user
--alter system set redo_transport_user = 'C##TRANSPORTDG';
--show parameter redo_transport_user
--prompt
--prompt Ensure C##TRANSPORTDG has SYSOPER priv for Data Guard
--col USERNAME for a15
--select USERNAME, SYSDBA, SYSOPER, SYSBACKUP, SYSDG, SYSKM from V$PWFILE_USERS where USERNAME = 'C##TRANSPORTDG';

prompt
prompt Modify SYS and SYSTEM passwords to current client standard
prompt
ALTER USER SYS IDENTIFIED BY VALUES 'S:79F13E8D7874590036C2598F1FFE7554167C99E40BDD3AB37CBCE5B02DF7;T:F4AB332BD5E65C18E4AE3D0BC64F358D886DE257FFEB08FB4977396A328415B80D2C9B462ABC768A57DAAB4A68A79328005E787B9DBC0EE17F55808722CAB6B39E97D352DBBBBA4F4D2B56DE2B1FAFF9';
ALTER USER SYSTEM IDENTIFIED BY VALUES 'S:A609233CF41B3D13E5B811B16644342EFEF153CFBEF1CD22CE19F8757756;T:283E398CA8042ADCC9C326ABFB42E9054F74417BA56527E334591C64D0CF44CBB7E8F3CF228FE0FF4D2466D391B2C708B55335E0F7DEBE19B8C2EB997B000490846D710DC74C054F830FE70738F23CFA';

prompt
prompt Common Users *** Non Default Users ***
@/dbadmin/sql/list_cdb_users.sql

prompt
prompt ***
prompt *** Remember to create CDB level EXPORT DB directory manually ***
prompt ***
