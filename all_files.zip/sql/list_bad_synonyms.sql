-- $Name$: list_bad_synonyms.sql
--
-- $Log$:  Modified - 04 June 2012 - creation
--
-- $Author$: Shawn Craven

prompt
prompt *** Report Bad Synonyms ***
prompt
set lines 220 pages 100
col SYN_OWNER for a25
col SYN_NAME for a55
col OBJ_OWNER for a25
col OBJ_NAME for a55
col OBJ_STATUS for a15
SELECT S.OWNER as SYN_OWNER, S.SYNONYM_NAME as SYN_NAME,
    S.TABLE_OWNER as OBJ_OWNER, S.TABLE_NAME as OBJ_NAME,
    CASE WHEN O.OWNER is null THEN 'MISSING' ELSE O.STATUS END as OBJ_STATUS
FROM DBA_SYNONYMS S
    LEFT JOIN DBA_OBJECTS O ON S.TABLE_OWNER = O.OWNER AND S.TABLE_NAME = O.OBJECT_NAME
WHERE O.OWNER is null
    OR O.STATUS != 'VALID'
ORDER by SYN_OWNER ;
