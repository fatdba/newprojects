-- $Name$ list_nondefault_init_params.sql
--
-- $Log$: Modified - 14 Nov 2018 - SC - Creation
--                 - 27 Oct 2021 - SC - Added PDB_spfile$ view query
--                 - 06 Mar 2023 - SC - Rewrote entire query to differentiate from pdb_spfile$ and v$system_parameter
--
-- $Author$: Shawn Craven
--
prompt
prompt *** Settings in pdb_spfile$ ***
prompt
col PDB_NAME for a18
col NAME for a32
col value$ for a20
col PDB_VALUE  for a32
col ROOT_VALUE for a32
select pdb_name,name,value$
  from pdb_spfile$ left join dba_pdbs on (CON_UID=pdb_uid)
 where  bitand(nvl(spare2,0),1)=0
 order by PDB_NAME, NAME ;

prompt
prompt *** Settings in v$system_parameter ***
prompt
select a.pdb_name, a.name, a.value PDB_VALUE, b.value ROOT_VALUE from
  (select pdb_name,name,value
   from v$system_parameter a left join dba_pdbs b on (a.CON_ID=b.pdb_id)
   where a.con_id>2 and isdefault='FALSE') a,
  (select 'CDB$ROOT' pdb_name,name,value
   from v$system_parameter where con_id=0) b
where a.name=b.name
order by 1,2;

/*
prompt
prompt *** CDB LEVEL NONDEFAULT INIT PARAMETERS ***
prompt
set lines 220 pages 100
col name format a38
col value format a105
--select  name, value from v$parameter where isdefault = 'FALSE' and value is not null order by name ;
SELECT con_id,name,VALUE FROM v$system_parameter WHERE isdefault='FALSE' order by 1,2

prompt
prompt *** PDB LEVEL CUSTOM INIT PARAMETERS ***
prompt

col SID for a12
col VALUE$ for a32
col PDB_NAME for a32

SELECT sid, pdb_uid, name, VALUE$ FROM pdb_spfile$ order by pdb_uid,name ;

prompt
prompt *** PDB UID DETAILS ***
prompt
SELECT pdb_name,con_uid FROM dba_pdbs;
*/