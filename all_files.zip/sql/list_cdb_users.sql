-- $Name$ list_cdb_users.sql

-- $Log$: Modified - 04 Sept 2017 - SC - Creation.
--                 - 08 Mar 2023  - SC - Reformatted output and added password_change_date column.
--                 - 02 May 2023  - SC - Cleanup query and ensured PASSWORD_EXPIRE is reported.
--
-- $Author$: Shawn Craven

prompt
prompt *** List of non default CDB Common users ***
prompt

set lines 220 pages 50
col USERNAME for a25
col ACCOUNT_STATUS for a18
col PROFILE for a18
col COMMON for a6
col LAST_LOGIN for a22
col password_change_date for a22
col expiry_date format a22
col created for a22
col CON_ID for 999999
select CON_ID, username, common, account_status, profile, created, to_char(last_login, 'DD-MON-RRRR hh24:mi:ss') as last_login, to_char(password_change_date, 'DD-MON-RRRR hh24:mi:ss') as password_change_date,to_char(expiry_date, 'DD-MON-RRRR hh24:mi:ss') as password_expire, password_versions
from cdb_users
where CON_ID = 1
and ORACLE_MAINTAINED != 'Y'
order by 1,2 ;