-- $Name$ list_pdb_history.sql
--
-- $Log$: Modified - 24 Sep 2019 - SC - Creation
--
-- $Author$: Shawn Craven
--

col PDB_NAME for a22
col DB_NAME for a12
col DB_UNIQUE_NAME for a12
col OP_TIMESTAMP for a35

select PDB_NAME,PDB_ID,DB_NAME,DB_UNIQUE_NAME,OP_TIMESTAMP,OPERATION from dba_pdb_history order by OP_TIMESTAMP ;
