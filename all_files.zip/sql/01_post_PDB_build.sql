-- $Name$ 01_post_PDB_build.sql
--
-- $Log$: Modified - 28 Apr 2023 - SC - Creation.
--      : Modified - 15 May 2024 - SC - Modified to client specific environment.
--
-- $Author$: Shawn Craven (scraven@renaps.com)
--

--# Append DB infirmation
@report_header.sql

--*** Renaps post PDB build customization steps ***

--# PDB - backup of original spfile - prior to any customization
DECLARE
  oracle_home VARCHAR2(200);
  cdb_name VARCHAR2(30);
  pdb_name VARCHAR2(30);
BEGIN
  oracle_home := sys_context('USERENV', 'ORACLE_HOME');
  cdb_name := sys_context('USERENV', 'INSTANCE_NAME');
  pdb_name := sys_context('USERENV', 'DB_NAME');
  EXECUTE IMMEDIATE 'CREATE PFILE=''' || oracle_home || '/dbs/init' || cdb_name || '.ora.pre_' || pdb_name || '_customization'' FROM SPFILE';
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error: ' || SQLCODE || ' - ' || SQLERRM);
END;
/
@list_nondefault_init_params.sql

--create USER tablespace if it does not already exist
DECLARE
    v_count INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM dba_tablespaces
    WHERE tablespace_name = 'USERS';

    IF v_count = 0 THEN
        EXECUTE IMMEDIATE 'CREATE TABLESPACE USERS';
        DBMS_OUTPUT.PUT_LINE('Tablespace USERS created successfully.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Tablespace USERS already exists.');
    END IF;
END;
/
ALTER DATABASE DEFAULT TABLESPACE USERS ;

--# PDB - Create separate password verify function
--# PDB - Review current profiles using PASSWORD_VERIFY_FUNCTION as a resource
@list_profiles.sql
@list_profile_PASSWORD_VERIFY_FUNCTION.sql

--# PDB - create custom local verify function
@cr_OLT_1_pswd_complex_f.sql

--# PDB - Create custom local Profiles
DECLARE
  v_count INTEGER;
BEGIN
-- Check if R$OLT_APP profile already exists
  SELECT COUNT(*) INTO v_count FROM DBA_PROFILES WHERE PROFILE = 'R$OLT_APP';
  IF v_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE PROFILE R$OLT_APP LIMIT
      FAILED_LOGIN_ATTEMPTS 3
      PASSWORD_LOCK_TIME 0.015
      PASSWORD_LIFE_TIME UNLIMITED
      PASSWORD_GRACE_TIME 0
      PASSWORD_REUSE_MAX 10
      PASSWORD_REUSE_TIME 180
      PASSWORD_VERIFY_FUNCTION R$PSWD_COMPLEX_F';
  ELSE
    DBMS_OUTPUT.PUT_LINE('Profile R$OLT_APP already exists');
  END IF;

-- Check if R$OLT_DBL_OWNER profile already exists
  SELECT COUNT(*) INTO v_count FROM DBA_PROFILES WHERE PROFILE = 'R$OLT_DBL_OWNER';
  IF v_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE PROFILE R$OLT_DBL_OWNER LIMIT
      FAILED_LOGIN_ATTEMPTS 3
      PASSWORD_LOCK_TIME 0.015
      PASSWORD_LIFE_TIME UNLIMITED
      PASSWORD_GRACE_TIME 0
      PASSWORD_REUSE_MAX 10
      PASSWORD_REUSE_TIME 180
      PASSWORD_VERIFY_FUNCTION R$PSWD_COMPLEX_F';
  ELSE
    DBMS_OUTPUT.PUT_LINE('Profile R$OLT_DBL_OWNER already exists');
  END IF;

-- Check if R$OLT_SCHEMA profile already exists
  SELECT COUNT(*) INTO v_count FROM DBA_PROFILES WHERE PROFILE = 'R$OLT_SCHEMA';
  IF v_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE PROFILE R$OLT_SCHEMA LIMIT
      FAILED_LOGIN_ATTEMPTS 3
      PASSWORD_LOCK_TIME 0.015
      PASSWORD_LIFE_TIME UNLIMITED
      PASSWORD_GRACE_TIME 0
      PASSWORD_REUSE_MAX 10
      PASSWORD_REUSE_TIME 180
      PASSWORD_VERIFY_FUNCTION R$PSWD_COMPLEX_F';
  ELSE
    DBMS_OUTPUT.PUT_LINE('Profile R$OLT_SCHEMA already exists');
  END IF;

-- Check if R$OLT_DBA profile already exists
  SELECT COUNT(*) INTO v_count FROM DBA_PROFILES WHERE PROFILE = 'R$OLT_DBA';
  IF v_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE PROFILE R$OLT_DBA LIMIT
      FAILED_LOGIN_ATTEMPTS 3
      PASSWORD_LOCK_TIME 0.015
      PASSWORD_LIFE_TIME 180
      PASSWORD_GRACE_TIME 0
      PASSWORD_REUSE_MAX 10
      PASSWORD_REUSE_TIME 180
      PASSWORD_VERIFY_FUNCTION R$PSWD_COMPLEX_F';
  ELSE
    DBMS_OUTPUT.PUT_LINE('Profile R$OLT_DBA already exists');
  END IF;

-- Check if R$OLT_SYS profile already exists
  SELECT COUNT(*) INTO v_count FROM DBA_PROFILES WHERE PROFILE = 'R$OLT_SYS';
  IF v_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE PROFILE R$OLT_SYS LIMIT
      FAILED_LOGIN_ATTEMPTS 3
      PASSWORD_LOCK_TIME 0.015
      PASSWORD_LIFE_TIME 180
      PASSWORD_GRACE_TIME 0
      PASSWORD_REUSE_MAX 10
      PASSWORD_REUSE_TIME 180
      PASSWORD_VERIFY_FUNCTION R$PSWD_COMPLEX_F';
  ELSE
    DBMS_OUTPUT.PUT_LINE('Profile R$OLT_SYS already exists');
  END IF;

-- Check if R$OLT_USER profile already exists
  SELECT COUNT(*) INTO v_count FROM DBA_PROFILES WHERE PROFILE = 'R$OLT_USER';
  IF v_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE PROFILE R$OLT_USER LIMIT
      FAILED_LOGIN_ATTEMPTS 3
      PASSWORD_LOCK_TIME 0.015
      PASSWORD_LIFE_TIME 180
      PASSWORD_GRACE_TIME 0
      PASSWORD_REUSE_MAX 10
      PASSWORD_REUSE_TIME 180
      PASSWORD_VERIFY_FUNCTION R$PSWD_COMPLEX_F';
  ELSE
    DBMS_OUTPUT.PUT_LINE('Profile R$OLT_USER already exists');
  END IF;
END;
/
@list_profile_PASSWORD_VERIFY_FUNCTION.sql

--# PDB - Create local PDB Renaps DBAs accounts
--@cr_OLT_dbas.sql
alter user PDBADMIN profile R$OLT_DBA;
@list_pdb_users.sql

--# PDB - Reset DEFAULT profile password expiration - CDB and all PDBs
@list_profile_PASSWORD_LIFE_TIME.sql
ALTER PROFILE DEFAULT LIMIT PASSWORD_LIFE_TIME unlimited ;
@list_profile_PASSWORD_LIFE_TIME.sql

--# PDB - AWR
--set awr_pdb_autoflush_enabled=true at the PDB level (Document ID 2469637.1)
alter system set awr_pdb_autoflush_enabled=true sid='*' scope=spfile ;
@list_awr_details
--Modify the snapshot setting:(snap_interval 30 min and retention 30 days(60*24*30) = PDB
execute dbms_workload_repository.modify_snapshot_settings(interval => 30,retention => 43200);
@list_awr_details

--# PDB - Undo - check optimum
@list_undo_retention
alter system set undo_retention=21600;
@list_undo_retention

--# PDB - Tablespaces - datafiles and tempfiles - always create as bigfiles
-- review and ensure next extents and maxsize are reasonable

--# PDB - Review default tablespaces
@list_default_tbsps

--# PDB - Cap ALL datafile and tempfiles at 32GB and increment by 100M - ignore PDB$SEED tempfile typically
SPOOL cap_files.sql
SET HEADING OFF
SET FEEDBACK OFF
SELECT 'alter database tempfile '||chr(39)||NAME||chr(39)||' AUTOEXTEND ON NEXT 100M MAXSIZE 33554416K ;' FROM v$tempfile WHERE status != 'OFFLINE' order by 1;
SELECT 'alter database datafile '||chr(39)||NAME||chr(39)||' AUTOEXTEND ON NEXT 100M MAXSIZE 33554416K ;' FROM v$datafile WHERE status != 'OFFLINE' order by 1;
SPOOL OFF
SET HEADING ON
SET FEEDBACK ON
@cap_files.sql

@list_tbs_space.sql

--# PDB - Create backup copy of spfile - post customization's
DECLARE
  oracle_home VARCHAR2(200);
  cdb_name VARCHAR2(30);
  pdb_name VARCHAR2(30);
BEGIN
  oracle_home := sys_context('USERENV', 'ORACLE_HOME');
  cdb_name := sys_context('USERENV', 'INSTANCE_NAME');
  pdb_name := sys_context('USERENV', 'DB_NAME');
  EXECUTE IMMEDIATE 'CREATE PFILE=''' || oracle_home || '/dbs/init' || cdb_name || '.ora.post_' || pdb_name || '_customization'' FROM SPFILE';
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error: ' || SQLCODE || ' - ' || SQLERRM);
END;
/

--# PDB - Recompile everything
@?/rdbms/admin/utlrp
@list_invalid_objects

--set RAC off if not already
PROMPT
PROMPT Disabling RAC Option
exec dbms_registry.OPTION_OFF('RAC');
@list_registry.sql
@list_pdb_violations.sql

prompt
prompt *** Recommend closing and reopening the PDB instance(s) for everything to take effect ***
prompt
