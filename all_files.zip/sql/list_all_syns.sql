set pagesize 1000
set header off
set linesize 100

spool /home/dpdssc/sql/shawn.sql

select 'CREATE	SYNONYM kbrown.'||SYNONYM_NAME||' FOR '||TABLE_OWNER||'.'||TABLE_NAME||';' FROM dba_synonyms where owner = 'ENESJM' and table_owner = 'SURVEY' ;

spool off
