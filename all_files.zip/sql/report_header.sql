SET FEEDBACK OFF ;

col 'Database Name: ' for a32
col 'Server Name: ' for a32
col 'Report Date: ' for a32
col 'Report Date: ' for a32

col REPORT_TITLE for a80
SELECT 
  LPAD('Database Name: ', 20) || 
  RPAD(sys_context('USERENV', 'DB_NAME'), 22) AS report_title
FROM dual
UNION ALL
SELECT 
  LPAD('Instance Name: ', 20) || 
  RPAD(sys_context('USERENV', 'INSTANCE_NAME'), 22) AS report_title
FROM dual
UNION ALL
SELECT 
  LPAD('DB Unique Name: ', 20) || 
  RPAD(sys_context('USERENV', 'DB_UNIQUE_NAME'), 22) AS report_title
FROM dual
UNION ALL
SELECT 
  LPAD('Container Type: ', 20) || 
  RPAD(CASE 
         WHEN SYS_CONTEXT('USERENV', 'CON_NAME')='CDB$ROOT' THEN 'CDB' 
         ELSE 'PDB' 
       END, 22) AS report_title
FROM dual
UNION ALL
SELECT 
  LPAD('Server Name: ', 20) || 
  RPAD(sys_context('USERENV', 'HOST'), 22) AS report_title
FROM dual
UNION ALL
SELECT 
  LPAD('Report Date: ', 20) || 
  RPAD(TO_CHAR(SYSDATE, 'MM/DD/YYYY'), 22) AS report_title
FROM dual;

SET FEEDBACK ON ;