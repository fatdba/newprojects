col OWNER for a22
col TABLE_NAME for a32
select owner, table_name, stattype_locked
from dba_tab_statistics
where stattype_locked is not null
and OWNER not in ('GSMADMIN_INTERNAL','SYS','SYSTEM','WMSYS')
order by 1,2 ;
