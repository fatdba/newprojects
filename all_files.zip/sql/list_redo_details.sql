-- $Name$ list_redo_details.sql
--
-- $Log$: Modified - 04 Sep 2015 - SC - Creation
--                 - 23 Jun 2020 - SC - Cleaned up/added headers, added more details to database details
--
-- $Author$: Shawn Craven

set serveroutput on
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
set lines 2000
set pages 100
set echo off
col directory_name format a40
col directory_path format a40
col value format a80
col member format a85
col IS_RECOVERY_DEST_FIL for a50
prompt *** DATABASE DETAILS ***
col INSTANCE_NAME for a18
col STATUS for a12
col DATABASE_STATUS for a12
col VERSION for a12
col LOGINS for a12
col LOG_MODE for a12
col OPEN_MODE for a12
col DATABASE_ROLE for a18
col DB_UNIQUE_NAME for a14
col OPEN_MODE for a20
col STARTUP_TIME for a22
col SYSDATE for a22
col HOST_NAME heading "HOST_NAME" for a23
col NAME FORMAT a10
col flashback_on FORMAT a12
col force_logging FORMAT a13
col current_scn for 9999999999999999
SELECT DISTINCT instance_number,instance_name,status,database_status,logins,cast(substr(host_name,1,19) as VARCHAR2(22))||'...' "HOST_NAME...",version,startup_time,sysdate FROM gv$instance order by 1;
SELECT DISTINCT inst_id, dbid,name,db_unique_name,log_mode,open_mode,database_role,flashback_on,force_logging,current_scn,sysdate FROM gv$database order by 1 ;

prompt *** DATA GUARD DETAILS ***
col dataguard_broker for a16 tru
col remote_archive for a14
col supplemental_log_data_min for a25
col supplemental_log_data_pk for a24
col supplemental_log_data_ui for a24
col SWITCHOVER_STATUS for a32
select remote_archive,supplemental_log_data_min,supplemental_log_data_pk,supplemental_log_data_ui,switchover_status,dataguard_broker from v$database;

PROMPT
set linesize 300
PROMPT
PROMPT ***
PROMPT Redo log thread details - check for thread 0 - bad!
PROMPT ***
column REDOLOG_FILE_NAME format a85
SELECT
    a.GROUP#,
    a.THREAD#,
    a.SEQUENCE#,
    a.ARCHIVED,
    a.STATUS,
    b.MEMBER    AS REDOLOG_FILE_NAME,
    (a.BYTES/1024/1024) AS SIZE_MB
FROM v$log a
JOIN v$logfile b ON a.Group#=b.Group#
ORDER BY a.THREAD#, a.GROUP#;

PROMPT
PROMPT ***
PROMPT Standby redo log thread details - check for thread 0 - bad!
PROMPT ***
select thread#, group#, sequence#, status, bytes/1024/1024 "Stby Log in  MB"  from v$standby_log ;
PROMPT
PROMPT ***
PROMPT Log file details -- should be 1 additional stby group than redo group
PROMPT ***
select * from v$logfile order by 1;
PROMPT
PROMPT ***
PROMPT standby_file_management should be AUTO typically for DG systems
PROMPT ***
show parameter standby_file_management
PROMPT
PROMPT ***
PROMPT create_online_log_dest should be duplexed
PROMPT ***
show parameter create_online_log_dest
PROMPT
PROMPT ***
PROMPT force_logging should be YES if a Data Guard system
PROMPT ***
col force_logging for a13
select force_logging from v$database;
set echo off
