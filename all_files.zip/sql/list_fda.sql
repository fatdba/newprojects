--## Adding GF 20221005 flashback database retention information 

SET LINESIZE 150

COLUMN owner_name FORMAT A20
COLUMN flashback_archive_name FORMAT A22
COLUMN create_time FORMAT A20
COLUMN last_purge_time FORMAT A20

SELECT owner_name,
       flashback_archive_name,
       flashback_archive#,
       retention_in_days,
       TO_CHAR(create_time, 'DD-MON-YYYY HH24:MI:SS') AS create_time,
       TO_CHAR(last_purge_time, 'DD-MON-YYYY HH24:MI:SS') AS last_purge_time,
       status
FROM   dba_flashback_archive
ORDER BY owner_name, flashback_archive_name;

-- 

SET LINESIZE 150

COLUMN flashback_archive_name FORMAT A22
COLUMN tablespace_name FORMAT A20
COLUMN quota_in_mb FORMAT A11

SELECT flashback_archive_name,
       flashback_archive#,
       tablespace_name,
       quota_in_mb
FROM   dba_flashback_archive_ts
ORDER BY flashback_archive_name;

SET LINESIZE 200
col OLDEST_FLASHBACK_SCN format 99999999999
col current_minus_24h format a20
SELECT con_id
      ,OLDEST_FLASHBACK_SCN 
      ,OLDEST_FLASHBACK_TIME
      ,to_char(sysdate -1,'dd-MON-yyyy hh24:mi:ss') AS current_minus_24h 
      ,RETENTION_TARGET    
      ,FLASHBACK_SIZE/1024/1024/1024 AS fda_size_gb     
      ,ESTIMATED_FLASHBACK_SIZE/1024/1024/1025 as estimated_fda_size_gb  
FROM v$flashback_database_log
ORDER BY con_id;

