-- $Name$ list_db_timezone.sql
--
-- $Log$: Modified - 04 Sep 2018 - SC - Created
--                 - 05 Feb 2020 - SC - Added additonal information gathering
--
-- $Author$: Shawn Craven
--

prompt
prompt *** DB TIMEZONE DETAILS ***
prompt

set lines 220
col SESSIONTIMEZONE for a25
select SESSIONTIMEZONE from DUAL;

col DBTIMEZONE for a25
SELECT dbtimezone FROM DUAL;

col TIMEZONE for a30
select value as TIMEZONE from dba_scheduler_global_attribute WHERE attribute_name = 'DEFAULT_TIMEZONE' ;

PROMPT *** Last 20 startup timezones used ***
SET SPACE 1 LINESIZE 80 PAGES 1000
SET SPACE 1 LINESIZE 80 PAGES 1000
SELECT * FROM (
select to_char(ORIGINATING_TIMESTAMP,'YYYY/MM/DD HH24:MI:SS TZH:TZM')
from V$DIAG_ALERT_EXT
WHERE trim(COMPONENT_ID)='rdbms'
and MESSAGE_TEXT like ('PMON started with%')
order by originating_timestamp desc )
WHERE rownum < 20 ;

PROMPT
PROMPT *** Review fixed_date init parameter ***
show parameter fixed_date

set lines 220 
PROMPT
col current_timestamp for a38
col localtimestamp for a38
col SYSTIMESTAMP for a38

select current_timestamp, localtimestamp, SYSTIMESTAMP from dual ;
