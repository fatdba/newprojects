-- $Name$ list_services.sql
-- $Log$: Modified - 04 Jun 2019 - SC - Creation
--                 - 28 Jan 2020 - SC - updated long columns to use cast

set lines 220
col SERVICE_ID for 999999
col NAME for a25
col NETWORK_NAME for a25
col CREATION_DATE for a21
col GLOBAL for a7
col SESSION_STATE_CONSISTENCY for a26
col PDB for a15
col FAILOVER_RESTORE for a15
col CON_ID for 99999
col CON_NAME for a15
PROMPT
PROMPT *** GV$ACTIVE_SERVICES ***
PROMPT
SELECT CON_ID, CON_NAME, INST_ID, SERVICE_ID, cast(substr(name,1,30) as VARCHAR2(22))||'...' "NAME...", cast(substr(network_name,1,30) as VARCHAR2(22))||'...' "NETWORK_NAME...", CREATION_DATE FROM gv$active_services ORDER BY CON_NAME, NAME, INST_ID ;
PROMPT
PROMPT *** DBA_SERVICES ***
PROMPT
SELECT SERVICE_ID, cast(substr(name,1,19) as VARCHAR2(22))||'...' "NAME...", cast(substr(network_name,1,19) as VARCHAR2(22))||'...' "NETWORK_NAME...", CREATION_DATE, ENABLED, SESSION_STATE_CONSISTENCY, PDB
FROM dba_services
WHERE NAME not like 'E122010X%'
order by NAME ;
/*
PROMPT
PROMPT ***SYS.ENABLE_PRIMARY_SERVICE *** Trigger status
PROMPT
col TRIGGER_NAME for a35
col TRIGGERING_EVENT for a35
select owner, TRIGGER_NAME, TRIGGER_TYPE, TRIGGERING_EVENT, STATUS from dba_triggers where TRIGGER_NAME = 'ENABLE_PRIMARY_SERVICE' ;
*/

--cast(substr(network_name,1,19) as VARCHAR2(22))||'...' "NETWORK_NAME..."
