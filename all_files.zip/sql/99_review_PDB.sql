prompt
prompt *** PDB Post Creation and Data Loading Report ***

@report_header.sql
@list_pdbs
@list_pdb_violations
@list_db_directories
@list_tbs_space
@list_profiles
@list_pdb_users
@list_profile_PASSWORD_LIFE_TIME.sql
@list_invalid_objects
@list_bad_synonyms.sql


