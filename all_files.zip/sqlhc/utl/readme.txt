30th July 2021 
The utility files in this directory are copies of the files found in the utility directory of SQLTXPLAIN. 
Modifications to these files is not allowed. The original SQLTXPLAIN files should be modified if needed and copied to this utility directory.
Files from the SQLTXPLAIN utility directory which do not work without a SQLTXPLAIN repository, have not been copied.
Subsequently all the files in this SQLHC utility directory should work without a SQLTXPLAIN repository.