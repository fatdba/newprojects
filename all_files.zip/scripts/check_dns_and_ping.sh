#!/bin/bash
################################################################################
#
# Script Name: check_dns_and_ping.sh
#
# Author: Shawn Craven
#
# Description: This script checks the availability of database servers by pinging
#              them and performs DNS lookups to verify their resolution. It provides
#              details on whether each server is reachable and its corresponding
#              DNS Name and Address.
#
# Usage: ./check_dns_and_ping.sh
#
# Notes: Ensure the "servers" array contains the correct server names. The script
#        requires network connectivity to perform ping and DNS lookups.
#        Ping checks for server reachability, and nslookup verifies DNS resolution.
#
# Modified: SC - 04 Nov 2024 - Initial script creation
#         : SC - 05 Dev 2024 - Reformatted script to be easier to read.
#
###############################################################################

# List of servers to ping and lookup
servers=(LTMS-DEV-DB01 LTMS-QA-DB01 LTMS-STAGE-DB01 LTMS-PROD-DB01)

# Loop through each server in the array
for server in "${servers[@]}"
do
  echo "Checking server: $server"

  # Ping the server and suppress the output to /dev/null
  ping -c 1 $server > /dev/null 2>&1

  # Check the exit status of the ping command
  if [ $? -eq 0 ]; then
    echo "$server is up"
  else
    echo "$server is down"
  fi

  # Perform DNS lookup and extract Name and Address using grep and sed for formatting
  nslookup $server | grep -E 'Name|Address' | sed 's/^/    /'

  echo "-------------------------------------------"
done
