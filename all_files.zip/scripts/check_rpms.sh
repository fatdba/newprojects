#!/bin/bash
################################################################################
#
# Script Name: check_rpms.sh
#
# Author: Shawn Craven
#
# Description: 
# This script checks whether a specific list of RPM packages is installed on the
# system. For each package in the list, the script will determine if the package
# is installed and, if it is, will output the installed version of the package.
# If the package is not installed, the script will indicate that it is missing.
#
# Usage: 
# ./check_rpms.sh
# 
# No switches or arguments are necessary. The script is designed to be run as-is.
#
# Notes: 
# Ensure that the script has execute permissions before running it. 
# To grant execute permissions, run: chmod +x check_rpms.sh
#
# Modified: SC - Jun 03, 2019 - Creation.
#         : SC - Aug 09, 2024 - Renamed script to check_rpms.sh and modified to use an array.
#
###############################################################################

# List of RPM packages to check
packages=(
    binutils
    cloog-ppl
    compat-libcap1
    compat-libstdc++-33
    cpp
	dos2unix   # Replacing unix2dos with dos2unix since unix2dos is part of dos2unix package
    elfutils
    ftp
    gcc
    glibc
    kernel
    ksh
    libaio
    libdmx
    libgcc
    libstdc
    libtool
    libXmu
    libXt
    libXv
    libXxf86dga
    libXxf86misc
    libXxf86vm
    mailx
    make
    mpfr
    ncurses
    ppl
    readline
    sharutils   # uuencode is part of the sharutils package
    sysstat
    unixODBC
    xorg-x11-utils
    xorg-x11-xauth
)

# Loop through the list of packages
for package in "${packages[@]}"; do
    # Check if the package is installed
    rpm_output=$(rpm -qa | grep "^$package")

    if [ -n "$rpm_output" ]; then
        echo "$package is installed. Version: $rpm_output"
    else
        echo "$package is not installed."
    fi
done
