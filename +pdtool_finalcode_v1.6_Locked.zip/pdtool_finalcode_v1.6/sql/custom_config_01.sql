-- this is a sample custom configuration requesting to produce just one section
-- for all possible DEF values please review pdtool1_00_config.sql
DEF pdtool1_sections = '1a';
