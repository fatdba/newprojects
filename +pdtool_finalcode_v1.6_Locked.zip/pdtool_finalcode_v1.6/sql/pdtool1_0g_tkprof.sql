-- tkprof for trace from execution of tool in case someone reports slow performance in tool
HOS ls -lat &&pdtool1_udump_path.*ora_&&pdtool1_spid._&&pdtool1_tracefile_identifier..trc >> &&pdtool1_log3..txt
HOS tkprof &&pdtool1_udump_path.*ora_&&pdtool1_spid._&&pdtool1_tracefile_identifier..trc &&pdtool1_tkprof._sort.txt sort=prsela exeela fchela >> &&pdtool1_log3..txt
HOS zip &&pdtool1_zip_filename. &&pdtool1_tkprof._sort.txt >> &&pdtool1_log3..txt
