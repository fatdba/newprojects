
PRO /************************************************************************************/

@@get_ddl INSTALL I1OCW_T_GSMCELL_A INDEX
@@get_ddl INSTALL PK_OCW_T_GSMCELL_A INDEX
