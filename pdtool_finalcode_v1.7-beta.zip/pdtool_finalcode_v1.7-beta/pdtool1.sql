/*****************************************************************************************
   
    pdtool1 - Oracle Database health audit tool
    pdtool1_right (C) 2020  


*****************************************************************************************/
DEF ash_validation = '';
@@sql/pdtool1_0a_main.sql
-- list of generated files
HOS unzip -l &&pdtool1_move_directory.&&pdtool1_zip_filename.
PRO "End pdtool1. Output: &&pdtool1_move_directory.&&pdtool1_zip_filename..zip"