SELECT TO_CHAR(ROWNUM) row_num, v0.* FROM /* 2a.32 */ (
WITH
obj AS (
SELECT /*+  MATERIALIZE NO_MERGE  */ /* 2a.32 */
       owner,
       object_name,
       object_id,
       last_ddl_time
  FROM dba_objects
 WHERE object_type LIKE 'TABLE%'
   AND last_ddl_time IS NOT NULL
   AND owner NOT IN ('ANONYMOUS','APEX_030200','APEX_040000','APEX_SSO','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS')
   AND owner NOT IN ('SI_INFORMTN_SCHEMA','SQLTXADMIN','SQLTXPLAIN','SYS','SYSMAN','SYSTEM','TRCANLZR','WMSYS','XDB','XS$NULL','PERFSTAT','STDBYPERF','MGDSYS','OJVMSYS')
),
ash AS (
SELECT /*+  MATERIALIZE NO_MERGE   DYNAMIC_SAMPLING(4)   FULL(h.ash) FULL(h.evt) FULL(h.sn) USE_HASH(h.sn h.ash h.evt)   FULL(h.INT$DBA_HIST_ACT_SESS_HISTORY.sn) FULL(h.INT$DBA_HIST_ACT_SESS_HISTORY.ash) FULL(h.INT$DBA_HIST_ACT_SESS_HISTORY.evt)   USE_HASH(h.INT$DBA_HIST_ACT_SESS_HISTORY.sn h.INT$DBA_HIST_ACT_SESS_HISTORY.ash h.INT$DBA_HIST_ACT_SESS_HISTORY.evt)  */
       /* 2a.32 */
       current_obj#,
       MAX(CAST(sample_time AS DATE)) sample_date
  FROM dba_hist_active_sess_history h
 WHERE current_obj# > 0
   AND sql_plan_operation LIKE '%TABLE%'
   AND snap_id BETWEEN 16731 AND 17473
   AND dbid = 1708174106
 GROUP BY
       current_obj#
),
sta1 AS (
SELECT /*+  MATERIALIZE NO_MERGE  */ /* 2a.32 */
       owner,
       table_name,
       MAX(last_analyzed) last_analyzed
  FROM dba_tab_statistics
 WHERE last_analyzed IS NOT NULL
   AND owner NOT IN ('ANONYMOUS','APEX_030200','APEX_040000','APEX_SSO','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS')
   AND owner NOT IN ('SI_INFORMTN_SCHEMA','SQLTXADMIN','SQLTXPLAIN','SYS','SYSMAN','SYSTEM','TRCANLZR','WMSYS','XDB','XS$NULL','PERFSTAT','STDBYPERF','MGDSYS','OJVMSYS')
 GROUP BY
       owner,
       table_name
),
sta2 AS (
SELECT /*+  MATERIALIZE NO_MERGE  */ /* 2a.32 */
       owner,
       table_name,
       last_analyzed
  FROM dba_tables
 WHERE last_analyzed IS NOT NULL
   AND owner NOT IN ('ANONYMOUS','APEX_030200','APEX_040000','APEX_SSO','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS')
   AND owner NOT IN ('SI_INFORMTN_SCHEMA','SQLTXADMIN','SQLTXPLAIN','SYS','SYSMAN','SYSTEM','TRCANLZR','WMSYS','XDB','XS$NULL','PERFSTAT','STDBYPERF','MGDSYS','OJVMSYS')
),
sta3 AS (
SELECT /*+  MATERIALIZE NO_MERGE  */ /* 2a.32 */
       table_owner owner,
       table_name,
       MAX(timestamp) last_date
  FROM dba_tab_modifications
 WHERE timestamp IS NOT NULL
   AND table_owner NOT IN ('ANONYMOUS','APEX_030200','APEX_040000','APEX_SSO','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS')
   AND table_owner NOT IN ('SI_INFORMTN_SCHEMA','SQLTXADMIN','SQLTXPLAIN','SYS','SYSMAN','SYSTEM','TRCANLZR','WMSYS','XDB','XS$NULL','PERFSTAT','STDBYPERF','MGDSYS','OJVMSYS')
 GROUP BY
       table_owner,
       table_name
),
grp AS (
SELECT /*+  MATERIALIZE NO_MERGE  */ /* 2a.32 */
       owner,
       object_name table_name,
       MAX(last_ddl_time) last_date
  FROM obj
 GROUP BY
       owner,
       object_name
 UNION
SELECT obj.owner,
       obj.object_name table_name,
       MAX(sample_date) last_date
  FROM ash, obj
 WHERE obj.object_id = ash.current_obj#
 GROUP BY
       obj.owner,
       obj.object_name
 UNION
SELECT owner,
       table_name,
       last_analyzed last_date
  FROM sta1
 UNION
SELECT owner,
       table_name,
       last_analyzed last_date
  FROM sta2
 UNION
SELECT owner,
       table_name,
       last_date
  FROM sta3
)
SELECT /*+  NO_MERGE  */ /* 2a.32 */
       MAX(last_date) last_date,
       owner,
       table_name
  FROM grp
 GROUP BY
       owner,
       table_name
HAVING MAX(last_date) < SYSDATE - 31
 ORDER BY
       1, 2, 3
) v0 WHERE ROWNUM <= 10000
